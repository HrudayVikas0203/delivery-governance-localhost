"""Add executive payload storage for solution architectures

Revision ID: 003_solution_architecture_executive_payload
Revises: 002_artifact_versioning
Create Date: 2026-08-02 19:45:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = '003_solution_architecture_executive_payload'
down_revision: Union[str, None] = '002_artifact_versioning'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = inspector.get_table_names()
    
    if 'alembic_version' in tables:
        ver_cols = {c['name']: c for c in inspector.get_columns('alembic_version')}
        if 'version_num' in ver_cols:
            col_type = str(ver_cols['version_num']['type'])
            if '255' not in col_type:
                op.execute("ALTER TABLE alembic_version MODIFY version_num VARCHAR(255)")

    if 'solution_architectures' in tables:
        arch_cols = [c['name'] for c in inspector.get_columns('solution_architectures')]
        if 'executive_json' not in arch_cols:
            op.add_column(
                'solution_architectures',
                sa.Column('executive_json', sa.Text(), nullable=True),
            )


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = inspector.get_table_names()
    if 'solution_architectures' in tables:
        arch_cols = [c['name'] for c in inspector.get_columns('solution_architectures')]
        if 'executive_json' in arch_cols:
            op.drop_column('solution_architectures', 'executive_json')
