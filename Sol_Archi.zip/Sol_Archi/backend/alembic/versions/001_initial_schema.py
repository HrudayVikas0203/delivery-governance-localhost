"""Initial MySQL schema migration for AI Solution Architect Copilot

Revision ID: 001_initial_schema
Revises: 
Create Date: 2026-07-26 22:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = '001_initial_schema'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'roles',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=64), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('permissions_json', sa.Text(), nullable=True),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_roles_name'), 'roles', ['name'], unique=True)

    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.String(length=64), nullable=False),
        sa.Column('username', sa.String(length=128), nullable=False),
        sa.Column('email', sa.String(length=255), nullable=False),
        sa.Column('password_hash', sa.String(length=255), nullable=False),
        sa.Column('role_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.ForeignKeyConstraint(['role_id'], ['roles.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_users_user_id'), 'users', ['user_id'], unique=True)
    op.create_index(op.f('ix_users_username'), 'users', ['username'], unique=True)
    op.create_index(op.f('ix_users_email'), 'users', ['email'], unique=True)

    op.create_table(
        'projects',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('owner_user_id', sa.String(length=64), nullable=True),
        sa.Column('selected_tech_stack', sa.String(length=255), nullable=True),
        sa.Column('selected_database', sa.String(length=255), nullable=True),
        sa.Column('is_stack_confirmed', sa.Boolean(), nullable=False),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_projects_project_id'), 'projects', ['project_id'], unique=True)
    op.create_index(op.f('ix_projects_owner_user_id'), 'projects', ['owner_user_id'], unique=False)

    op.create_table(
        'documents',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('document_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('file_name', sa.String(length=255), nullable=False),
        sa.Column('file_type', sa.String(length=64), nullable=False),
        sa.Column('file_size', sa.Integer(), nullable=False),
        sa.Column('file_path', sa.String(length=512), nullable=False),
        sa.Column('uploaded_at', sa.String(length=64), nullable=False),
        sa.Column('status', sa.String(length=64), nullable=False),
        sa.Column('page_count', sa.Integer(), nullable=False),
        sa.Column('chunk_count', sa.Integer(), nullable=False),
        sa.Column('sha256', sa.String(length=128), nullable=True),
        sa.Column('raw_text', sa.Text(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_documents_document_id'), 'documents', ['document_id'], unique=True)
    op.create_index(op.f('ix_documents_project_id'), 'documents', ['project_id'], unique=False)

    op.create_table(
        'requirements',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('document_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False),
        sa.Column('overview', sa.Text(), nullable=True),
        sa.Column('payload_json', sa.Text(), nullable=False),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_requirements_document_id'), 'requirements', ['document_id'], unique=False)
    op.create_index(op.f('ix_requirements_project_id'), 'requirements', ['project_id'], unique=False)
    op.create_index(op.f('ix_requirements_version'), 'requirements', ['version'], unique=False)

    op.create_table(
        'business_flows',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('document_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False),
        sa.Column('nodes_json', sa.Text(), nullable=False),
        sa.Column('edges_json', sa.Text(), nullable=False),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_business_flows_document_id'), 'business_flows', ['document_id'], unique=False)
    op.create_index(op.f('ix_business_flows_project_id'), 'business_flows', ['project_id'], unique=False)
    op.create_index(op.f('ix_business_flows_version'), 'business_flows', ['version'], unique=False)

    op.create_table(
        'solution_architectures',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('document_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False),
        sa.Column('nodes_json', sa.Text(), nullable=False),
        sa.Column('edges_json', sa.Text(), nullable=False),
        sa.Column('tech_stack_details_json', sa.Text(), nullable=True),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_solution_architectures_document_id'), 'solution_architectures', ['document_id'], unique=False)
    op.create_index(op.f('ix_solution_architectures_project_id'), 'solution_architectures', ['project_id'], unique=False)
    op.create_index(op.f('ix_solution_architectures_version'), 'solution_architectures', ['version'], unique=False)

    op.create_table(
        'database_designs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('document_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False),
        sa.Column('entities_json', sa.Text(), nullable=False),
        sa.Column('database_tech', sa.String(length=128), nullable=False),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_database_designs_document_id'), 'database_designs', ['document_id'], unique=False)
    op.create_index(op.f('ix_database_designs_project_id'), 'database_designs', ['project_id'], unique=False)
    op.create_index(op.f('ix_database_designs_version'), 'database_designs', ['version'], unique=False)

    op.create_table(
        'reports',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('report_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('report_type', sa.String(length=128), nullable=False),
        sa.Column('title', sa.String(length=255), nullable=False),
        sa.Column('content_json', sa.Text(), nullable=False),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.Column('updated_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_reports_report_id'), 'reports', ['report_id'], unique=True)
    op.create_index(op.f('ix_reports_project_id'), 'reports', ['project_id'], unique=False)

    op.create_table(
        'chat_history',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('message_id', sa.String(length=64), nullable=False),
        sa.Column('project_id', sa.String(length=64), nullable=False),
        sa.Column('session_id', sa.String(length=64), nullable=False),
        sa.Column('user_id', sa.String(length=64), nullable=True),
        sa.Column('role', sa.String(length=32), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('sources_json', sa.Text(), nullable=True),
        sa.Column('created_at', sa.String(length=64), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_chat_history_message_id'), 'chat_history', ['message_id'], unique=True)
    op.create_index(op.f('ix_chat_history_project_id'), 'chat_history', ['project_id'], unique=False)
    op.create_index(op.f('ix_chat_history_session_id'), 'chat_history', ['session_id'], unique=False)
    op.create_index(op.f('ix_chat_history_user_id'), 'chat_history', ['user_id'], unique=False)


def downgrade() -> None:
    op.drop_table('chat_history')
    op.drop_table('reports')
    op.drop_table('database_designs')
    op.drop_table('solution_architectures')
    op.drop_table('business_flows')
    op.drop_table('requirements')
    op.drop_table('documents')
    op.drop_table('projects')
    op.drop_table('users')
    op.drop_table('roles')
