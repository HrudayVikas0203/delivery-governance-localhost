"""Artifact versioning and metadata schema migration

Revision ID: 002_artifact_versioning
Revises: 001_initial_schema
Create Date: 2026-07-28 15:10:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = '002_artifact_versioning'
down_revision: Union[str, None] = '001_initial_schema'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    tables = ['business_flows', 'solution_architectures', 'database_designs', 'reports']
    
    for table in tables:
        op.add_column(table, sa.Column('ai_provider', sa.String(length=64), nullable=True))
        op.add_column(table, sa.Column('model_used', sa.String(length=128), nullable=True))
        op.add_column(table, sa.Column('prompt_version', sa.String(length=64), nullable=True, server_default='v1.0'))
        op.add_column(table, sa.Column('created_by', sa.String(length=128), nullable=False, server_default='AI Engine'))
        op.add_column(table, sa.Column('generation_status', sa.String(length=32), nullable=False, server_default='Success'))

    op.add_column('reports', sa.Column('version', sa.Integer(), nullable=False, server_default='1'))
    op.create_index('ix_reports_version', 'reports', ['version'], unique=False)
    
    op.create_index('ix_business_flows_project_version', 'business_flows', ['project_id', 'version'], unique=False)
    op.create_index('ix_business_flows_created_at', 'business_flows', ['created_at'], unique=False)

    op.create_index('ix_solution_architectures_project_version', 'solution_architectures', ['project_id', 'version'], unique=False)
    op.create_index('ix_solution_architectures_created_at', 'solution_architectures', ['created_at'], unique=False)

    op.create_index('ix_database_designs_project_version', 'database_designs', ['project_id', 'version'], unique=False)
    op.create_index('ix_database_designs_created_at', 'database_designs', ['created_at'], unique=False)

    op.create_index('ix_reports_project_version', 'reports', ['project_id', 'version'], unique=False)
    op.create_index('ix_reports_created_at', 'reports', ['created_at'], unique=False)


def downgrade() -> None:
    tables = ['business_flows', 'solution_architectures', 'database_designs', 'reports']

    op.drop_index('ix_reports_created_at', table_name='reports')
    op.drop_index('ix_reports_project_version', table_name='reports')
    op.drop_index('ix_database_designs_created_at', table_name='database_designs')
    op.drop_index('ix_database_designs_project_version', table_name='database_designs')
    op.drop_index('ix_solution_architectures_created_at', table_name='solution_architectures')
    op.drop_index('ix_solution_architectures_project_version', table_name='solution_architectures')
    op.drop_index('ix_business_flows_created_at', table_name='business_flows')
    op.drop_index('ix_business_flows_project_version', table_name='business_flows')

    op.drop_index('ix_reports_version', table_name='reports')
    op.drop_column('reports', 'version')

    for table in tables:
        op.drop_column(table, 'generation_status')
        op.drop_column(table, 'created_by')
        op.drop_column(table, 'prompt_version')
        op.drop_column(table, 'model_used')
        op.drop_column(table, 'ai_provider')
