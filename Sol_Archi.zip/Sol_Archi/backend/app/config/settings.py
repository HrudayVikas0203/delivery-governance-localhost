from __future__ import annotations

import os
import logging
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Resolve the backend environment file independently of Uvicorn's working
# directory. override=True ensures a backend restart uses a newly edited local
# .env value instead of a stale inherited process environment variable.
BACKEND_ROOT = Path(__file__).resolve().parents[2]
BACKEND_ENV_PATH = BACKEND_ROOT / ".env"
load_dotenv(dotenv_path=BACKEND_ENV_PATH, override=True)


def _parse_csv(value: str | None, default: list[str]) -> list[str]:
    if not value:
        return default
    return [item.strip() for item in value.split(",") if item.strip()]


@dataclass(frozen=True)
class ApplicationSettings:
    APP_NAME: str
    APP_VERSION: str
    CORS_ALLOW_ORIGINS: list[str]
    HTTP_TIMEOUT_SECONDS: int


@dataclass(frozen=True)
class DatabaseSettings:
    MYSQL_HOST: str
    MYSQL_PORT: str
    MYSQL_DATABASE: str
    MYSQL_USER: str
    MYSQL_PASSWORD: str
    APP_DB_PATH: str

    @property
    def DATABASE_URL(self) -> str:
        from urllib.parse import quote_plus

        host = self.MYSQL_HOST or "localhost"
        port = self.MYSQL_PORT or "3306"
        database = self.MYSQL_DATABASE or "ai_solution_architect"
        user = quote_plus(self.MYSQL_USER or "root")
        password = quote_plus(self.MYSQL_PASSWORD or "")
        return f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"


@dataclass(frozen=True)
class SecuritySettings:
    JWT_SECRET: str


@dataclass(frozen=True)
class StorageSettings:
    UPLOAD_DIR: str
    CHROMA_PERSIST_DIR: str
    CHROMA_COLLECTION_NAME: str
    MAX_UPLOAD_SIZE_MB: int
    ALLOWED_UPLOAD_EXTENSIONS: set[str]
    CHUNK_SIZE: int
    CHUNK_OVERLAP: int


class AISettings:
    _llm_provider: str = "groq"
    _groq_api_key: str = ""
    _groq_model: str = "llama-3.3-70b-versatile"
    _gemini_api_key: str = ""
    _gemini_model: str = "gemini-2.5-flash"
    _openai_api_key: str = ""
    _openai_model: str = "gpt-4o"

    def __init__(
        self,
        LLM_PROVIDER: str = "groq",
        GROQ_API_KEY: str = "",
        GROQ_MODEL: str = "llama-3.3-70b-versatile",
        GEMINI_API_KEY: str = "",
        GEMINI_MODEL: str = "gemini-2.5-flash",
        OPENAI_API_KEY: str = "",
        OPENAI_MODEL: str = "gpt-4o",
    ):
        self._llm_provider = LLM_PROVIDER
        self._groq_api_key = GROQ_API_KEY
        self._groq_model = GROQ_MODEL
        self._gemini_api_key = GEMINI_API_KEY
        self._gemini_model = GEMINI_MODEL
        self._openai_api_key = OPENAI_API_KEY
        self._openai_model = OPENAI_MODEL

    @property
    def LLM_PROVIDER(self) -> str:
        return os.getenv("LLM_PROVIDER", self._llm_provider)

    @property
    def GROQ_API_KEY(self) -> str:
        return os.getenv("GROQ_API_KEY", self._groq_api_key)

    @property
    def GROQ_MODEL(self) -> str:
        return os.getenv("GROQ_MODEL", self._groq_model)

    @property
    def GEMINI_API_KEY(self) -> str:
        return os.getenv("GEMINI_API_KEY", os.getenv("GOOGLE_API_KEY", self._gemini_api_key))

    @property
    def GEMINI_MODEL(self) -> str:
        return os.getenv("GEMINI_MODEL", self._gemini_model)

    @property
    def OPENAI_API_KEY(self) -> str:
        return os.getenv("OPENAI_API_KEY", self._openai_api_key)

    @property
    def OPENAI_MODEL(self) -> str:
        return os.getenv("OPENAI_MODEL", self._openai_model)


@dataclass(frozen=True)
class LoggingSettings:
    LOG_DIR: str


@dataclass(frozen=True)
class Settings:
    # 1. Application Group
    APP_NAME: str
    APP_VERSION: str
    CORS_ALLOW_ORIGINS: list[str]
    HTTP_TIMEOUT_SECONDS: int

    # 2. Database Group
    MYSQL_HOST: str
    MYSQL_PORT: str
    MYSQL_DATABASE: str
    MYSQL_USER: str
    MYSQL_PASSWORD: str
    APP_DB_PATH: str

    # 3. Security Group
    JWT_SECRET: str

    # 4. Storage Group
    UPLOAD_DIR: str
    CHROMA_PERSIST_DIR: str
    CHROMA_COLLECTION_NAME: str
    MAX_UPLOAD_SIZE_MB: int
    ALLOWED_UPLOAD_EXTENSIONS: set[str]
    CHUNK_SIZE: int
    CHUNK_OVERLAP: int

    # 5. AI Settings Group
    LLM_PROVIDER: str
    GROQ_API_KEY: str
    GROQ_MODEL: str
    GEMINI_API_KEY: str
    GEMINI_MODEL: str
    OPENAI_API_KEY: str
    OPENAI_MODEL: str

    # 6. Logging Group
    LOG_DIR: str

    # Structured Section Accessors
    app: ApplicationSettings
    db: DatabaseSettings
    security: SecuritySettings
    storage: StorageSettings
    ai: AISettings
    logging: LoggingSettings

    @property
    def DATABASE_URL(self) -> str:
        return self.db.DATABASE_URL


def _build_settings() -> Settings:
    backend_root = BACKEND_ROOT
    data_root = backend_root / "data"
    uploads_root = data_root / "uploads"
    chroma_root = data_root / "chroma"
    logs_root = data_root / "logs"

    data_root.mkdir(parents=True, exist_ok=True)
    uploads_root.mkdir(parents=True, exist_ok=True)
    chroma_root.mkdir(parents=True, exist_ok=True)
    logs_root.mkdir(parents=True, exist_ok=True)

    app_settings = ApplicationSettings(
        APP_NAME=os.getenv("APP_NAME", "AISolutionArchitect Backend"),
        APP_VERSION=os.getenv("APP_VERSION", "1.0.0"),
        CORS_ALLOW_ORIGINS=_parse_csv(os.getenv("CORS_ALLOW_ORIGINS"), ["http://localhost:5173"]),
        HTTP_TIMEOUT_SECONDS=int(os.getenv("HTTP_TIMEOUT_SECONDS", "90")),
    )

    db_settings = DatabaseSettings(
        MYSQL_HOST=os.getenv("MYSQL_HOST", "localhost"),
        MYSQL_PORT=os.getenv("MYSQL_PORT", "3306"),
        MYSQL_DATABASE=os.getenv("MYSQL_DATABASE", "ai_solution_architect"),
        MYSQL_USER=os.getenv("MYSQL_USER", "root"),
        MYSQL_PASSWORD=os.getenv("MYSQL_PASSWORD", "Nous@12345"),
        APP_DB_PATH=str(data_root / "app.db"),
    )

    sec_settings = SecuritySettings(
        JWT_SECRET=os.getenv("JWT_SECRET", ""),
    )

    storage_settings = StorageSettings(
        UPLOAD_DIR=str(uploads_root),
        CHROMA_PERSIST_DIR=str(chroma_root),
        CHROMA_COLLECTION_NAME=os.getenv("CHROMA_COLLECTION_NAME", "project_document_chunks"),
        MAX_UPLOAD_SIZE_MB=int(os.getenv("MAX_UPLOAD_SIZE_MB", "25")),
        ALLOWED_UPLOAD_EXTENSIONS={
            ext.lower()
            for ext in _parse_csv(os.getenv("ALLOWED_UPLOAD_EXTENSIONS"), ["pdf", "docx", "txt", "md"])
        },
        CHUNK_SIZE=int(os.getenv("CHUNK_SIZE", "1200")),
        CHUNK_OVERLAP=int(os.getenv("CHUNK_OVERLAP", "200")),
    )

    ai_settings = AISettings(
        LLM_PROVIDER=os.getenv("LLM_PROVIDER", "groq"),
        GROQ_API_KEY=os.getenv("GROQ_API_KEY", ""),
        GROQ_MODEL=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
        GEMINI_API_KEY=os.getenv("GEMINI_API_KEY", os.getenv("GOOGLE_API_KEY", "")),
        GEMINI_MODEL=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        OPENAI_API_KEY=os.getenv("OPENAI_API_KEY", ""),
        OPENAI_MODEL=os.getenv("OPENAI_MODEL", "gpt-4o"),
    )

    logging_settings = LoggingSettings(
        LOG_DIR=str(logs_root),
    )

    built_settings = Settings(
        # Application Group
        APP_NAME=app_settings.APP_NAME,
        APP_VERSION=app_settings.APP_VERSION,
        CORS_ALLOW_ORIGINS=app_settings.CORS_ALLOW_ORIGINS,
        HTTP_TIMEOUT_SECONDS=app_settings.HTTP_TIMEOUT_SECONDS,
        # Database Group
        MYSQL_HOST=db_settings.MYSQL_HOST,
        MYSQL_PORT=db_settings.MYSQL_PORT,
        MYSQL_DATABASE=db_settings.MYSQL_DATABASE,
        MYSQL_USER=db_settings.MYSQL_USER,
        MYSQL_PASSWORD=db_settings.MYSQL_PASSWORD,
        APP_DB_PATH=db_settings.APP_DB_PATH,
        # Security Group
        JWT_SECRET=sec_settings.JWT_SECRET,
        # Storage Group
        UPLOAD_DIR=storage_settings.UPLOAD_DIR,
        CHROMA_PERSIST_DIR=storage_settings.CHROMA_PERSIST_DIR,
        CHROMA_COLLECTION_NAME=storage_settings.CHROMA_COLLECTION_NAME,
        MAX_UPLOAD_SIZE_MB=storage_settings.MAX_UPLOAD_SIZE_MB,
        ALLOWED_UPLOAD_EXTENSIONS=storage_settings.ALLOWED_UPLOAD_EXTENSIONS,
        CHUNK_SIZE=storage_settings.CHUNK_SIZE,
        CHUNK_OVERLAP=storage_settings.CHUNK_OVERLAP,
        # AI Group
        LLM_PROVIDER=ai_settings.LLM_PROVIDER,
        GROQ_API_KEY=ai_settings.GROQ_API_KEY,
        GROQ_MODEL=ai_settings.GROQ_MODEL,
        GEMINI_API_KEY=ai_settings.GEMINI_API_KEY,
        GEMINI_MODEL=ai_settings.GEMINI_MODEL,
        OPENAI_API_KEY=ai_settings.OPENAI_API_KEY,
        OPENAI_MODEL=ai_settings.OPENAI_MODEL,
        # Logging Group
        LOG_DIR=logging_settings.LOG_DIR,
        # Section Accessors
        app=app_settings,
        db=db_settings,
        security=sec_settings,
        storage=storage_settings,
        ai=ai_settings,
        logging=logging_settings,
    )
    logger.info(
        "[Groq] API key loaded: %s | API key source: backend environment | Model: %s",
        bool(built_settings.ai.GROQ_API_KEY),
        built_settings.ai.GROQ_MODEL,
    )
    return built_settings


settings = _build_settings()
