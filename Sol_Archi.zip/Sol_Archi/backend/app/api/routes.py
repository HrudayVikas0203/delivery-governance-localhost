from fastapi import APIRouter
from app.api.endpoints import router as endpoints_router

v1_router = APIRouter(prefix="/v1", tags=["v1"])
v1_router.include_router(endpoints_router)

api_router = APIRouter(prefix="/api")
api_router.include_router(endpoints_router)
api_router.include_router(v1_router)


