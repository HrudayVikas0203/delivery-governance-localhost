from __future__ import annotations

import logging
import time
from typing import Any, Dict

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.storage import metadata_store
from app.schemas.documents import (
    ArchitectureGenerationRequest,
    ArchitectureRequest,
    BusinessFlowGenerationRequest,
    BusinessFlowRequest,
    ChatQueryRequest,
    ChatQueryResponse,
    ProjectCreateRequest,
    ProjectResponse,
    ProcessingStatusResponse,
    ReportGenerationRequest,
    RequirementGenerationRequest,
    RequirementUpdateRequest,
    UploadResponse,
)
from app.services.ai_service import AIService
from app.services.chat_service import chat_service
from app.services.document_service import DocumentService
from app.debug_session_log import write_debug_log

router = APIRouter(tags=["main"])

document_service = DocumentService()
ai_service = AIService()
logger = logging.getLogger(__name__)


def _enrich_payload_with_mysql_data(payload_dict: Dict[str, Any], project_id: str, doc_id: str | None, db: Session) -> Dict[str, Any]:
    if not project_id and not doc_id:
        raise HTTPException(status_code=400, detail="Project ID or Document ID is required for AI generation")

    existing_reqs = payload_dict.get("requirements") or {}
    if not existing_reqs.get("overview") and not existing_reqs.get("functional"):
        mysql_reqs = None
        if doc_id:
            doc_reqs = metadata_store.get_requirements(doc_id, db=db)
            if doc_reqs:
                mysql_reqs = doc_reqs
        if not mysql_reqs and project_id:
            proj_reqs = metadata_store.get_project_requirements(project_id, db=db)
            if proj_reqs and len(proj_reqs) > 0:
                mysql_reqs = proj_reqs[0]

        if mysql_reqs:
            payload_dict["requirements"] = mysql_reqs

    return payload_dict


def _validate_generated_artifact(result: Dict[str, Any], artifact: str) -> None:
    """Reject parsed-but-malformed model output before it can be versioned."""
    if not isinstance(result, dict):
        raise HTTPException(status_code=422, detail=f"AI returned an invalid {artifact} JSON payload")

    required_lists = {
        "business flow": ("nodes", "edges"),
        "architecture": ("nodes", "edges"),
    }
    if any(not isinstance(result.get(key), list) for key in required_lists[artifact]):
        raise HTTPException(status_code=422, detail=f"AI returned an invalid {artifact} JSON payload")


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/projects", response_model=list[ProjectResponse])
def list_projects(db: Session = Depends(get_db)):
    return metadata_store.list_projects(db=db)


@router.post("/projects", response_model=ProjectResponse)
def create_project(payload: ProjectCreateRequest, db: Session = Depends(get_db)):
    return metadata_store.create_project(
        name=payload.name,
        description=payload.description,
        selected_tech_stack=payload.selectedTechStack,
        selected_database=payload.selectedDatabase,
        is_stack_confirmed=payload.isStackConfirmed,
        db=db,
    )


@router.post("/documents/upload", response_model=UploadResponse)
def upload_document(
    file: UploadFile = File(...),
    projectId: str = Form(...),
    db: Session = Depends(get_db),
):
    if not projectId:
        raise HTTPException(status_code=400, detail="Project ID is required")
    file_bytes = file.file.read()
    return document_service.upload_document(projectId, file.filename or "uploaded-file", file_bytes, db=db)


@router.get("/documents/project/{project_id}")
def list_project_documents(project_id: str, db: Session = Depends(get_db)):
    write_debug_log(
        "endpoints.py:list_project_documents",
        "List project documents",
        {"project_id": project_id},
        hypothesis_id="F",
    )
    try:
        return document_service.list_project_documents(project_id, db=db)
    except Exception as exc:
        write_debug_log(
            "endpoints.py:list_project_documents",
            "List project documents failed",
            {"project_id": project_id, "error": str(exc)},
            hypothesis_id="F",
        )
        raise


@router.get("/documents/{document_id}/status", response_model=ProcessingStatusResponse)
def get_status(document_id: str, db: Session = Depends(get_db)):
    return document_service.get_processing_status(document_id, db=db)


@router.get("/requirements/project/{project_id}")
def get_project_requirements(project_id: str, db: Session = Depends(get_db)):
    reqs = metadata_store.get_project_requirements(project_id, db=db)
    return {"projectId": project_id, "requirements": reqs}


@router.get("/requirements/{document_id}")
def get_requirements(document_id: str, db: Session = Depends(get_db)):
    req = metadata_store.get_requirements(document_id, db=db)
    return {"documentId": document_id, "requirements": req}


@router.post("/requirements/generate")
def generate_requirements(payload: RequirementGenerationRequest, db: Session = Depends(get_db)):
    start_time = time.time()
    payload_dict = payload.model_dump()
    if not payload_dict.get("text") and payload.docId:
        stored_doc = metadata_store.get_document(payload.docId, db=db)
        if not stored_doc:
            raise HTTPException(status_code=404, detail="Document not found")
        payload_dict["text"] = stored_doc.get("raw_text") or ""

    if not payload_dict.get("text"):
        raise HTTPException(status_code=400, detail="Document text is required")

    result = ai_service.generate_requirements(payload_dict)
    if payload.docId and payload.projectId:
        metadata_store.save_requirements(payload.docId, payload.projectId, result, db=db)
    duration_ms = int((time.time() - start_time) * 1000)
    logger.info(
        "AI Requirements Extraction Completed | Project: %s | Doc: %s | Duration: %dms",
        payload.projectId,
        payload.docId,
        duration_ms,
    )
    return result


# ================= BUSINESS FLOW ENDPOINTS ================= #
@router.get("/business-flow/{document_id}")
def get_business_flow(document_id: str, db: Session = Depends(get_db)):
    flow = metadata_store.get_business_flow(document_id, db=db)
    if not flow:
        raise HTTPException(status_code=404, detail="Business flow not found")
    return {"documentId": document_id, "businessFlow": flow}


@router.get("/business-flow/{document_id}/versions")
def get_business_flow_versions(document_id: str, db: Session = Depends(get_db)):
    versions = metadata_store.get_business_flow_versions(document_id, db=db)
    return {"documentId": document_id, "versions": versions, "total": len(versions)}


@router.get("/business-flow/{document_id}/version/{version}")
def get_business_flow_by_version(document_id: str, version: int, db: Session = Depends(get_db)):
    flow = metadata_store.get_business_flow_by_version(document_id, version, db=db)
    if not flow:
        raise HTTPException(status_code=404, detail=f"Business flow version {version} not found")
    return {"documentId": document_id, "version": version, "businessFlow": flow}


@router.post("/business-flow/{document_id}/restore/{version}")
def restore_business_flow_version(document_id: str, version: int, db: Session = Depends(get_db)):
    target = metadata_store.get_business_flow_by_version(document_id, version, db=db)
    if not target:
        raise HTTPException(status_code=404, detail=f"Business flow version {version} not found to restore")
    restored = metadata_store.save_business_flow(
        document_id,
        target["projectId"],
        {
            "nodes": target["nodes"],
            "edges": target["edges"],
            "aiProvider": target.get("aiProvider"),
            "modelUsed": target.get("modelUsed"),
            "createdBy": f"Restored from Version {version}",
        },
        db=db,
    )
    return {"documentId": document_id, "restoredVersion": version, "newVersion": restored["version"], "businessFlow": restored}


@router.get("/business-flow/{document_id}/compare")
def compare_business_flow_versions(document_id: str, v1: int, v2: int, db: Session = Depends(get_db)):
    flow1 = metadata_store.get_business_flow_by_version(document_id, v1, db=db)
    flow2 = metadata_store.get_business_flow_by_version(document_id, v2, db=db)
    if not flow1 or not flow2:
        raise HTTPException(status_code=404, detail="One or both versions not found for comparison")
    
    nodes1 = {n["id"]: n for n in flow1.get("nodes", [])}
    nodes2 = {n["id"]: n for n in flow2.get("nodes", [])}
    added_nodes = [n for nid, n in nodes2.items() if nid not in nodes1]
    removed_nodes = [n for nid, n in nodes1.items() if nid not in nodes2]
    
    return {
        "documentId": document_id,
        "v1": v1,
        "v2": v2,
        "nodesCount": {"v1": len(flow1.get("nodes", [])), "v2": len(flow2.get("nodes", []))},
        "edgesCount": {"v1": len(flow1.get("edges", [])), "v2": len(flow2.get("edges", []))},
        "diff": {"addedNodes": added_nodes, "removedNodes": removed_nodes},
    }


@router.post("/business-flow/generate")
def generate_business_flow(payload: BusinessFlowGenerationRequest, db: Session = Depends(get_db)):
    if not payload.docId:
        raise HTTPException(status_code=400, detail="Document ID is required")
    if not payload.projectId:
        raise HTTPException(status_code=400, detail="Project ID is required")

    start_time = time.time()
    doc_id = payload.docId
    project_id = payload.projectId
    p_dict = payload.model_dump()
    p_dict = _enrich_payload_with_mysql_data(p_dict, project_id, doc_id, db=db)

    result = ai_service.generate_business_flow(p_dict)
    _validate_generated_artifact(result, "business flow")
    saved = metadata_store.save_business_flow(
        doc_id,
        project_id,
        {
            **result,
            "aiConfig": payload.aiConfig.model_dump() if payload.aiConfig else None,
        },
        db=db,
    )
    duration_ms = int((time.time() - start_time) * 1000)
    logger.info(
        "AI Regeneration Completed | Project: %s | Artifact: BusinessFlow | Version: %s | Provider: %s | Model: %s | Duration: %dms",
        project_id,
        saved.get("version"),
        saved.get("aiProvider"),
        saved.get("modelUsed"),
        duration_ms,
    )
    return saved


# ================= SOLUTION ARCHITECTURE ENDPOINTS ================= #
@router.get("/architecture/{document_id}")
def get_architecture(document_id: str, db: Session = Depends(get_db)):
    arch = metadata_store.get_architecture(document_id, db=db)
    if not arch:
        raise HTTPException(status_code=404, detail="Architecture not found")
    return {"documentId": document_id, "architecture": arch}


@router.get("/architecture/{document_id}/versions")
def get_architecture_versions(document_id: str, db: Session = Depends(get_db)):
    versions = metadata_store.get_architecture_versions(document_id, db=db)
    return {"documentId": document_id, "versions": versions, "total": len(versions)}


@router.get("/architecture/{document_id}/version/{version}")
def get_architecture_by_version(document_id: str, version: int, db: Session = Depends(get_db)):
    arch = metadata_store.get_architecture_by_version(document_id, version, db=db)
    if not arch:
        raise HTTPException(status_code=404, detail=f"Architecture version {version} not found")
    return {"documentId": document_id, "version": version, "architecture": arch}


@router.post("/architecture/{document_id}/restore/{version}")
def restore_architecture_version(document_id: str, version: int, db: Session = Depends(get_db)):
    target = metadata_store.get_architecture_by_version(document_id, version, db=db)
    if not target:
        raise HTTPException(status_code=404, detail=f"Architecture version {version} not found to restore")
    restored = metadata_store.save_architecture(
        document_id,
        target["projectId"],
        {
            "nodes": target["nodes"],
            "edges": target["edges"],
            "executive": target.get("executive"),
            "techStackDetails": target.get("techStackDetails"),
            "aiProvider": target.get("aiProvider"),
            "modelUsed": target.get("modelUsed"),
            "createdBy": f"Restored from Version {version}",
        },
        db=db,
    )
    return {"documentId": document_id, "restoredVersion": version, "newVersion": restored["version"], "architecture": restored}


@router.get("/architecture/{document_id}/compare")
def compare_architecture_versions(document_id: str, v1: int, v2: int, db: Session = Depends(get_db)):
    arch1 = metadata_store.get_architecture_by_version(document_id, v1, db=db)
    arch2 = metadata_store.get_architecture_by_version(document_id, v2, db=db)
    if not arch1 or not arch2:
        raise HTTPException(status_code=404, detail="One or both versions not found for comparison")
    
    nodes1 = {n["id"]: n for n in arch1.get("nodes", [])}
    nodes2 = {n["id"]: n for n in arch2.get("nodes", [])}
    added_nodes = [n for nid, n in nodes2.items() if nid not in nodes1]
    removed_nodes = [n for nid, n in nodes1.items() if nid not in nodes2]

    return {
        "documentId": document_id,
        "v1": v1,
        "v2": v2,
        "nodesCount": {"v1": len(arch1.get("nodes", [])), "v2": len(arch2.get("nodes", []))},
        "edgesCount": {"v1": len(arch1.get("edges", [])), "v2": len(arch2.get("edges", []))},
        "diff": {"addedNodes": added_nodes, "removedNodes": removed_nodes},
    }


@router.post("/architecture/generate")
def generate_architecture(payload: ArchitectureGenerationRequest, db: Session = Depends(get_db)):
    doc_id = payload.resolved_doc_id
    project_id = payload.resolved_project_id
    if not doc_id:
        raise HTTPException(status_code=400, detail="Document ID is required")
    if not project_id:
        raise HTTPException(status_code=400, detail="Project ID is required")

    start_time = time.time()
    p_dict = payload.model_dump()
    p_dict = _enrich_payload_with_mysql_data(p_dict, project_id, doc_id, db=db)
    previous_versions = metadata_store.get_architecture_versions(doc_id, db=db)
    if not previous_versions and doc_id != project_id:
        previous_versions = metadata_store.get_architecture_versions(project_id, db=db)

    p_dict["previousArchitectures"] = [
        {
            "version": version.get("version"),
            "templateId": (version.get("executive") or {}).get("templateId"),
            "themeId": (version.get("executive") or {}).get("themeId"),
            "layerNames": [layer.get("name") for layer in (version.get("executive") or {}).get("layers", [])[:7]],
            "decisionTitles": [decision.get("decision") for decision in (version.get("executive") or {}).get("architecturalDecisions", [])[:4]],
        }
        for version in previous_versions[:4]
    ]
    p_dict["variantSeed"] = f"{project_id}-{doc_id}-{len(previous_versions) + 1}"

    result = ai_service.generate_architecture(p_dict, payload.techStack)
    _validate_generated_artifact(result, "architecture")
    saved = metadata_store.save_architecture(
        doc_id,
        project_id,
        {
            **result,
            "aiConfig": payload.aiConfig.model_dump() if payload.aiConfig else None,
        },
        db=db,
    )
    duration_ms = int((time.time() - start_time) * 1000)
    logger.info(
        "AI Generation Completed & Committed | doc_id: %s | project_id: %s | record_id: %s | version: %s | provider: %s | duration: %dms",
        doc_id,
        project_id,
        saved.get("id"),
        saved.get("version"),
        saved.get("aiProvider"),
        duration_ms,
    )
    return saved


@router.post("/chat/query", response_model=ChatQueryResponse)
def query_chat(payload: ChatQueryRequest, db: Session = Depends(get_db)):
    return chat_service.chat(payload, db=db)


@router.post("/requirements/{document_id}/update")
def update_requirements(document_id: str, payload: RequirementUpdateRequest, db: Session = Depends(get_db)):
    data = payload.model_dump()
    project_id = data.get("projectId") or "default-project"
    existing = metadata_store.get_requirements(document_id, db=db) or {}
    # Partial edits must not replace the generated module list or other
    # requirement categories that are omitted by the update contract.
    merged = {**existing, **{key: value for key, value in data.items() if value is not None}}
    metadata_store.save_requirements(document_id, project_id, merged, db=db)
    return {"documentId": document_id, "status": "updated", "payload": merged}


@router.post("/business-flow/{document_id}/save")
def save_business_flow(document_id: str, payload: BusinessFlowRequest, db: Session = Depends(get_db)):
    data = payload.model_dump()
    project_id = data.get("projectId") or "default-project"
    saved = metadata_store.save_business_flow(document_id, project_id, data, db=db)
    return {"documentId": document_id, "status": "saved", "version": saved["version"], "payload": saved}


@router.post("/architecture/{document_id}/save")
def save_architecture(document_id: str, payload: ArchitectureRequest, db: Session = Depends(get_db)):
    data = payload.model_dump()
    doc_id = payload.resolved_doc_id or document_id
    project_id = payload.resolved_project_id or data.get("projectId") or data.get("project_id") or "default-project"
    saved = metadata_store.save_architecture(doc_id, project_id, data, db=db)
    return {"documentId": doc_id, "status": "saved", "version": saved["version"], "payload": saved}


@router.post("/reports/generate")
def generate_reports(payload: ReportGenerationRequest, db: Session = Depends(get_db)):
    start_time = time.time()
    payload_dict = payload.model_dump()
    project_id = payload.projectId or payload_dict.get("project", {}).get("id") or "default-project"
    enriched = _enrich_payload_with_mysql_data(payload_dict, project_id, None, db=db)
    result = ai_service.generate_executive_report(enriched)
    saved = metadata_store.save_report(
        project_id,
        {
            **result,
            "aiConfig": payload.aiConfig.model_dump() if payload.aiConfig else None,
        },
        db=db,
    )
    duration_ms = int((time.time() - start_time) * 1000)
    logger.info(
        "AI Regeneration Completed | Project: %s | Artifact: Report | Version: %s | Provider: %s | Model: %s | Duration: %dms",
        project_id,
        saved.get("version"),
        saved.get("aiProvider"),
        saved.get("modelUsed"),
        duration_ms,
    )
    return saved
