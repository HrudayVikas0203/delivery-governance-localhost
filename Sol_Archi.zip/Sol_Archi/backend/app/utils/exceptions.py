from __future__ import annotations


class AIProviderException(Exception):
    def __init__(
        self,
        message: str,
        provider: str = "Groq",
        retryable: bool = True,
        status_code: int = 429,
    ):
        super().__init__(message)
        self.message = message
        self.provider = provider
        self.retryable = retryable
        self.status_code = status_code
