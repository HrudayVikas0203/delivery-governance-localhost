from __future__ import annotations

from sqlalchemy import Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class SolutionArchitecture(Base):
    __tablename__ = "solution_architectures"
    __table_args__ = (
        Index("ix_solution_architectures_project_version", "project_id", "version"),
        Index("ix_solution_architectures_created_at", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    document_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    project_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    version: Mapped[int] = mapped_column(Integer, index=True, default=1, nullable=False)
    nodes_json: Mapped[str] = mapped_column(Text, nullable=False)
    edges_json: Mapped[str] = mapped_column(Text, nullable=False)
    executive_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    tech_stack_details_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    ai_provider: Mapped[str | None] = mapped_column(String(64), nullable=True)
    model_used: Mapped[str | None] = mapped_column(String(128), nullable=True)
    prompt_version: Mapped[str | None] = mapped_column(String(64), default="v1.0", nullable=True)
    created_by: Mapped[str] = mapped_column(String(128), default="AI Engine", nullable=False)
    generation_status: Mapped[str] = mapped_column(String(32), default="Success", nullable=False)
    created_at: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    updated_at: Mapped[str] = mapped_column(String(64), nullable=False)
