from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List
from uuid import uuid4

from app.database.storage import metadata_store
from app.rag.chroma_store import vector_store
from app.rag.embeddings import embedding_service
from app.schemas.documents import ChatQueryRequest, ChatQueryResponse, ChatSource
from app.services.llm_service import llm_service


logger = logging.getLogger(__name__)


from sqlalchemy.orm import Session


class ChatService:
    def chat(self, request: ChatQueryRequest, db: Session | None = None) -> ChatQueryResponse:
        started_at = time.perf_counter()
        now = datetime.now(timezone.utc).isoformat()

        metadata_store.save_chat_message(
            message_id=f"user-{uuid4()}",
            project_id=request.projectId,
            session_id=request.sessionId,
            role="user",
            content=request.question,
            created_at=now,
            db=db,
        )

        query_embedding = embedding_service.embed_query(request.question)
        raw_results = vector_store.query_project(request.projectId, query_embedding, request.topK)

        documents = raw_results.get("documents", [[]])[0]
        metadatas = raw_results.get("metadatas", [[]])[0]
        distances = raw_results.get("distances", [[]])[0]

        sources: List[ChatSource] = []
        for document, metadata, distance in zip(documents, metadatas, distances):
            similarity = max(0.0, 1.0 - float(distance or 0.0))
            if similarity < request.minScore:
                continue
            sources.append(
                ChatSource(
                    documentId=metadata["document_id"],
                    documentName=metadata["file_name"],
                    chunkNumber=int(metadata["chunk_number"]),
                    chunkContent=document,
                    similarityScore=round(similarity, 4),
                )
            )

        if not sources:
            response_text = "I couldn't find relevant information in the uploaded project documents."
            elapsed_ms = int((time.perf_counter() - started_at) * 1000)
            metadata_store.save_chat_message(
                message_id=f"assistant-{uuid4()}",
                project_id=request.projectId,
                session_id=request.sessionId,
                role="assistant",
                content=response_text,
                created_at=datetime.now(timezone.utc).isoformat(),
                db=db,
            )
            metadata_store.save_chat_log(
                log_id=f"log-{uuid4()}",
                project_id=request.projectId,
                session_id=request.sessionId,
                question=request.question,
                retrieved_chunks=[],
                similarity_scores=[],
                prompt="",
                ai_response=response_text,
                response_time_ms=elapsed_ms,
                created_at=datetime.now(timezone.utc).isoformat(),
                db=db,
            )
            logger.info("AI Chat fallback returned for project=%s question=%s", request.projectId, request.question)
            return ChatQueryResponse(answer=response_text, sources=[], responseTimeMs=elapsed_ms)

        prompt = self._build_prompt(request, sources)
        response_text = llm_service.chat_completion(
            provider=request.aiConfig.provider,
            model=request.aiConfig.moduleModels.aiChat or request.aiConfig.defaultModel,
            prompt=prompt,
            system_prompt=(
                "You are an Enterprise Solution Architect Copilot. "
                "Answer only from the retrieved project document chunks. "
                "If the answer is not supported by those chunks, say exactly: "
                "\"I couldn't find relevant information in the uploaded project documents.\""
            ),
            history=[item.model_dump() for item in request.history[-8:]],
            api_key=request.aiConfig.apiKey,
            endpoint_url=request.aiConfig.endpointUrl,
            temperature=request.aiConfig.temperature,
            max_tokens=request.aiConfig.maxTokens,
            response_format="Raw Text",
        )

        elapsed_ms = int((time.perf_counter() - started_at) * 1000)
        metadata_store.save_chat_message(
            message_id=f"assistant-{uuid4()}",
            project_id=request.projectId,
            session_id=request.sessionId,
            role="assistant",
            content=response_text,
            created_at=datetime.now(timezone.utc).isoformat(),
            db=db,
        )
        metadata_store.save_chat_log(
            log_id=f"log-{uuid4()}",
            project_id=request.projectId,
            session_id=request.sessionId,
            question=request.question,
            retrieved_chunks=[source.model_dump() for source in sources],
            similarity_scores=[source.similarityScore for source in sources],
            prompt=prompt,
            ai_response=response_text,
            response_time_ms=elapsed_ms,
            created_at=datetime.now(timezone.utc).isoformat(),
            db=db,
        )
        logger.info(
            "AI Chat project=%s question=%s chunks=%s scores=%s response_time_ms=%s",
            request.projectId,
            request.question,
            [source.chunkNumber for source in sources],
            [source.similarityScore for source in sources],
            elapsed_ms,
        )
        return ChatQueryResponse(answer=response_text, sources=sources, responseTimeMs=elapsed_ms)


    def _build_prompt(self, request: ChatQueryRequest, sources: List[ChatSource]) -> str:
        project_name = request.projectMetadata.get("name", request.projectId)
        project_description = request.projectMetadata.get("description", "")
        source_block = "\n\n".join(
            [
                f"[Document: {source.documentName} | Chunk: {source.chunkNumber} | Similarity: {source.similarityScore}]\n"
                f"{source.chunkContent}"
                for source in sources
            ]
        )
        return (
            f"Current project: {project_name}\n"
            f"Project description: {project_description}\n\n"
            f"Retrieved project document chunks:\n{source_block}\n\n"
            f"User question:\n{request.question}\n\n"
            "Respond with a concise answer grounded in the retrieved chunks. "
            "Reference the supporting document names naturally in the answer."
        )


chat_service = ChatService()
