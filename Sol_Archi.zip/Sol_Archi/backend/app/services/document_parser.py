from __future__ import annotations

import io
from typing import Tuple

from docx import Document as DocxDocument
from pypdf import PdfReader


class DocumentParser:
    def parse(self, file_name: str, file_bytes: bytes) -> Tuple[str, int, str]:
        suffix = file_name.lower().rsplit(".", 1)[-1] if "." in file_name else ""
        if suffix == "pdf":
            return self._parse_pdf(file_bytes)
        if suffix == "docx":
            return self._parse_docx(file_bytes)
        if suffix in ("txt", "md"):
            text = file_bytes.decode("utf-8", errors="ignore").strip()
            return text, 1, suffix.upper()
        raise ValueError("Unsupported document format. Only PDF, DOCX, TXT, and MD are supported.")


    def _parse_pdf(self, file_bytes: bytes) -> Tuple[str, int, str]:
        reader = PdfReader(io.BytesIO(file_bytes))
        pages = []
        for page in reader.pages:
            pages.append(page.extract_text() or "")
        return "\n\n".join(pages).strip(), len(reader.pages), "PDF"

    def _parse_docx(self, file_bytes: bytes) -> Tuple[str, int, str]:
        document = DocxDocument(io.BytesIO(file_bytes))
        paragraphs = [paragraph.text.strip() for paragraph in document.paragraphs if paragraph.text.strip()]
        return "\n\n".join(paragraphs).strip(), max(1, len(paragraphs)), "DOCX"


document_parser = DocumentParser()
