from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, Tuple

import requests

from app.config.settings import settings
from app.utils.exceptions import AIProviderException

logger = logging.getLogger(__name__)


class LLMService:
    @staticmethod
    def _mask_api_key(api_key: Optional[str]) -> str:
        """Return a non-secret identifier suitable for operational logs."""
        if not api_key:
            return "absent"
        if len(api_key) <= 8:
            return "*" * len(api_key)
        return f"{api_key[:4]}...{api_key[-4:]}"

    @staticmethod
    def _response_body(response: Optional[requests.Response]) -> str:
        """Read a bounded provider error body without risking an exception in logging."""
        if response is None:
            return ""
        try:
            body = response.text
        except Exception:
            return ""
        if not isinstance(body, str):
            return ""
        return body[:2_000]

    @staticmethod
    def _groq_error_for_status(status_code: int, error_body: str) -> AIProviderException:
        """Map only Groq's actual transport status to the matching caller error."""
        if status_code == 400:
            message, retryable = "Groq request rejected", False
        elif status_code == 401:
            message, retryable = "Groq API authentication failed", False
        elif status_code == 403:
            message, retryable = "Groq API access forbidden", False
        elif status_code == 404:
            message, retryable = "Groq model not found", False
        elif status_code == 429:
            message, retryable = "Groq rate limit exceeded", True
        elif 500 <= status_code <= 599:
            message, retryable = "Groq service unavailable", True
        else:
            message, retryable = f"Groq request failed (HTTP {status_code})", False
        # The upstream body is logged for diagnosis, but deliberately not returned
        # to the client because it may contain provider-specific implementation data.
        return AIProviderException(
            message=message,
            provider="Groq",
            retryable=retryable,
            status_code=status_code,
        )

    def _log_groq_diagnostic(
        self,
        *,
        model: str,
        status_code: Optional[int],
        error_body: str = "",
        api_key: Optional[str],
        key_source: str,
        request_key_supplied: bool,
    ) -> None:
        safe_error_body = error_body.replace(api_key, "[redacted]") if api_key else error_body
        logger.warning(
            "Groq diagnostic | provider=Groq | model=%s | http_status=%s | "
            "error_body=%s | api_key_present=%s | api_key_fingerprint=%s | "
            "api_key_source=%s | request_ai_config_key_supplied=%s",
            model,
            status_code if status_code is not None else "none",
            safe_error_body or "none",
            bool(api_key),
            self._mask_api_key(api_key),
            key_source,
            request_key_supplied,
        )

    def chat_completion(
        self,
        provider: str = "groq",
        model: str = "",
        prompt: str = "",
        *,
        system_prompt: str = "",
        history: Optional[List[Dict[str, str]]] = None,
        api_key: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        temperature: float = 0.2,
        max_tokens: int = 1200,
        response_format: Optional[str] = None,
    ) -> str:
        raw_provider = provider or settings.LLM_PROVIDER or "groq"
        primary_normalized = raw_provider.strip().lower()
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(history or [])
        messages.append({"role": "user", "content": prompt})

        # Groq is intentionally terminal: calling a different provider after a Groq
        # failure hides the original provider/status from the caller.
        priority_chain = self._build_provider_chain(primary_normalized)
        last_exception: Optional[Exception] = None

        for idx, target_provider in enumerate(priority_chain):
            try:
                if target_provider == "groq":
                    # The backend environment is authoritative for Groq so a stale
                    # browser-stored aiConfig.apiKey cannot override a rotated key.
                    environment_key = settings.ai.GROQ_API_KEY
                    effective_key = environment_key or api_key
                    key_source = "backend/.env" if environment_key else "request aiConfig"
                    effective_model = model if (primary_normalized == "groq" and model) else (settings.ai.GROQ_MODEL or "llama-3.3-70b-versatile")
                    if not effective_key:
                        if len(priority_chain) == 1:
                            raise ValueError("Groq requires an API key. Set GROQ_API_KEY in environment or settings.")
                        logger.warning("Groq API key missing. Skipping Groq in provider chain.")
                        continue
                    return self._groq(
                        api_key=effective_key,
                        key_source=key_source,
                        request_key_supplied=bool(api_key),
                        model=effective_model,
                        endpoint_url=(endpoint_url if primary_normalized == "groq" else None) or "https://api.groq.com/openai/v1/chat/completions",
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        response_format=response_format,
                    )

                if target_provider in {"google gemini", "google-gemini", "gemini"}:
                    effective_key = api_key if (primary_normalized in {"google gemini", "google-gemini", "gemini"} and api_key) else settings.ai.GEMINI_API_KEY
                    effective_model = model if (primary_normalized in {"google gemini", "google-gemini", "gemini"} and model) else (settings.ai.GEMINI_MODEL or "gemini-2.5-flash")
                    if not effective_key:
                        if len(priority_chain) == 1:
                            raise ValueError("Google Gemini requires an API key. Set GEMINI_API_KEY in environment or settings.")
                        logger.warning("Gemini API key missing. Skipping Gemini in provider chain.")
                        continue
                    return self._gemini(
                        api_key=effective_key,
                        endpoint_url=endpoint_url if primary_normalized in {"google gemini", "google-gemini", "gemini"} else None,
                        model=effective_model,
                        system_prompt=system_prompt,
                        prompt=prompt,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        response_format=response_format,
                    )

                if target_provider in {"openai", "custom endpoint", "custom-endpoint", "xai grok", "xai-grok", "ollama"}:
                    effective_key = api_key if (primary_normalized in {"openai", "custom endpoint", "custom-endpoint", "xai grok", "xai-grok", "ollama"} and api_key) else settings.ai.OPENAI_API_KEY
                    effective_model = model if (primary_normalized in {"openai", "custom endpoint", "custom-endpoint", "xai grok", "xai-grok", "ollama"} and model) else (settings.ai.OPENAI_MODEL or "gpt-4o")
                    effective_url = endpoint_url or self._default_endpoint(target_provider)
                    if not effective_key and "localhost" not in effective_url:
                        if len(priority_chain) == 1:
                            raise ValueError("OpenAI requires an API key. Set OPENAI_API_KEY in environment or settings.")
                        logger.warning("OpenAI API key missing. Skipping OpenAI in provider chain.")
                        continue
                    return self._openai_compatible(
                        endpoint_url=effective_url,
                        api_key=effective_key,
                        model=effective_model,
                        messages=messages,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        response_format=response_format,
                        provider_label=target_provider,
                    )

                if target_provider in {"anthropic claude", "anthropic-claude"}:
                    effective_key = api_key if (primary_normalized in {"anthropic claude", "anthropic-claude"} and api_key) else getattr(settings.ai, "ANTHROPIC_API_KEY", "")
                    if not effective_key:
                        raise ValueError("Anthropic Claude requires an API key.")
                    return self._anthropic(
                        api_key=effective_key,
                        endpoint_url=endpoint_url,
                        model=model or "claude-3-5-sonnet-20241022",
                        system_prompt=system_prompt,
                        history=history or [],
                        prompt=prompt,
                        temperature=temperature,
                        max_tokens=max_tokens,
                    )
            except (AIProviderException, requests.exceptions.HTTPError, requests.exceptions.RequestException, ValueError) as ex:
                last_exception = ex
                # Groq errors are always returned exactly as Groq classified them.
                # Never fall through to another provider after a Groq failure.
                if target_provider == "groq":
                    raise ex
                logger.warning(
                    "AI Provider '%s' failed (step %d/%d): %s. Switching to next configured provider...",
                    target_provider,
                    idx + 1,
                    len(priority_chain),
                    ex,
                )
                continue

        # If all providers in chain failed or were unconfigured
        if isinstance(last_exception, AIProviderException):
            raise last_exception
        
        raise AIProviderException(
            message="AI provider is temporarily rate limited.",
            provider=raw_provider.capitalize(),
            retryable=True,
            status_code=429,
        )

    def _build_provider_chain(self, primary_provider: str) -> List[str]:
        if primary_provider in {"groq"}:
            return ["groq"]
        if primary_provider in {"google gemini", "google-gemini", "gemini"}:
            return ["gemini", "openai"]
        if primary_provider in {"openai"}:
            return ["openai"]
        return [primary_provider]

    def _parse_retry_after(self, response: Optional[requests.Response]) -> Optional[float]:
        if response is None:
            return None
        header_val = response.headers.get("Retry-After") or response.headers.get("retry-after")
        if not header_val:
            return None
        try:
            return float(header_val)
        except (ValueError, TypeError):
            return None

    def _post_with_429_retry(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Dict[str, str],
        timeout: int = 60,
        max_retries: int = 3,
        provider_name: str = "Groq",
        model_name: str = "default",
    ) -> requests.Response:
        # Retry-After values can be several minutes. A synchronous API request must
        # never sleep for that duration; one short 429 retry is the most we allow.
        max_429_retries = 1
        max_429_wait_seconds = 2.0
        backoff = 2.0
        last_response: Optional[requests.Response] = None
        last_error: Optional[Exception] = None

        for attempt in range(max_retries + 1):
            try:
                start_time = time.time()
                response = requests.post(url, json=payload, headers=headers, timeout=timeout)
                duration_ms = int((time.time() - start_time) * 1000)
                last_response = response

                if response.status_code == 429:
                    retry_after = self._parse_retry_after(response)
                    wait_time = min(retry_after if retry_after is not None else backoff, max_429_wait_seconds)
                    logger.warning(
                        "HTTP 429 Rate Limit encountered | Provider: %s | Model: %s | Attempt %d/%d | URL: %s | Waiting: %.1fs...",
                        provider_name,
                        model_name,
                        attempt + 1,
                        max_retries + 1,
                        url,
                        wait_time,
                    )
                    if attempt < max_429_retries:
                        time.sleep(wait_time)
                        backoff *= 2.0
                        continue
                    else:
                        if provider_name.lower() == "groq":
                            error = self._groq_error_for_status(429, self._response_body(response))
                            error.provider_error_body = self._response_body(response)
                            error.provider_actual_status = 429
                            raise error
                        raise AIProviderException(
                            message=f"{provider_name} rate limit exceeded (HTTP 429).",
                            provider=provider_name,
                            retryable=True,
                            status_code=429,
                        )

                if response.status_code >= 400 and provider_name.lower() == "groq":
                    error = self._groq_error_for_status(response.status_code, self._response_body(response))
                    error.provider_error_body = self._response_body(response)
                    error.provider_actual_status = response.status_code
                    raise error

                response.raise_for_status()
                logger.info(
                    "HTTP request succeeded | Provider: %s | Model: %s | Status: %d | Duration: %dms | URL: %s",
                    provider_name,
                    model_name,
                    response.status_code,
                    duration_ms,
                    url,
                )
                return response

            except requests.exceptions.HTTPError as e:
                last_error = e
                status_code = e.response.status_code if e.response is not None else 500
                if status_code == 429:
                    retry_after = self._parse_retry_after(e.response)
                    wait_time = min(retry_after if retry_after is not None else backoff, max_429_wait_seconds)
                    logger.warning(
                        "HTTP 429 Rate Limit error | Provider: %s | Model: %s | Attempt %d/%d | URL: %s | Waiting: %.1fs...",
                        provider_name,
                        model_name,
                        attempt + 1,
                        max_retries + 1,
                        url,
                        wait_time,
                    )
                    if attempt < max_429_retries:
                        time.sleep(wait_time)
                        backoff *= 2.0
                        continue
                    else:
                        raise AIProviderException(
                            message=f"{provider_name} rate limit exceeded (HTTP 429).",
                            provider=provider_name,
                            retryable=True,
                            status_code=429,
                        )
                if attempt == max_retries:
                    break

            except requests.exceptions.RequestException as e:
                last_error = e
                if attempt < max_retries:
                    logger.warning(
                        "HTTP request exception | Provider: %s | Model: %s | Attempt %d/%d for URL %s: %s. Retrying in %.1fs...",
                        provider_name,
                        model_name,
                        attempt + 1,
                        max_retries + 1,
                        url,
                        e,
                        backoff,
                    )
                    time.sleep(backoff)
                    backoff *= 2.0
                    continue
                if attempt == max_retries:
                    break

        if isinstance(last_error, AIProviderException):
            raise last_error

        if provider_name.lower() == "groq" and last_response is None:
            if isinstance(last_error, requests.exceptions.Timeout):
                error = AIProviderException("Groq request timed out", provider="Groq", retryable=True, status_code=504)
            else:
                error = AIProviderException("Groq connection failed", provider="Groq", retryable=True, status_code=503)
            error.provider_error_body = str(last_error or "Network error")
            error.provider_actual_status = None
            raise error
        
        status_code = last_response.status_code if last_response is not None else 500
        if status_code == 429:
            if provider_name.lower() == "groq":
                error = self._groq_error_for_status(429, self._response_body(last_response))
                error.provider_error_body = self._response_body(last_response)
                error.provider_actual_status = 429
                raise error
            raise AIProviderException(
                message=f"{provider_name} rate limit exceeded (HTTP 429).",
                provider=provider_name,
                retryable=True,
                status_code=429,
            )

        if provider_name.lower() == "groq" and last_response is not None:
            error = self._groq_error_for_status(status_code, self._response_body(last_response))
            error.provider_error_body = self._response_body(last_response)
            error.provider_actual_status = status_code
            raise error

        raise AIProviderException(
            message=f"{provider_name} request failed: {last_error or 'Network error'}",
            provider=provider_name,
            retryable=False,
            status_code=status_code,
        )

    def _groq(
        self,
        *,
        api_key: Optional[str],
        key_source: str,
        request_key_supplied: bool,
        model: str,
        endpoint_url: str,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        response_format: Optional[str],
    ) -> str:
        effective_key = api_key or settings.ai.GROQ_API_KEY
        effective_model = model or settings.ai.GROQ_MODEL or "llama-3.3-70b-versatile"
        if not effective_key:
            raise ValueError("Groq requires an API key. Set GROQ_API_KEY in environment or settings.")

        logger.info(
            "Groq request configuration | provider=Groq | model=%s | api_key_present=%s | "
            "api_key_fingerprint=%s | api_key_source=%s | request_ai_config_key_supplied=%s",
            effective_model,
            bool(effective_key),
            self._mask_api_key(effective_key),
            key_source,
            request_key_supplied,
        )

        payload: Dict[str, Any] = {
            "model": effective_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format and response_format.lower() == "json object":
            payload["response_format"] = {"type": "json_object"}

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {effective_key}",
        }

        try:
            response = self._post_with_429_retry(
                endpoint_url,
                payload=payload,
                headers=headers,
                timeout=settings.app.HTTP_TIMEOUT_SECONDS,
                max_retries=1,
                provider_name="Groq",
                model_name=effective_model,
            )
        except AIProviderException as ex:
            self._log_groq_diagnostic(
                model=effective_model,
                status_code=getattr(ex, "provider_actual_status", ex.status_code),
                error_body=getattr(ex, "provider_error_body", ex.message),
                api_key=effective_key,
                key_source=key_source,
                request_key_supplied=request_key_supplied,
            )
            raise
        except requests.exceptions.Timeout as ex:
            self._log_groq_diagnostic(model=effective_model, status_code=None, error_body=str(ex), api_key=effective_key, key_source=key_source, request_key_supplied=request_key_supplied)
            raise AIProviderException("Groq request timed out", provider="Groq", retryable=True, status_code=504) from ex
        except requests.exceptions.RequestException as ex:
            self._log_groq_diagnostic(model=effective_model, status_code=None, error_body=str(ex), api_key=effective_key, key_source=key_source, request_key_supplied=request_key_supplied)
            raise AIProviderException("Groq connection failed", provider="Groq", retryable=True, status_code=503) from ex

        try:
            data = response.json()
        except (ValueError, requests.exceptions.JSONDecodeError) as ex:
            self._log_groq_diagnostic(model=effective_model, status_code=response.status_code, error_body="Invalid JSON response from Groq", api_key=effective_key, key_source=key_source, request_key_supplied=request_key_supplied)
            raise AIProviderException("Groq returned an invalid response", provider="Groq", retryable=True, status_code=502) from ex
        usage = data.get("usage", {})
        content = data.get("choices", [{}])[0].get("message", {}).get("content")
        if not content:
            self._log_groq_diagnostic(model=effective_model, status_code=response.status_code, error_body="Groq response contained no message content", api_key=effective_key, key_source=key_source, request_key_supplied=request_key_supplied)
            raise AIProviderException("Groq returned an empty response", provider="Groq", retryable=True, status_code=502)

        logger.info(
            "Groq API Execution Completed | Provider: Groq | Model: %s | HTTP 200 | Tokens: prompt=%s completion=%s total=%s",
            effective_model,
            usage.get("prompt_tokens"),
            usage.get("completion_tokens"),
            usage.get("total_tokens"),
        )
        return content

    def _default_endpoint(self, provider: str) -> str:
        if provider == "xai-grok":
            return "https://api.x.ai/v1/chat/completions"
        if provider == "ollama":
            return "http://localhost:11434/v1/chat/completions"
        return "https://api.openai.com/v1/chat/completions"

    def _openai_compatible(
        self,
        *,
        endpoint_url: str,
        api_key: Optional[str],
        model: str,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
        response_format: Optional[str],
        provider_label: str = "OpenAI",
    ) -> str:
        if not endpoint_url:
            raise ValueError("Missing endpoint URL for OpenAI-compatible request.")
        if not api_key and "localhost" not in endpoint_url:
            raise ValueError(f"Missing API key for {provider_label} request.")

        payload: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format and response_format.lower() == "json object":
            payload["response_format"] = {"type": "json_object"}

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        response = self._post_with_429_retry(
            endpoint_url,
            payload=payload,
            headers=headers,
            timeout=settings.app.HTTP_TIMEOUT_SECONDS,
            max_retries=3,
            provider_name=provider_label.capitalize(),
            model_name=model,
        )
        data = response.json()
        usage = data.get("usage", {})
        content = data.get("choices", [{}])[0].get("message", {}).get("content")
        if not content:
            raise ValueError(f"{provider_label} returned an empty response.")
        logger.info(
            "%s API Execution Completed | Provider: %s | Model: %s | HTTP 200 | Tokens: prompt=%s completion=%s total=%s",
            provider_label.capitalize(),
            provider_label.capitalize(),
            model,
            usage.get("prompt_tokens"),
            usage.get("completion_tokens"),
            usage.get("total_tokens"),
        )
        return content

    def _anthropic(
        self,
        *,
        api_key: Optional[str],
        endpoint_url: Optional[str],
        model: str,
        system_prompt: str,
        history: List[Dict[str, str]],
        prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        if not api_key:
            raise ValueError("Anthropic Claude requires an API key.")
        url = endpoint_url or "https://api.anthropic.com/v1/messages"
        payload = {
            "model": model,
            "system": system_prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                *[
                    {"role": "assistant" if item["role"] == "assistant" else "user", "content": item["content"]}
                    for item in history
                ],
                {"role": "user", "content": prompt},
            ],
        }
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        response = self._post_with_429_retry(
            url,
            payload=payload,
            headers=headers,
            timeout=settings.app.HTTP_TIMEOUT_SECONDS,
            max_retries=3,
            provider_name="Anthropic",
            model_name=model,
        )
        data = response.json()
        usage = data.get("usage", {})
        logger.info(
            "Anthropic API Execution Completed | Provider: Anthropic | Model: %s | HTTP 200 | Tokens: %s",
            model,
            usage,
        )
        return data["content"][0]["text"]

    def _gemini(
        self,
        *,
        api_key: Optional[str],
        endpoint_url: Optional[str],
        model: str,
        system_prompt: str,
        prompt: str,
        temperature: float,
        max_tokens: int,
        response_format: Optional[str],
    ) -> str:
        if not api_key:
            raise ValueError("Google Gemini requires an API key. Pass api_key or configure GEMINI_API_KEY in environment or settings.")
        effective_model = model or "gemini-2.5-flash"
        url = endpoint_url or f"https://generativelanguage.googleapis.com/v1beta/models/{effective_model}:generateContent?key={api_key}"
        payload: Dict[str, Any] = {
            "contents": [{"parts": [{"text": f"{system_prompt}\n\n{prompt}"}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }
        if response_format and response_format.lower() == "json object":
            payload["generationConfig"]["responseMimeType"] = "application/json"

        response = self._post_with_429_retry(
            url,
            payload=payload,
            headers={"Content-Type": "application/json"},
            timeout=settings.app.HTTP_TIMEOUT_SECONDS,
            max_retries=3,
            provider_name="Gemini",
            model_name=effective_model,
        )
        data = response.json()
        usage = data.get("usageMetadata", {})
        logger.info(
            "Gemini API Execution Completed | Provider: Gemini | Model: %s | HTTP 200 | Tokens: prompt=%s completion=%s total=%s",
            effective_model,
            usage.get("promptTokenCount"),
            usage.get("candidatesTokenCount"),
            usage.get("totalTokenCount"),
        )
        return data["candidates"][0]["content"]["parts"][0]["text"]


llm_service = LLMService()
