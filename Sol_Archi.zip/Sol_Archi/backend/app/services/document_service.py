from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict
from uuid import uuid4

from fastapi import HTTPException, status

from app.config.settings import settings
from app.database.storage import StoredDocumentRecord, metadata_store
from app.rag.chunking import chunk_payloads
from app.rag.chroma_store import vector_store
from app.rag.embeddings import embedding_service
from app.schemas.documents import UploadResponse
from app.services.document_parser import document_parser


from sqlalchemy.orm import Session


class DocumentService:
    def upload_document(self, project_id: str, file_name: str, file_bytes: bytes, db: Session | None = None) -> UploadResponse:
        sanitized_name = Path(file_name).name
        extension = sanitized_name.rsplit(".", 1)[-1].lower() if "." in sanitized_name else ""

        if not sanitized_name:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="File name is required.")
        if extension not in settings.ALLOWED_UPLOAD_EXTENSIONS:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported file type '{extension or 'unknown'}'. Allowed types: {sorted(settings.ALLOWED_UPLOAD_EXTENSIONS)}",
            )

        max_upload_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
        if len(file_bytes) > max_upload_bytes:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File exceeds the maximum upload size of {settings.MAX_UPLOAD_SIZE_MB} MB.",
            )

        document_id = f"doc-{uuid4().hex[:12]}"
        now = datetime.now(timezone.utc).isoformat()
        file_type = extension.upper() if extension else "UNKNOWN"
        file_size_bytes = len(file_bytes)
        project_dir = Path(settings.UPLOAD_DIR) / project_id
        project_dir.mkdir(parents=True, exist_ok=True)
        saved_path = project_dir / f"{document_id}-{sanitized_name}"

        metadata_store.upsert_document(
            StoredDocumentRecord(
                document_id=document_id,
                project_id=project_id,
                file_name=sanitized_name,
                file_type=file_type,
                file_size=file_size_bytes,
                file_path=str(saved_path),
                uploaded_at=now,
                status="Processing",
            ),
            db=db,
        )

        try:
            saved_path.write_bytes(file_bytes)
            raw_text, page_count, normalized_type = document_parser.parse(sanitized_name, file_bytes)
            sha256 = hashlib.sha256(file_bytes).hexdigest()
            chunks = chunk_payloads(project_id, document_id, sanitized_name, raw_text)
            created_at = datetime.now(timezone.utc).isoformat()
            for chunk in chunks:
                chunk["created_at"] = created_at

            embeddings = embedding_service.embed_texts([chunk["content"] for chunk in chunks])
            vector_store.upsert_chunks(chunks, embeddings)
            metadata_store.replace_document_chunks(document_id, project_id, chunks, db=db)

            metadata_store.upsert_document(
                StoredDocumentRecord(
                    document_id=document_id,
                    project_id=project_id,
                    file_name=sanitized_name,
                    file_type=normalized_type,
                    file_size=file_size_bytes,
                    file_path=str(saved_path),
                    uploaded_at=now,
                    status="Completed",
                    page_count=page_count,
                    chunk_count=len(chunks),
                    sha256=sha256,
                    raw_text=raw_text,
                ),
                db=db,
            )
        except Exception as exc:
            metadata_store.upsert_document(
                StoredDocumentRecord(
                    document_id=document_id,
                    project_id=project_id,
                    file_name=sanitized_name,
                    file_type=file_type,
                    file_size=file_size_bytes,
                    file_path=str(saved_path),
                    uploaded_at=now,
                    status="Failed",
                    error_message=str(exc),
                ),
                db=db,
            )
            raise

        return UploadResponse(
            documentId=document_id,
            name=sanitized_name,
            type=normalized_type,
            size=f"{(file_size_bytes / (1024 * 1024)):.1f} MB",
            uploadedAt=now,
            status="Completed",
        )

    def get_processing_status(self, document_id: str, db: Session | None = None) -> Dict[str, Any]:
        record = metadata_store.get_document(document_id, db=db)
        if not record:
            return {
                "documentId": document_id,
                "status": "NotFound",
                "confidence": 0,
                "errorDetails": "Document not found",
            }
        return {
            "documentId": document_id,
            "status": record["status"],
            "confidence": 100 if record["status"] == "Completed" else 0,
            "errorDetails": record["error_message"] or None,
        }

    def list_project_documents(self, project_id: str, db: Session | None = None) -> list[Dict[str, Any]]:
        records = metadata_store.get_project_documents(project_id, db=db)
        return [
            {
                "documentId": record["document_id"],
                "name": record["file_name"],
                "type": record["file_type"],
                "size": f"{(record['file_size'] / (1024 * 1024)):.1f} MB",
                "uploadedAt": record["uploaded_at"],
                "status": record["status"],
                "pageCount": record["page_count"],
                "chunkCount": record["chunk_count"],
            }
            for record in records
        ]

