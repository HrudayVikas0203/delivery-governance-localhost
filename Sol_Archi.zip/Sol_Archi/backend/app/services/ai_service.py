from __future__ import annotations

import json
import logging
from uuid import uuid4
from typing import Any, Dict

from app.services.llm_service import llm_service

logger = logging.getLogger(__name__)


class AIService:
    EXECUTIVE_TEMPLATES = [
        "enterpriseConsulting",
        "executiveBlueprint",
        "capabilityMap",
        "cloudNativePlatform",
        "aiPlatformArchitecture",
        "digitalTransformation",
        "technologyCapabilityMatrix",
        "enterpriseOperatingModel",
        "referenceArchitecture",
        "solutionDeliveryFramework",
        "modernEnterprisePlatform",
        "executiveStrategyView",
        "technologyReferenceArchitecture",
        "applicationModernization",
        "platformArchitecture",
        "dataGovernanceArchitecture",
        "integrationArchitecture",
        "businessTransformationRoadmap",
        "microservicesArchitecture",
        "eventDrivenArchitecture",
        "hybridCloudArchitecture",
        "enterpriseAiEcosystem",
        "businessCapabilityModel",
        "operatingArchitecture",
        "targetStateArchitecture",
    ]

    EXECUTIVE_THEMES = [
        "corporateBlue",
        "executiveNavy",
        "azure",
        "emerald",
        "purple",
        "slateGray",
        "ibmStyle",
        "awsStyle",
        "sapStyle",
        "oracleStyle",
        "darkExecutive",
        "monochrome",
    ]

    def generate_requirements(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        prompt = (
            "Extract structured requirements from the provided document text and return valid JSON.\n\n"
            f"Document text:\n{payload.get('text', '')[:18000]}"
        )
        content = llm_service.chat_completion(
            provider=payload.get("aiConfig", {}).get("provider", "OpenAI"),
            model=payload.get("aiConfig", {}).get("moduleModels", {}).get("requirementExtraction")
            or payload.get("aiConfig", {}).get("defaultModel", "gpt-4o"),
            prompt=prompt,
            system_prompt=(
                "You are an enterprise business analyst. Return JSON only with keys: "
                "overview, businessObjectives, projectScope, stakeholders, actors, modules, "
                "functional, nonFunctional, businessRules, assumptions, constraints, "
                "externalSystems, risks, dependencies."
            ),
            api_key=payload.get("aiConfig", {}).get("apiKey"),
            endpoint_url=payload.get("aiConfig", {}).get("endpointUrl"),
            temperature=payload.get("aiConfig", {}).get("temperature", 0.2),
            max_tokens=payload.get("aiConfig", {}).get("maxTokens", 2500),
            response_format="JSON Object",
        )
        return self._parse_json(content)

    def generate_business_flow(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        reqs = payload.get("requirements") or payload
        project = payload.get("project") or {}
        ai_config = payload.get("aiConfig") or reqs.get("aiConfig") or {}

        func_list = reqs.get("functional") or []
        nfr_list = reqs.get("nonFunctional") or []

        prompt = (
            "Synthesize a fresh, dynamic Business Process Flow diagram from the following latest project requirements and metadata.\n\n"
            f"Project Name: {project.get('name', 'Enterprise System')}\n"
            f"Description / Scope: {project.get('description', '')}\n"
            f"Overview: {reqs.get('overview', '')}\n"
            f"Business Objectives: {reqs.get('businessObjectives', [])}\n"
            f"Business Rules: {reqs.get('businessRules', [])}\n"
            f"Actors: {reqs.get('actors', [])}\n"
            f"Business Modules: {reqs.get('modules', [])}\n"
            f"Functional Requirements ({len(func_list)}): {func_list[:10]}\n"
            f"Non-Functional Requirements: {nfr_list[:5]}\n\n"
            "Generate JSON with keys 'nodes' and 'edges' for React Flow diagram.\n"
            "Each node must have 'id', 'type', 'data' (with 'label' string), 'position' ({'x': number, 'y': number}).\n"
            "Each edge must have 'id', 'source', 'target', 'label' (optional)."
        )

        content = llm_service.chat_completion(
            provider=ai_config.get("provider", "OpenAI"),
            model=ai_config.get("moduleModels", {}).get("businessFlow") or ai_config.get("defaultModel", "gpt-4o-mini"),
            prompt=prompt,
            system_prompt="You generate business flow diagrams as JSON. Do not use retrieval or hardcoded static templates.",
            api_key=ai_config.get("apiKey"),
            endpoint_url=ai_config.get("endpointUrl"),
            temperature=ai_config.get("temperature", 0.2),
            max_tokens=ai_config.get("maxTokens", 1800),
            response_format="JSON Object",
        )
        return self._parse_json(content)

    def generate_architecture(self, payload: Dict[str, Any], tech_stack: str) -> Dict[str, Any]:
        reqs = payload.get("requirements") or payload
        project = payload.get("project") or {}
        tech_details = payload.get("techStackDetails") or project.get("techStackDetails") or {}
        ai_config = payload.get("aiConfig") or reqs.get("aiConfig") or {}
        previous_architectures = payload.get("previousArchitectures") or []

        func_list = reqs.get("functional") or []
        nfr_list = reqs.get("nonFunctional") or []
        external_systems = reqs.get("externalSystems") or []
        business_modules = reqs.get("modules") or []
        actors = reqs.get("actors") or []
        from app.utils.exceptions import AIProviderException

        variant_seed = uuid4().hex[:12]
        prompt = (
            "Generate an enterprise Solution Architecture package containing BOTH a Technical topology diagram AND an Executive Solution Architecture for presentation.\n"
            "STRICT DELIVERABLE CONSTRAINTS (MANDATORY):\n"
            "1. You MUST generate EXACTLY 6 Enterprise Architecture Layers tailored to the project.\n"
            "2. Each layer object MUST contain an 'items' array with 1 to 4 distinct component objects. Prefer four only when they are meaningful; do not add filler components.\n"
            "3. 'architecturalDecisions': Array of 3 to 4 distinct objects ({id, decision, whyChosen, category}).\n"
            "4. 'businessValue': Array of 3 to 4 distinct objects ({id, title, description, metric}).\n"
            "5. 'technologyHighlights': Array of 3 to 4 distinct objects ({id, title, summary, badge}).\n"
            "6. CRITICAL VARIATION INSTRUCTION: Every generation MUST produce a genuinely NEW and DISTINCT architecture structure tailored to the project requirements.\n"
            f"Prior Architectures Generated To Avoid Repeating: {previous_architectures[:4]}\n\n"
            f"Project Name: {project.get('name', 'Enterprise System')}\n"
            f"Target Tech Stack: {tech_stack or project.get('selectedTechStack', 'Modern Cloud Native')}\n"
            f"Detailed Stack Config: {tech_details}\n"
            f"Overview: {reqs.get('overview', '')}\n"
            f"Business Objectives: {reqs.get('businessObjectives', [])}\n"
            f"Actors: {actors[:10]}\n"
            f"Business Modules: {business_modules[:12]}\n"
            f"Functional Requirements: {func_list[:12]}\n"
            f"Non-Functional Requirements: {nfr_list[:6]}\n"
            f"External Systems / Integrations: {external_systems[:10]}\n"
            f"Variant Seed: {variant_seed}\n\n"
            "Generate JSON with keys:\n"
            "1. 'nodes': Array of Technical React Flow nodes ({id, type, data: {label, sublabel, layer, icon, technology}, position: {x, y}}).\n"
            "2. 'edges': Array of Technical connections ({id, source, target, label}).\n"
            "3. 'executive': Object with:\n"
            "   - 'templateId': 'enterpriseConsulting'\n"
            "   - 'themeId': 'corporateBlue'\n"
            "   - 'title': 'Solution Architecture - ' + project name.\n"
            "   - 'subtitle': concise subheading.\n"
            "   - 'layoutNarrative': short sentence describing the architecture flow.\n"
            "   - 'generatedVariantId': reuse the Variant Seed value.\n"
            "   - 'layers': Array of EXACTLY 6 Enterprise Architecture Layers tailored to the project. Vary names and component breakdown across runs. Each layer object MUST have 'id', 'name', 'category', 'summary', and 'items' (1 to 4 meaningful component objects per layer).\n"
            "     Each item object must contain:\n"
            "       - 'id': string\n"
            "       - 'name': concise component name (maximum 54 characters)\n"
            "       - 'businessPurpose': concise explanation (maximum 88 characters)\n"
            "       - 'technicalResponsibility': array of 1-2 specific responsibility bullets, each maximum 88 characters\n"
            "       - 'supportingTechnology': concrete framework / service name (e.g., 'React 18', 'Azure OpenAI', 'PostgreSQL 16', 'FastAPI')\n"
            "       - 'icon': Lucide icon name (e.g., 'Users', 'Crown', 'Brain', 'Cpu', 'Shield', 'Network', 'Database', 'HardDrive', 'Boxes', 'Activity', 'Key', 'Radio', 'Search', 'Terminal')\n"
            "       - 'badge': short category badge\n"
            "   - 'architecturalDecisions': Array of 5 to 6 distinct objects ({id, decision, whyChosen, category}).\n"
            "   - 'businessValue': Array of 5 to 6 distinct objects ({id, title, description, metric}).\n"
            "   - 'technologyHighlights': Array of 5 to 6 distinct objects ({id, title, summary, badge}).\n"
            "4. 'techStackDetails': Dict of stack components."
        )

        try:
            content = llm_service.chat_completion(
                provider=ai_config.get("provider", "groq"),
                model=ai_config.get("moduleModels", {}).get("architecture") or ai_config.get("defaultModel", ""),
                prompt=prompt,
                system_prompt=(
                    "You are a Senior Principal Enterprise Solutions Architect. "
                    "Return JSON only. Every regeneration request MUST produce a uniquely structured, compact, presentation-ready solution architecture deliverable. "
                    "Vary layer names, component groupings, architectural decisions, business outcomes, and technology highlights while maintaining high technical rigor. "
                    "Always generate EXACTLY 6 layers with one to four detailed, meaningful component cards per layer; never use filler cards."
                ),
                api_key=ai_config.get("apiKey"),
                endpoint_url=ai_config.get("endpointUrl"),
                temperature=max(ai_config.get("temperature", 0.2), 0.75),
                max_tokens=min(max(ai_config.get("maxTokens", 2600), 2600), 3200),
                response_format="JSON Object",
            )
            parsed = self._parse_json(content)
            if self._validate_architecture_payload(parsed):
                logger.info("AI Architecture generation passed compact architecture validation on single call.")
                return parsed
            # Do not manufacture a diagram from fallback/static content. The caller
            # must receive a failed generation when the provider output is invalid.
            raise ValueError("AI returned an incomplete solution architecture payload.")
        except AIProviderException:
            raise
        except Exception as ex:
            logger.error("AI Architecture generation failed unexpectedly: %s", ex)
            raise AIProviderException(
                message=f"Architecture generation failed: {str(ex)}",
                provider=ai_config.get("provider", "Groq"),
                retryable=True,
                status_code=500,
            )


    def _validate_architecture_payload(self, parsed: Dict[str, Any]) -> bool:
        if not isinstance(parsed, dict):
            return False
        nodes = parsed.get("nodes")
        edges = parsed.get("edges")
        executive = parsed.get("executive")
        if not isinstance(nodes, list) or len(nodes) < 4:
            return False
        if not isinstance(edges, list) or len(edges) < 3:
            return False
        if not isinstance(executive, dict):
            return False

        layers = executive.get("layers")
        decisions = executive.get("architecturalDecisions")
        values = executive.get("businessValue")
        highlights = executive.get("technologyHighlights")

        if not isinstance(layers, list) or len(layers) < 6:
            return False
        if not isinstance(decisions, list) or len(decisions) < 3:
            return False
        if not isinstance(values, list) or len(values) < 3:
            return False
        if not isinstance(highlights, list) or len(highlights) < 3:
            return False

        for layer in layers[:6]:
            if not isinstance(layer, dict):
                return False
            items = layer.get("items")
            if not isinstance(items, list) or not 1 <= len(items) <= 4:
                return False

        return True

    def _ensure_6x6_architecture_guarantee(self, parsed: Dict[str, Any], project_name: str) -> Dict[str, Any]:
        if not isinstance(parsed, dict):
            parsed = {}
        executive = parsed.get("executive") or {}
        if not isinstance(executive, dict):
            executive = {}
            parsed["executive"] = executive

        raw_layers = executive.get("layers") or []
        fallback_layers = [
            ("Layer 1: User & Experience Domain", "Users & Actors", "Client-facing workspaces, executive dashboards, and developer portals."),
            ("Layer 2: Business Capabilities & Core Engine", "Business Core", "Requirement extraction, process modeling, and governance workflows."),
            ("Layer 3: Core AI Platform & Intelligence", "AI Engine", "LLM orchestrators, hybrid RAG vector indices, and guardrail pipelines."),
            ("Layer 4: Integration & Gateway Layer", "Integration Bus", "API management, async event streaming, and enterprise SSO adapters."),
            ("Layer 5: Enterprise Data & Persistence Platform", "Data Platform", "Relational database clusters, vector stores, and object vaults."),
            ("Layer 6: Infrastructure & Observability Platform", "Infrastructure", "Container microservices runtime, telemetry, and automated release gates.")
        ]

        normalized_layers = []
        for l_idx in range(6):
            if l_idx < len(raw_layers) and isinstance(raw_layers[l_idx], dict):
                layer_obj = raw_layers[l_idx]
            else:
                f_name, f_cat, f_sum = fallback_layers[l_idx]
                layer_obj = {
                    "id": f"layer-{l_idx + 1}",
                    "name": f_name,
                    "category": f_cat,
                    "summary": f_sum,
                    "items": []
                }

            items = layer_obj.get("items") if isinstance(layer_obj.get("items"), list) else []
            fallback_items = [
                {"name": "Executive Dashboard", "businessPurpose": "C-level strategy & ROI analytics", "supportingTechnology": "React SPA", "icon": "Crown", "badge": "Leadership"},
                {"name": "Solution Architect Workbench", "businessPurpose": "Blueprint design & stack validation", "supportingTechnology": "React Flow", "icon": "UserCog", "badge": "Architect"},
                {"name": "Requirement Extraction Engine", "businessPurpose": "BRD parsing & specification extraction", "supportingTechnology": "FastAPI NLP", "icon": "FileText", "badge": "Capability"},
                {"name": "AI Model Orchestrator", "businessPurpose": "Multi-provider model routing & cost optimization", "supportingTechnology": "Azure OpenAI", "icon": "Brain", "badge": "AI Core"},
                {"name": "Enterprise API Gateway", "businessPurpose": "Centralized API endpoint routing & rate limiting", "supportingTechnology": "Azure APIM", "icon": "Network", "badge": "Perimeter"},
                {"name": "Relational Database Cluster", "businessPurpose": "ACID transactional storage of project state", "supportingTechnology": "PostgreSQL 16", "icon": "Database", "badge": "Relational DB"}
            ]

            while len(items) < 4:
                idx_f = len(items) % len(fallback_items)
                fb = fallback_items[idx_f]
                items.append({
                    "id": f"item-{l_idx + 1}-{len(items) + 1}",
                    "name": f"{fb['name']}",
                    "businessPurpose": fb["businessPurpose"],
                    "technicalResponsibility": ["Service Processing & Validation", "Event Dispatching", "Telemetry Audit Logging"],
                    "supportingTechnology": fb["supportingTechnology"],
                    "icon": fb["icon"],
                    "badge": fb["badge"]
                })
            layer_obj["items"] = items[:4]
            normalized_layers.append(layer_obj)

        executive["layers"] = normalized_layers
        parsed["executive"] = executive
        return parsed

    def generate_executive_report(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        project = payload.get("project") or {}
        reqs = payload.get("requirements") or {}
        flow = payload.get("businessFlow") or {}
        arch = payload.get("architecture") or {}
        ai_config = payload.get("aiConfig") or {}

        func_list = reqs.get("functional") or []
        nfr_list = reqs.get("nonFunctional") or []

        prompt = (
            f"Generate a multi-section Executive Solution Report for project '{project.get('name', 'Enterprise Project')}'.\n\n"
            f"Project Details: {project}\n"
            f"Requirements Overview: {reqs.get('overview', '')}\n"
            f"Business Objectives: {reqs.get('businessObjectives', [])}\n"
            f"Functional Requirements: {func_list[:5]}\n"
            f"Non-Functional Requirements: {nfr_list[:5]}\n"
            f"Business Process Flow: {flow.get('nodes', []) if isinstance(flow, dict) else []}\n"
            f"Solution Architecture: {arch.get('nodes', []) if isinstance(arch, dict) else []}\n"
            "Return JSON with a single key 'sections' containing an array of section objects, each with 'title' and 'content' markdown strings."
        )

        content = llm_service.chat_completion(
            provider=ai_config.get("provider", "OpenAI"),
            model=ai_config.get("moduleModels", {}).get("reports") or ai_config.get("defaultModel", "gpt-4o"),
            prompt=prompt,
            system_prompt=(
                "You are a Principal Enterprise Solutions Architect writing a client-ready executive solution report. "
                "Synthesize project details, requirements, architecture, and business flow into comprehensive, professional Markdown report sections. "
                "Return JSON with key 'sections' containing array of objects with keys 'title' and 'content'."
            ),
            api_key=ai_config.get("apiKey"),
            endpoint_url=ai_config.get("endpointUrl"),
            temperature=ai_config.get("temperature", 0.2),
            max_tokens=ai_config.get("maxTokens", 3000),
            response_format="JSON Object",
        )
        return self._parse_json(content)

    def _parse_json(self, content: str) -> Dict[str, Any]:
        cleaned = content.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.replace("```json", "").replace("```", "").strip()
        return json.loads(cleaned)
