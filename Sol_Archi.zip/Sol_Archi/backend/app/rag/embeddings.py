from __future__ import annotations

import hashlib
import math
import threading
from typing import Dict, Iterable, List


class EmbeddingService:
    def __init__(self, dimension: int = 384) -> None:
        self.dimension = dimension
        self._cache: Dict[str, List[float]] = {}
        self._lock = threading.Lock()

    def embed_texts(self, texts: Iterable[str]) -> List[List[float]]:
        return [self._embed_with_cache(text) for text in texts]

    def embed_query(self, text: str) -> List[float]:
        return self._embed_with_cache(text)

    def _embed_with_cache(self, text: str) -> List[float]:
        key = hashlib.sha256(text.encode("utf-8")).hexdigest()
        with self._lock:
            cached = self._cache.get(key)
        if cached is not None:
            return cached

        vector = self._hashing_embedding(text)
        with self._lock:
            self._cache[key] = vector
        return vector

    def _hashing_embedding(self, text: str) -> List[float]:
        vector = [0.0] * self.dimension
        tokens = [token for token in text.lower().split() if token]
        for token in tokens:
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            bucket = int.from_bytes(digest[:4], "big") % self.dimension
            sign = 1.0 if digest[4] % 2 == 0 else -1.0
            weight = 1.0 + (digest[5] / 255.0)
            vector[bucket] += sign * weight

        norm = math.sqrt(sum(value * value for value in vector))
        if norm == 0:
            return vector
        return [value / norm for value in vector]


embedding_service = EmbeddingService()
