from __future__ import annotations

import hashlib
import re
from typing import Dict, List


def normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def split_text_into_chunks(text: str, chunk_size: int = 1200, chunk_overlap: int = 200) -> List[str]:
    paragraphs = [normalize_whitespace(p) for p in re.split(r"\n\s*\n", text) if normalize_whitespace(p)]
    if not paragraphs:
        normalized = normalize_whitespace(text)
        return [normalized] if normalized else []

    chunks: List[str] = []
    current = ""

    for paragraph in paragraphs:
        if len(paragraph) > chunk_size:
            sentences = re.split(r"(?<=[.!?])\s+", paragraph)
        else:
            sentences = [paragraph]

        for sentence in sentences:
            if not sentence:
                continue
            candidate = f"{current} {sentence}".strip() if current else sentence
            if len(candidate) <= chunk_size:
                current = candidate
                continue

            if current:
                chunks.append(current)
                overlap = current[-chunk_overlap:] if chunk_overlap > 0 else ""
                current = f"{overlap} {sentence}".strip()
            else:
                chunks.append(sentence[:chunk_size])
                current = sentence[max(0, chunk_size - chunk_overlap):].strip()

    if current:
        chunks.append(current)

    return [chunk for chunk in chunks if chunk]


def chunk_payloads(project_id: str, document_id: str, file_name: str, text: str) -> List[Dict[str, object]]:
    chunks = split_text_into_chunks(text)
    payloads: List[Dict[str, object]] = []
    for idx, chunk in enumerate(chunks, start=1):
        payloads.append(
            {
                "chunk_id": f"{document_id}:chunk:{idx}",
                "chunk_number": idx,
                "content": chunk,
                "content_hash": hashlib.sha256(chunk.encode("utf-8")).hexdigest(),
                "metadata": {
                    "project_id": project_id,
                    "document_id": document_id,
                    "file_name": file_name,
                    "chunk_number": idx,
                },
            }
        )
    return payloads
