from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database.connection import SessionLocal
from app.models.solution_architecture import SolutionArchitecture

logger = logging.getLogger(__name__)


class SolutionArchitectureRepository:
    """Repository for managing Solution Architecture persistence and retrieval."""

    def _get_session(self, db: Session | None) -> tuple[Session, bool]:
        if db is not None:
            return db, False
        return SessionLocal(), True

    def save_solution_architecture(
        self,
        document_id: str,
        project_id: str,
        payload: Dict[str, Any],
        db: Session | None = None,
    ) -> Dict[str, Any]:
        session, should_close = self._get_session(db)
        now = datetime.now(timezone.utc).isoformat()
        try:
            # Query latest version matching document_id OR project_id
            latest_version = (
                session.query(func.max(SolutionArchitecture.version))
                .filter(
                    (SolutionArchitecture.document_id == document_id)
                    | (SolutionArchitecture.project_id == project_id)
                    | (SolutionArchitecture.document_id == project_id)
                    | (SolutionArchitecture.project_id == document_id)
                )
                .scalar()
            )
            next_version = (latest_version or 0) + 1

            executive_data = payload.get("executive")
            if executive_data is None and isinstance(payload.get("executive_json"), str):
                try:
                    executive_data = json.loads(payload["executive_json"])
                except Exception:
                    executive_data = None

            executive_json_str = json.dumps(executive_data) if executive_data is not None else None

            tech_details = payload.get("techStackDetails")
            tech_stack_json_str = json.dumps(tech_details) if tech_details is not None else None

            ai_config = payload.get("aiConfig") if isinstance(payload.get("aiConfig"), dict) else {}
            ai_provider = ai_config.get("provider") or payload.get("aiProvider")
            model_used = ai_config.get("defaultModel") or payload.get("modelUsed")

            arch = SolutionArchitecture(
                document_id=document_id,
                project_id=project_id,
                version=next_version,
                nodes_json=json.dumps(payload.get("nodes", [])),
                edges_json=json.dumps(payload.get("edges", [])),
                executive_json=executive_json_str,
                tech_stack_details_json=tech_stack_json_str,
                ai_provider=ai_provider,
                model_used=model_used,
                created_by=payload.get("createdBy") or "AI Engine",
                generation_status=payload.get("status") or "Success",
                created_at=now,
                updated_at=now,
            )
            session.add(arch)
            session.commit()
            session.refresh(arch)

            logger.info(
                "Solution Architecture Saved | Record ID: %s | document_id: %s | project_id: %s | version: %d | status: %s",
                arch.id,
                document_id,
                project_id,
                next_version,
                arch.generation_status,
            )

            return self._format_architecture(arch)
        except Exception as e:
            session.rollback()
            logger.error(
                "Error saving Solution Architecture | document_id: %s | project_id: %s | Error: %s",
                document_id,
                project_id,
                str(e),
                exc_info=True,
            )
            raise
        finally:
            if should_close:
                session.close()

    def get_latest_solution_architecture(
        self,
        identifier: str,
        db: Session | None = None,
    ) -> Optional[Dict[str, Any]]:
        return self.get_solution_architecture(identifier=identifier, version=None, db=db)

    def get_solution_architecture(
        self,
        identifier: str,
        version: Optional[int] = None,
        db: Session | None = None,
    ) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            logger.info(
                "Retrieving Solution Architecture | Query Identifier: %s | Version filter: %s | WHERE condition: (document_id == '%s' OR project_id == '%s')",
                identifier,
                version,
                identifier,
                identifier,
            )

            query = session.query(SolutionArchitecture).filter(
                (SolutionArchitecture.document_id == identifier)
                | (SolutionArchitecture.project_id == identifier)
            )

            if version is not None:
                query = query.filter(SolutionArchitecture.version == version)

            arch = query.order_by(SolutionArchitecture.version.desc()).first()

            if arch:
                logger.info(
                    "Solution Architecture Found | Record ID: %s | document_id: %s | project_id: %s | version: %d",
                    arch.id,
                    arch.document_id,
                    arch.project_id,
                    arch.version,
                )
                return self._format_architecture(arch)
            else:
                logger.warning(
                    "Solution Architecture NOT Found | Query Identifier: %s | Version: %s",
                    identifier,
                    version,
                )
                return None
        finally:
            if should_close:
                session.close()

    def get_architecture_versions(
        self,
        identifier: str,
        db: Session | None = None,
    ) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            logger.info(
                "Retrieving Solution Architecture Versions | Query Identifier: %s | WHERE condition: (document_id == '%s' OR project_id == '%s')",
                identifier,
                identifier,
                identifier,
            )

            rows = (
                session.query(SolutionArchitecture)
                .filter(
                    (SolutionArchitecture.document_id == identifier)
                    | (SolutionArchitecture.project_id == identifier)
                )
                .order_by(SolutionArchitecture.version.desc())
                .all()
            )

            logger.info(
                "Solution Architecture Versions Retrieved | Query Identifier: %s | Count: %d",
                identifier,
                len(rows),
            )

            return [self._format_architecture(r) for r in rows]
        finally:
            if should_close:
                session.close()

    def _format_architecture(self, arch: SolutionArchitecture) -> Dict[str, Any]:
        return {
            "id": arch.id,
            "documentId": arch.document_id,
            "projectId": arch.project_id,
            "version": arch.version,
            "nodes": json.loads(arch.nodes_json) if arch.nodes_json else [],
            "edges": json.loads(arch.edges_json) if arch.edges_json else [],
            "executive": json.loads(arch.executive_json) if arch.executive_json else None,
            "techStackDetails": json.loads(arch.tech_stack_details_json) if arch.tech_stack_details_json else None,
            "aiProvider": arch.ai_provider,
            "modelUsed": arch.model_used,
            "promptVersion": arch.prompt_version,
            "createdBy": arch.created_by,
            "generationStatus": arch.generation_status,
            "createdAt": arch.created_at,
            "updatedAt": arch.updated_at,
        }


architecture_repository = SolutionArchitectureRepository()
