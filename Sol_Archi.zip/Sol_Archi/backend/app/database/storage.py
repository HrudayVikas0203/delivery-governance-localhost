from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional
from uuid import uuid4

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database.connection import SessionLocal
from app.models import (
    BusinessFlow,
    ChatHistory,
    Document,
    Project,
    Report,
    Requirement,
    Role,
    SolutionArchitecture,
    User,
)
from app.repositories.architecture_repository import architecture_repository

logger = logging.getLogger(__name__)


@dataclass
class StoredDocumentRecord:
    document_id: str
    project_id: str
    file_name: str
    file_type: str
    file_size: int
    file_path: str
    uploaded_at: str
    status: str
    page_count: int = 0
    chunk_count: int = 0
    sha256: str = ""
    raw_text: str = ""
    error_message: str = ""


class MetadataStore:
    """SQLAlchemy ORM-backed metadata store for documents and design artifacts."""

    def _get_session(self, db: Session | None) -> tuple[Session, bool]:
        if db is not None:
            return db, False
        return SessionLocal(), True

    def upsert_document(self, record: StoredDocumentRecord, db: Session | None = None) -> None:
        session, should_close = self._get_session(db)
        try:
            doc = session.query(Document).filter(Document.document_id == record.document_id).first()
            if not doc:
                doc = Document(document_id=record.document_id, project_id=record.project_id)
                session.add(doc)

            doc.project_id = record.project_id
            doc.file_name = record.file_name
            doc.file_type = record.file_type
            doc.file_size = record.file_size
            doc.file_path = record.file_path
            doc.uploaded_at = record.uploaded_at
            doc.status = record.status
            doc.page_count = record.page_count
            doc.chunk_count = record.chunk_count
            doc.sha256 = record.sha256
            doc.raw_text = record.raw_text
            doc.error_message = record.error_message

            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def get_document(self, document_id: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            doc = session.query(Document).filter(Document.document_id == document_id).first()
            if not doc:
                return None
            return {
                "document_id": doc.document_id,
                "project_id": doc.project_id,
                "file_name": doc.file_name,
                "file_type": doc.file_type,
                "file_size": doc.file_size,
                "file_path": doc.file_path,
                "uploaded_at": doc.uploaded_at,
                "status": doc.status,
                "page_count": doc.page_count,
                "chunk_count": doc.chunk_count,
                "sha256": doc.sha256,
                "raw_text": doc.raw_text,
                "error_message": doc.error_message,
            }
        finally:
            if should_close:
                session.close()

    def get_project_documents(self, project_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            docs = (
                session.query(Document)
                .filter(Document.project_id == project_id)
                .order_by(Document.uploaded_at.desc())
                .all()
            )
            return [
                {
                    "document_id": doc.document_id,
                    "project_id": doc.project_id,
                    "file_name": doc.file_name,
                    "file_type": doc.file_type,
                    "file_size": doc.file_size,
                    "file_path": doc.file_path,
                    "uploaded_at": doc.uploaded_at,
                    "status": doc.status,
                    "page_count": doc.page_count,
                    "chunk_count": doc.chunk_count,
                    "sha256": doc.sha256,
                    "raw_text": doc.raw_text,
                    "error_message": doc.error_message,
                }
                for doc in docs
            ]
        finally:
            if should_close:
                session.close()

    def replace_document_chunks(self, document_id: str, project_id: str, chunks: Iterable[Dict[str, Any]], db: Session | None = None) -> None:
        pass

    def get_project_chunks(self, project_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        return []

    def save_chat_message(
        self,
        message_id: str,
        project_id: str,
        session_id: str,
        role: str,
        content: str,
        created_at: str,
        user_id: str | None = None,
        db: Session | None = None,
    ) -> None:
        session, should_close = self._get_session(db)
        try:
            msg = session.query(ChatHistory).filter(ChatHistory.message_id == message_id).first()
            if not msg:
                msg = ChatHistory(message_id=message_id)
                session.add(msg)

            msg.project_id = project_id
            msg.session_id = session_id
            msg.role = role
            msg.content = content
            msg.user_id = user_id
            msg.created_at = created_at
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def get_chat_history(self, project_id: str, session_id: str, limit: int = 20, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rows = (
                session.query(ChatHistory)
                .filter(ChatHistory.project_id == project_id, ChatHistory.session_id == session_id)
                .order_by(ChatHistory.created_at.asc())
                .limit(limit)
                .all()
            )
            return [
                {
                    "message_id": r.message_id,
                    "project_id": r.project_id,
                    "session_id": r.session_id,
                    "role": r.role,
                    "content": r.content,
                    "created_at": r.created_at,
                }
                for r in rows
            ]
        finally:
            if should_close:
                session.close()

    def save_chat_log(
        self,
        log_id: str,
        project_id: str,
        session_id: str,
        question: str,
        retrieved_chunks: List[Dict[str, Any]],
        similarity_scores: List[float],
        prompt: str,
        ai_response: str,
        response_time_ms: int,
        created_at: str,
        db: Session | None = None,
    ) -> None:
        session, should_close = self._get_session(db)
        try:
            msg = ChatHistory(
                message_id=log_id,
                project_id=project_id,
                session_id=session_id,
                role="system_log",
                content=ai_response,
                sources_json=json.dumps(retrieved_chunks),
                created_at=created_at,
            )
            session.add(msg)
            session.commit()
        except Exception:
            session.rollback()
        finally:
            if should_close:
                session.close()

    def save_requirements(self, document_id: str, project_id: str, payload: Dict[str, Any], db: Session | None = None) -> None:
        session, should_close = self._get_session(db)
        now = datetime.now(timezone.utc).isoformat()
        try:
            req = session.query(Requirement).filter(Requirement.document_id == document_id).first()
            if not req:
                req = Requirement(document_id=document_id, created_at=now)
                session.add(req)

            req.project_id = project_id
            normalized_payload = self._normalize_requirement_payload(payload)
            req.overview = normalized_payload.get("overview") or ""
            req.payload_json = json.dumps(normalized_payload)
            req.version = payload.get("version", req.version if req.version else 1)
            req.updated_at = now
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def get_requirements(self, document_id: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            req = session.query(Requirement).filter(Requirement.document_id == document_id).first()
            return self._normalize_requirement_payload(json.loads(req.payload_json)) if req else None
        finally:
            if should_close:
                session.close()

    def get_project_requirements(self, project_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rows = (
                session.query(Requirement)
                .filter(Requirement.project_id == project_id)
                .order_by(Requirement.updated_at.desc())
                .all()
            )
            return [self._normalize_requirement_payload(json.loads(r.payload_json)) for r in rows]
        finally:
            if should_close:
                session.close()

    @staticmethod
    def _normalize_requirement_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
        """Preserve module associations and keep persisted module counts consistent.

        Older records and model responses use several equivalent association keys;
        expose the canonical ``module`` field without creating new modules.
        """
        if not isinstance(payload, dict):
            return payload
        normalized = dict(payload)
        all_requirements = []
        for key in ("functional", "nonFunctional"):
            items = normalized.get(key)
            if isinstance(items, list):
                for index, item in enumerate(items):
                    if not isinstance(item, dict):
                        continue
                    req = dict(item)
                    value = req.get("module")
                    if not value:
                        value = req.get("businessModule") or req.get("business_module") or req.get("moduleName") or req.get("module_id") or req.get("moduleId")
                    if isinstance(value, dict):
                        value = value.get("name") or value.get("moduleName") or value.get("title") or value.get("id")
                    if value:
                        req["module"] = value
                    normalized[key][index] = req
                    all_requirements.append(req)

        modules = normalized.get("modules")
        if isinstance(modules, list):
            for module in modules:
                if not isinstance(module, dict):
                    continue
                module_id = str(module.get("id") or "").strip().lower()
                module_name = str(module.get("name") or module.get("moduleName") or module.get("title") or "").strip()
                key = module_name.lower()
                count = 0
                for req in all_requirements:
                    ref = req.get("module")
                    ref = str(ref.get("id") or ref.get("name") or "") if isinstance(ref, dict) else str(ref or "")
                    if ref.strip().lower() in {module_id, key} and ref.strip():
                        count += 1
                module["requirements"] = count
                module["status"] = "Analyzed" if count else "No requirements"
        return normalized

    # ================= BUSINESS FLOW VERSIONING ================= #
    def save_business_flow(self, document_id: str, project_id: str, payload: Dict[str, Any], db: Session | None = None) -> Dict[str, Any]:
        session, should_close = self._get_session(db)
        now = datetime.now(timezone.utc).isoformat()
        try:
            latest_version = (
                session.query(func.max(BusinessFlow.version))
                .filter((BusinessFlow.document_id == document_id) | (BusinessFlow.project_id == project_id))
                .scalar()
            )
            next_version = (latest_version or 0) + 1

            flow = BusinessFlow(
                document_id=document_id,
                project_id=project_id,
                version=next_version,
                nodes_json=json.dumps(payload.get("nodes", [])),
                edges_json=json.dumps(payload.get("edges", [])),
                ai_provider=payload.get("aiConfig", {}).get("provider") if isinstance(payload.get("aiConfig"), dict) else payload.get("aiProvider"),
                model_used=payload.get("aiConfig", {}).get("defaultModel") if isinstance(payload.get("aiConfig"), dict) else payload.get("modelUsed"),
                created_by=payload.get("createdBy") or "AI Engine",
                generation_status=payload.get("status") or "Success",
                created_at=now,
                updated_at=now,
            )
            session.add(flow)
            session.commit()
            return self._format_business_flow(flow)
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def get_business_flow(self, document_id: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            flow = (
                session.query(BusinessFlow)
                .filter((BusinessFlow.document_id == document_id) | (BusinessFlow.project_id == document_id))
                .order_by(BusinessFlow.version.desc())
                .first()
            )
            return self._format_business_flow(flow) if flow else None
        finally:
            if should_close:
                session.close()

    def get_business_flow_versions(self, document_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rows = (
                session.query(BusinessFlow)
                .filter((BusinessFlow.document_id == document_id) | (BusinessFlow.project_id == document_id))
                .order_by(BusinessFlow.version.desc())
                .all()
            )
            return [self._format_business_flow(r) for r in rows]
        finally:
            if should_close:
                session.close()

    def get_business_flow_by_version(self, document_id: str, version: int, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            flow = (
                session.query(BusinessFlow)
                .filter(((BusinessFlow.document_id == document_id) | (BusinessFlow.project_id == document_id)) & (BusinessFlow.version == version))
                .first()
            )
            return self._format_business_flow(flow) if flow else None
        finally:
            if should_close:
                session.close()

    def _format_business_flow(self, flow: BusinessFlow) -> Dict[str, Any]:
        return {
            "id": flow.id,
            "documentId": flow.document_id,
            "projectId": flow.project_id,
            "version": flow.version,
            "nodes": json.loads(flow.nodes_json),
            "edges": json.loads(flow.edges_json),
            "aiProvider": flow.ai_provider,
            "modelUsed": flow.model_used,
            "promptVersion": flow.prompt_version,
            "createdBy": flow.created_by,
            "generationStatus": flow.generation_status,
            "createdAt": flow.created_at,
            "updatedAt": flow.updated_at,
        }

    # ================= SOLUTION ARCHITECTURE VERSIONING ================= #
    def save_solution_architecture(self, document_id: str, project_id: str, payload: Dict[str, Any], db: Session | None = None) -> Dict[str, Any]:
        return architecture_repository.save_solution_architecture(document_id, project_id, payload, db=db)

    def save_architecture(self, document_id: str, project_id: str, payload: Dict[str, Any], db: Session | None = None) -> Dict[str, Any]:
        return self.save_solution_architecture(document_id, project_id, payload, db=db)

    def get_latest_solution_architecture(self, identifier: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        return architecture_repository.get_latest_solution_architecture(identifier, db=db)

    def get_solution_architecture(self, identifier: str, version: Optional[int] = None, db: Session | None = None) -> Optional[Dict[str, Any]]:
        return architecture_repository.get_solution_architecture(identifier, version=version, db=db)

    def get_architecture(self, document_id: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        return self.get_latest_solution_architecture(document_id, db=db)

    def get_architecture_versions(self, document_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        return architecture_repository.get_architecture_versions(document_id, db=db)

    def get_architecture_by_version(self, document_id: str, version: int, db: Session | None = None) -> Optional[Dict[str, Any]]:
        return self.get_solution_architecture(document_id, version=version, db=db)

    def _format_architecture(self, arch: SolutionArchitecture) -> Dict[str, Any]:
        return architecture_repository._format_architecture(arch)

    # ================= DATABASE DESIGN VERSIONING ================= #
    def save_database_design(self, document_id: str, project_id: str, payload: Dict[str, Any], db: Session | None = None) -> Dict[str, Any]:
        session, should_close = self._get_session(db)
        now = datetime.now(timezone.utc).isoformat()
        try:
            latest_version = (
                session.query(func.max(DatabaseDesign.version))
                .filter((DatabaseDesign.document_id == document_id) | (DatabaseDesign.project_id == project_id))
                .scalar()
            )
            next_version = (latest_version or 0) + 1

            db_design = DatabaseDesign(
                document_id=document_id,
                project_id=project_id,
                version=next_version,
                entities_json=json.dumps(payload.get("entities", [])),
                database_tech=payload.get("databaseTech", ""),
                ai_provider=payload.get("aiConfig", {}).get("provider") if isinstance(payload.get("aiConfig"), dict) else payload.get("aiProvider"),
                model_used=payload.get("aiConfig", {}).get("defaultModel") if isinstance(payload.get("aiConfig"), dict) else payload.get("modelUsed"),
                created_by=payload.get("createdBy") or "AI Engine",
                generation_status=payload.get("status") or "Success",
                created_at=now,
                updated_at=now,
            )
            session.add(db_design)
            session.commit()
            return self._format_database_design(db_design)
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def get_database_design(self, document_id: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            db_design = (
                session.query(DatabaseDesign)
                .filter((DatabaseDesign.document_id == document_id) | (DatabaseDesign.project_id == document_id))
                .order_by(DatabaseDesign.version.desc())
                .first()
            )
            return self._format_database_design(db_design) if db_design else None
        finally:
            if should_close:
                session.close()

    def get_database_design_versions(self, document_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rows = (
                session.query(DatabaseDesign)
                .filter((DatabaseDesign.document_id == document_id) | (DatabaseDesign.project_id == document_id))
                .order_by(DatabaseDesign.version.desc())
                .all()
            )
            return [self._format_database_design(r) for r in rows]
        finally:
            if should_close:
                session.close()

    def get_database_design_by_version(self, document_id: str, version: int, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            db_design = (
                session.query(DatabaseDesign)
                .filter(((DatabaseDesign.document_id == document_id) | (DatabaseDesign.project_id == document_id)) & (DatabaseDesign.version == version))
                .first()
            )
            return self._format_database_design(db_design) if db_design else None
        finally:
            if should_close:
                session.close()

    def _format_database_design(self, db_design: DatabaseDesign) -> Dict[str, Any]:
        return {
            "id": db_design.id,
            "documentId": db_design.document_id,
            "projectId": db_design.project_id,
            "version": db_design.version,
            "entities": json.loads(db_design.entities_json),
            "databaseTech": db_design.database_tech,
            "aiProvider": db_design.ai_provider,
            "modelUsed": db_design.model_used,
            "promptVersion": db_design.prompt_version,
            "createdBy": db_design.created_by,
            "generationStatus": db_design.generation_status,
            "createdAt": db_design.created_at,
            "updatedAt": db_design.updated_at,
        }

    # ================= REPORT VERSIONING ================= #
    def save_report(self, project_id: str, payload: Dict[str, Any], db: Session | None = None) -> Dict[str, Any]:
        session, should_close = self._get_session(db)
        now = datetime.now(timezone.utc).isoformat()
        try:
            latest_version = (
                session.query(func.max(Report.version))
                .filter(Report.project_id == project_id)
                .scalar()
            )
            next_version = (latest_version or 0) + 1
            report_id = payload.get("reportId") or f"rpt-{project_id}-v{next_version}"

            rpt = Report(
                report_id=report_id,
                project_id=project_id,
                version=next_version,
                report_type=payload.get("reportType", "Executive Solution Report"),
                title=payload.get("title", "Executive Solution Architecture Report"),
                content_json=json.dumps(payload.get("sections", payload.get("content", []))),
                ai_provider=payload.get("aiConfig", {}).get("provider") if isinstance(payload.get("aiConfig"), dict) else payload.get("aiProvider"),
                model_used=payload.get("aiConfig", {}).get("defaultModel") if isinstance(payload.get("aiConfig"), dict) else payload.get("modelUsed"),
                created_by=payload.get("createdBy") or "AI Engine",
                generation_status=payload.get("status") or "Success",
                created_at=now,
                updated_at=now,
            )
            session.add(rpt)
            session.commit()
            return self._format_report(rpt)
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def get_report(self, project_id: str, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rpt = (
                session.query(Report)
                .filter((Report.project_id == project_id) | (Report.report_id == project_id))
                .order_by(Report.version.desc())
                .first()
            )
            return self._format_report(rpt) if rpt else None
        finally:
            if should_close:
                session.close()

    def get_report_versions(self, project_id: str, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rows = (
                session.query(Report)
                .filter((Report.project_id == project_id) | (Report.report_id == project_id))
                .order_by(Report.version.desc())
                .all()
            )
            return [self._format_report(r) for r in rows]
        finally:
            if should_close:
                session.close()

    def get_report_by_version(self, project_id: str, version: int, db: Session | None = None) -> Optional[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rpt = (
                session.query(Report)
                .filter(((Report.project_id == project_id) | (Report.report_id == project_id)) & (Report.version == version))
                .first()
            )
            return self._format_report(rpt) if rpt else None
        finally:
            if should_close:
                session.close()

    def _format_report(self, rpt: Report) -> Dict[str, Any]:
        return {
            "id": rpt.id,
            "reportId": rpt.report_id,
            "projectId": rpt.project_id,
            "version": rpt.version,
            "reportType": rpt.report_type,
            "title": rpt.title,
            "sections": json.loads(rpt.content_json) if rpt.content_json else [],
            "aiProvider": rpt.ai_provider,
            "modelUsed": rpt.model_used,
            "promptVersion": rpt.prompt_version,
            "createdBy": rpt.created_by,
            "generationStatus": rpt.generation_status,
            "createdAt": rpt.created_at,
            "updatedAt": rpt.updated_at,
        }

    def _format_project(self, project: Project) -> Dict[str, Any]:
        return {
            "id": project.project_id,
            "name": project.name,
            "description": project.description or "",
            "createdAt": project.created_at,
            "selectedTechStack": project.selected_tech_stack or "",
            "selectedDatabase": project.selected_database or "",
            "isStackConfirmed": bool(project.is_stack_confirmed),
        }

    def list_projects(self, db: Session | None = None) -> List[Dict[str, Any]]:
        session, should_close = self._get_session(db)
        try:
            rows = session.query(Project).order_by(Project.created_at.asc()).all()
            return [self._format_project(row) for row in rows]
        finally:
            if should_close:
                session.close()

    def create_project(
        self,
        name: str,
        description: str = "",
        selected_tech_stack: str = "",
        selected_database: str = "",
        is_stack_confirmed: bool = False,
        db: Session | None = None,
    ) -> Dict[str, Any]:
        session, should_close = self._get_session(db)
        try:
            now = datetime.now(timezone.utc).isoformat()
            project = Project(
                project_id=f"project-{uuid4().hex[:12]}",
                name=name,
                description=description,
                selected_tech_stack=selected_tech_stack or None,
                selected_database=selected_database or None,
                is_stack_confirmed=is_stack_confirmed,
                created_at=now,
                updated_at=now,
            )
            session.add(project)
            session.commit()
            session.refresh(project)
            return self._format_project(project)
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()

    def ensure_default_project(
        self,
        project_id: str,
        name: str,
        description: str,
        db: Session | None = None,
    ) -> Dict[str, Any]:
        session, should_close = self._get_session(db)
        try:
            existing = session.query(Project).filter(Project.project_id == project_id).first()
            if existing:
                return self._format_project(existing)
            now = datetime.now(timezone.utc).isoformat()
            project = Project(
                project_id=project_id,
                name=name,
                description=description,
                created_at=now,
                updated_at=now,
            )
            session.add(project)
            session.commit()
            session.refresh(project)
            return self._format_project(project)
        except Exception:
            session.rollback()
            raise
        finally:
            if should_close:
                session.close()


metadata_store = MetadataStore()
