from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.database.connection import SessionLocal, engine
from app.database.storage import metadata_store
from app.models import Base, Role, User

logger = logging.getLogger(__name__)


def init_db(db: Session | None = None) -> None:
    """Creates database tables and seeds default roles and admin account."""
    Base.metadata.create_all(bind=engine)

    close_session = False
    if db is None:
        db = SessionLocal()
        close_session = True

    try:
        now = datetime.now(timezone.utc).isoformat()

        # Seed default roles
        default_roles = [
            ("Admin", "Full administrative access across all projects and system settings"),
            ("Solution Architect", "Design solution architectures, business flows, and technical stack selection"),
            ("Enterprise Architect", "Review architectural standards and system integrations"),
            ("Business Analyst", "Upload document requirements, edit requirements, and generate business flows"),
            ("Delivery Manager", "Track project status, dependencies, and executive summary reports"),
        ]

        for role_name, description in default_roles:
            existing = db.query(Role).filter(Role.name == role_name).first()
            if not existing:
                role = Role(
                    name=role_name,
                    description=description,
                    permissions_json=json.dumps(["read", "write", "export"]),
                    created_at=now,
                )
                db.add(role)
        db.commit()

        # Seed default admin user if absent
        admin_user = db.query(User).filter(User.username == "admin").first()
        if not admin_user:
            admin_role = db.query(Role).filter(Role.name == "Admin").first()
            admin = User(
                user_id="usr-admin-001",
                username="admin",
                email="admin@enterprise.com",
                password_hash="$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeg6Lruj3vjPGga31lW",  # hashed default password
                role_id=admin_role.id if admin_role else None,
                created_at=now,
                updated_at=now,
            )
            db.add(admin)
            db.commit()

        default_project_id = os.getenv("DEFAULT_PROJECT_ID", "project-default")
        metadata_store.ensure_default_project(
            project_id=default_project_id,
            name="Current Project",
            description="Project workspace for uploaded solution documents",
            db=db,
        )

        logger.info("Database schema initialized and default seed data loaded successfully.")
    except Exception as exc:
        db.rollback()
        logger.exception("Failed to initialize database: %s", exc)
        raise
    finally:
        if close_session:
            db.close()


if __name__ == "__main__":
    init_db()
