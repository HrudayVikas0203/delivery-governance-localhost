from __future__ import annotations

import logging
from typing import Generator
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session, sessionmaker

from app.config.settings import settings

logger = logging.getLogger(__name__)


def create_db_engine():
    database_url = settings.DATABASE_URL
    engine = create_engine(
        database_url,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
        echo=False,
    )
    logger.info("Configured SQLAlchemy engine for MySQL database: %s", database_url)
    return engine


engine = create_db_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    """Dependency injection helper for FastAPI endpoints with automatic transaction rollback."""
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def validate_database_connection() -> bool:
    """Validates connectivity to the active database engine."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        logger.info("Successfully validated MySQL database connectivity.")
        return True
    except Exception as exc:
        logger.error("Database connection failure: %s", exc)
        return False
