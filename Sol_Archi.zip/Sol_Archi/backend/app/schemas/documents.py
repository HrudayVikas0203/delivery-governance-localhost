from typing import Any, List, Optional
from pydantic import BaseModel, Field


class UploadResponse(BaseModel):
    documentId: str
    name: str
    type: str
    size: str
    uploadedAt: str
    status: str


class ProjectResponse(BaseModel):
    id: str
    name: str
    description: str = ""
    createdAt: str
    selectedTechStack: str = ""
    selectedDatabase: str = ""
    isStackConfirmed: bool = False


class ProjectCreateRequest(BaseModel):
    name: str
    description: str = ""
    selectedTechStack: str = ""
    selectedDatabase: str = ""
    isStackConfirmed: bool = False


class ProcessingStatusResponse(BaseModel):
    documentId: str
    status: str
    confidence: int
    errorDetails: Optional[str] = None


class RequirementUpdateRequest(BaseModel):
    docId: Optional[str] = None
    projectId: Optional[str] = None
    overview: Optional[str] = None
    functional: Optional[List[dict]] = None
    nonFunctional: Optional[List[dict]] = None
    model_config = {"extra": "allow"}


class BusinessFlowRequest(BaseModel):
    docId: Optional[str] = None
    projectId: Optional[str] = None
    nodes: List[dict]
    edges: List[dict]
    model_config = {"extra": "allow"}


class ArchitectureRequest(BaseModel):
    docId: Optional[str] = None
    documentId: Optional[str] = None
    projectId: Optional[str] = None
    project_id: Optional[str] = None
    nodes: List[dict]
    edges: List[dict]
    executive: Optional[dict] = None
    techStackDetails: Optional[Any] = None
    model_config = {"extra": "allow"}

    @property
    def resolved_doc_id(self) -> Optional[str]:
        return self.docId or self.documentId

    @property
    def resolved_project_id(self) -> Optional[str]:
        return self.projectId or self.project_id


class ModuleModelMapping(BaseModel):
    requirementExtraction: str = "llama-3.3-70b-versatile"
    businessFlow: str = "llama-3.3-70b-versatile"
    architecture: str = "llama-3.3-70b-versatile"
    reports: str = "llama-3.3-70b-versatile"
    aiChat: str = "llama-3.3-70b-versatile"


class AiConfigPayload(BaseModel):
    provider: str = "Groq"
    defaultModel: str = "llama-3.3-70b-versatile"
    moduleModels: ModuleModelMapping = Field(default_factory=ModuleModelMapping)
    temperature: float = 0.2
    maxTokens: int = 1200
    responseFormat: str = "Raw Text"
    apiKey: Optional[str] = None
    endpointUrl: Optional[str] = None


class RequirementGenerationRequest(BaseModel):
    docId: Optional[str] = None
    projectId: Optional[str] = None
    text: str = ""
    aiConfig: AiConfigPayload


class BusinessFlowGenerationRequest(BaseModel):
    docId: Optional[str] = None
    projectId: Optional[str] = None
    requirements: Optional[dict] = Field(default_factory=dict)
    aiConfig: Optional[AiConfigPayload] = Field(default_factory=AiConfigPayload)


class ArchitectureGenerationRequest(BaseModel):
    docId: Optional[str] = None
    documentId: Optional[str] = None
    projectId: Optional[str] = None
    project_id: Optional[str] = None
    requirements: Optional[dict] = Field(default_factory=dict)
    techStack: str = ""
    aiConfig: Optional[AiConfigPayload] = Field(default_factory=AiConfigPayload)
    model_config = {"extra": "allow"}

    @property
    def resolved_doc_id(self) -> Optional[str]:
        return self.docId or self.documentId

    @property
    def resolved_project_id(self) -> Optional[str]:
        return self.projectId or self.project_id


class ReportGenerationRequest(BaseModel):
    projectId: Optional[str] = None
    project: dict = Field(default_factory=dict)
    requirements: Optional[dict] = None
    businessFlow: Optional[dict] = None
    architecture: Optional[dict] = None
    aiConfig: AiConfigPayload



class ChatHistoryItem(BaseModel):
    role: str
    content: str


class ChatQueryRequest(BaseModel):
    projectId: str
    sessionId: str
    question: str
    history: List[ChatHistoryItem] = Field(default_factory=list)
    projectMetadata: dict = Field(default_factory=dict)
    aiConfig: AiConfigPayload
    topK: int = 5
    minScore: float = 0.15


class ChatSource(BaseModel):
    documentId: str
    documentName: str
    chunkNumber: int
    chunkContent: str
    similarityScore: float


class ChatQueryResponse(BaseModel):
    answer: str
    sources: List[ChatSource] = Field(default_factory=list)
    responseTimeMs: int
