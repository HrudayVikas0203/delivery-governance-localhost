from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from sqlalchemy.exc import DBAPIError, OperationalError

from app.api.routes import api_router
from app.config.settings import settings
from app.database.connection import validate_database_connection
from app.database.init_db import init_db
from app.database.storage import metadata_store
from app.debug_session_log import write_debug_log
from app.rag.chroma_store import vector_store

logger = logging.getLogger(__name__)

app = FastAPI(title=settings.APP_NAME, version=settings.APP_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ALLOW_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

app.include_router(api_router)


@app.middleware("http")
async def debug_request_middleware(request: Request, call_next):
    write_debug_log(
        "main.py:middleware",
        "Incoming request",
        {"method": request.method, "path": request.url.path},
        hypothesis_id="E",
    )
    response = await call_next(request)
    write_debug_log(
        "main.py:middleware",
        "Outgoing response",
        {"method": request.method, "path": request.url.path, "status": response.status_code},
        hypothesis_id="E",
    )
    return response


@app.on_event("startup")
def on_startup():
    is_connected = validate_database_connection()
    if is_connected:
        logger.info("Database connection validated successfully during startup.")
    else:
        logger.warning("Database connection check failed during startup.")
    init_db()
    _ = metadata_store
    _ = vector_store


@app.exception_handler(OperationalError)
@app.exception_handler(DBAPIError)
async def handle_db_error(_: Request, exc: Exception):
    logger.error("Database operational exception: %s", exc)
    return JSONResponse(
        status_code=503,
        content={
            "error": "database_error",
            "detail": "Database service is currently unavailable. Please verify backend MySQL connection.",
        },
    )


@app.exception_handler(RequestValidationError)
async def handle_validation_error(_: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "error": "validation_error",
            "detail": exc.errors(),
        },
    )


from app.utils.exceptions import AIProviderException


@app.exception_handler(AIProviderException)
async def handle_ai_provider_error(_: Request, exc: AIProviderException):
    logger.warning("AI Provider Exception: %s | Provider: %s", exc.message, exc.provider)
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "error": exc.message,
            "retryable": exc.retryable,
            "provider": exc.provider,
            "detail": exc.message,
        },
    )



@app.exception_handler(Exception)
async def handle_unexpected_error(_: Request, exc: Exception):
    logger.exception("Unhandled backend exception")
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "detail": str(exc),
        },
    )


@app.get("/health")
def health_check():
    return {"status": "ok", "service": settings.APP_NAME, "version": settings.APP_VERSION}

