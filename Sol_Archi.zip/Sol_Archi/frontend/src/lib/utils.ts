import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNumber(num: number): string {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M'
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
  return num.toString()
}

export function getTimeAgo(date: Date): string {
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 1) return 'Just now'
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  if (days < 7) return `${days}d ago`
  return date.toLocaleDateString()
}

export function getConfidenceColor(score: number): string {
  if (score >= 90) return 'text-green-500'
  if (score >= 70) return 'text-yellow-500'
  if (score >= 50) return 'text-orange-500'
  return 'text-red-500'
}

export function getConfidenceBg(score: number): string {
  if (score >= 90) return 'bg-green-500/10 text-green-600'
  if (score >= 70) return 'bg-yellow-500/10 text-yellow-600'
  if (score >= 50) return 'bg-orange-500/10 text-orange-600'
  return 'bg-red-500/10 text-red-600'
}

export function getPriorityColor(priority?: string | null): string {
  const norm = (priority ?? 'medium').toString().toLowerCase()
  switch (norm) {
    case 'critical': return 'bg-red-500/10 text-red-600 border-red-200'
    case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-200'
    case 'medium': return 'bg-yellow-500/10 text-yellow-600 border-yellow-200'
    case 'low': return 'bg-blue-500/10 text-blue-600 border-blue-200'
    default: return 'bg-gray-500/10 text-gray-600 border-gray-200'
  }
}

export function getMethodColor(method?: string | null): string {
  const norm = (method ?? 'GET').toString().toUpperCase()
  switch (norm) {
    case 'GET': return 'method-get'
    case 'POST': return 'method-post'
    case 'PUT': return 'method-put'
    case 'DELETE': return 'method-delete'
    case 'PATCH': return 'method-patch'
    default: return 'bg-gray-100 text-gray-600'
  }
}

export function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}
