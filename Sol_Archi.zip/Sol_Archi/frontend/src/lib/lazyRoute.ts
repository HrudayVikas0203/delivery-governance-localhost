import { lazy } from 'react'

export function lazyRoute<T extends React.ComponentType<any>>(
  loader: () => Promise<{ default: T }>,
  routeLabel: string,
) {
  return lazy(async () => {
    try {
      return await loader()
    } catch (error) {
      console.error(`Failed to load ${routeLabel}`, error)
      const detail = error instanceof Error ? error.message : String(error)
      throw new Error(`Unable to load ${routeLabel}. Please refresh or try again. ${detail}`)
    }
  })
}
