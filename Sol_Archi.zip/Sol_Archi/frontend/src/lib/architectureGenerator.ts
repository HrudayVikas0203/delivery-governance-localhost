import type { ArchNode, ArchEdge, Recommendation, TechRecommendation, ValidationWarning, HealthMetric, VersionHistoryItem, DBEntity, ReportSection, Project, ExecutiveArchitectureData } from '../data/types'

// Helper function to build nodes with consistent style
function createNode(id: string, label: string, componentType: string, technology: string, cloudService: string, layer: 'Presentation' | 'Middleware' | 'Backend' | 'Data' | 'Infrastructure', icon: string, x: number, y: number): ArchNode {
  return {
    id,
    type: 'archNode',
    position: { x, y },
    data: {
      label,
      componentType,
      technology,
      cloudService,
      layer,
      description: `${label} component operating at the ${layer} layer using ${technology}.`,
      icon,
    }
  }
}

// Generate Architecture based on chosen stack
export function generateArchitectureForStack(stack: string, customDetails?: Project['techStackDetails']): {
  nodes: ArchNode[]
  edges: ArchEdge[]
  executive?: ExecutiveArchitectureData
  recommendations: Recommendation[]
  techStack: TechRecommendation[]
  validations: ValidationWarning[]
  healthMetrics: HealthMetric[]
  versions: VersionHistoryItem[]
} {
  let nodes: ArchNode[] = []
  let edges: ArchEdge[] = []
  let techRecommendations: TechRecommendation[] = []
  let recommendations: Recommendation[] = []
  let validations: ValidationWarning[] = []
  let healthMetrics: HealthMetric[] = []
  let versions: VersionHistoryItem[] = []

  if (customDetails) {
    const cloud = customDetails.cloudPlatform || 'AWS'
    const front = customDetails.frontend || 'React'
    const back = customDetails.backend || 'Python FastAPI'
    const db = customDetails.database || 'PostgreSQL'
    const auth = customDetails.authentication || 'OAuth2'
    const storage = customDetails.storage || 'AWS S3'
    const messaging = customDetails.messaging || 'RabbitMQ'
    const ai = customDetails.aiServices || 'OpenAI API'
    const monitoring = customDetails.monitoring || 'Prometheus + Grafana'

    nodes = [
      createNode('ac1', 'Users', 'Client', 'Browser / Mobile', '-', 'Presentation', 'Users', 400, 0),
      createNode('ac2', 'Web Portal', 'Frontend', front, `${cloud} Hosting`, 'Presentation', 'Globe', 400, 90),
      createNode('ac3', 'CDN', 'Content Delivery', `${cloud} CDN`, `${cloud} CDN`, 'Presentation', 'Cloud', 650, 90),
      createNode('ac4', 'API Gateway', 'Gateway', `${cloud} Gateway`, `${cloud} API Gateway`, 'Middleware', 'Shield', 400, 200),
      createNode('ac5', 'Auth Service', 'Security', auth, auth, 'Backend', 'Key', 150, 320),
      createNode('ac6', 'Core Application', 'Backend App', back, `${cloud} App Instance`, 'Backend', 'Server', 400, 320),
      createNode('ac7', 'Database Instance', 'Database', db, db, 'Data', 'Database', 250, 460),
      createNode('ac8', 'Object Storage', 'Storage', storage, storage, 'Data', 'HardDrive', 550, 460),
      createNode('ac9', 'AI Core Service', 'AI Engine', ai, ai, 'Backend', 'Brain', 650, 320),
      createNode('ac10', 'Event Bus', 'Messaging', messaging, messaging, 'Infrastructure', 'ArrowLeftRight', 150, 460),
      createNode('ac11', 'Observability Stack', 'Monitoring', monitoring, monitoring, 'Infrastructure', 'Activity', 400, 580),
    ]

    edges = [
      { id: 'e1', source: 'ac1', target: 'ac2', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
      { id: 'e2', source: 'ac2', target: 'ac3', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
      { id: 'e3', source: 'ac2', target: 'ac4', label: 'HTTPS', animated: true, style: { stroke: '#3B82F6', strokeWidth: 2 } },
      { id: 'e4', source: 'ac4', target: 'ac5', label: 'Authenticate', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
      { id: 'e5', source: 'ac4', target: 'ac6', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
      { id: 'e6', source: 'ac6', target: 'ac7', label: 'Read/Write', animated: true, style: { stroke: '#F59E0B', strokeWidth: 1.5 } },
      { id: 'e7', source: 'ac6', target: 'ac8', label: 'Store Asset', animated: true, style: { stroke: '#10B981', strokeWidth: 1.5 } },
      { id: 'e8', source: 'ac6', target: 'ac9', label: 'Prompt RAG', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
      { id: 'e9', source: 'ac6', target: 'ac10', label: 'Publish Event', animated: true, style: { stroke: '#6B7280', strokeWidth: 1.5 } },
      { id: 'e10', source: 'ac6', target: 'ac11', label: 'APM Logs', animated: false, style: { stroke: '#10B981', strokeWidth: 1.5 } },
    ]

    techRecommendations = [
      { category: 'Frontend', technology: front, confidence: 95, reason: `Optimized component layout using ${front} for web portals.`, alternatives: ['React', 'Angular', 'Vue.js'] },
      { category: 'Backend', technology: back, confidence: 93, reason: `Robust server execution architecture running on ${back}.`, alternatives: ['.NET 8', 'Python FastAPI', 'Go'] },
      { category: 'Database', technology: db, confidence: 94, reason: `Structured and scaled queries powered by ${db}.`, alternatives: ['PostgreSQL', 'MongoDB', 'SQL Server'] },
      { category: 'Cloud Infrastructure', technology: cloud, confidence: 92, reason: `Highly integrated cloud environments provided by ${cloud}.`, alternatives: ['AWS', 'Azure', 'GCP'] }
    ]

    recommendations = [
      { id: 'REC1', title: 'Add API Rate Limiting', reason: 'No rate limiting detected on API Gateway. External-facing APIs are vulnerable to abuse and DDoS attacks.', impact: 'Critical', priority: 1, category: 'Security', applied: false },
      { id: 'REC2', title: 'Implement Circuit Breaker Pattern', reason: 'External integrations lack fault tolerance. Service failures could cascade through the system.', impact: 'High', priority: 2, category: 'Reliability', applied: false },
      { id: 'REC3', title: 'Add Redis Cache Layer', reason: 'Frequently accessed data should be cached to reduce database load.', impact: 'High', priority: 3, category: 'Performance', applied: true },
    ]

    validations = [
      { id: 'VW1', title: 'Authentication Service - Single Point of Failure', priority: 'Critical', description: 'Authentication service has no redundancy configured. A failure would lock out all users.', recommendedFix: 'Deploy Auth Service in active-active configuration across availability zones', category: 'Reliability', resolved: false },
      { id: 'VW2', title: 'Missing Audit Logging on DELETE Operations', priority: 'Critical', description: 'DELETE operations lack comprehensive audit trail logging.', recommendedFix: 'Add middleware to capture all destructive operations with before/after state', category: 'Compliance', resolved: false },
    ]

    healthMetrics = [
      { name: 'Completeness', score: 85, maxScore: 100, recommendations: ['Add disaster recovery configuration', 'Define data backup strategy'] },
      { name: 'Security', score: 72, maxScore: 100, recommendations: ['Implement field-level encryption', 'Add API rate limiting'] },
      { name: 'Performance', score: 88, maxScore: 100, recommendations: ['Add connection pooling'] },
      { name: 'Scalability', score: 92, maxScore: 100, recommendations: [] },
    ]

    versions = [
      { id: 'v1', version: 'v1.0', name: 'Initial Architecture Draft', date: '2026-07-08', changes: 'Basic monolith structure with relational SQL database.', components: 11, connections: 10, author: 'AI Architect' },
    ]
  } else {
    const isNet = stack.includes('.NET')
    const isFastAPI = stack.includes('FastAPI')

    if (isNet) {
      // React + .NET + Azure SQL
      nodes = [
        createNode('ac1', 'Users', 'Client', 'Browser / Mobile', '-', 'Presentation', 'Users', 400, 0),
        createNode('ac2', 'Web Portal', 'Frontend', 'React 18 + TypeScript', 'Azure Static Web Apps', 'Presentation', 'Globe', 400, 90),
        createNode('ac3', 'CDN', 'Content Delivery', 'Azure CDN', 'Azure CDN', 'Presentation', 'Cloud', 650, 90),
        createNode('ac4', 'API Gateway', 'Gateway', 'Azure API Management', 'Azure APIM', 'Middleware', 'Shield', 400, 200),
        createNode('ac5', 'Auth Service', 'Microservice', 'Node.js + Passport', 'Azure AD B2C', 'Backend', 'Key', 150, 320),
        createNode('ac6', 'Employee Service', 'Microservice', '.NET 8 / C#', 'Azure Container Apps', 'Backend', 'User', 300, 320),
        createNode('ac7', 'Performance Service', 'Microservice', '.NET 8 / C#', 'Azure Container Apps', 'Backend', 'Target', 450, 320),
        createNode('ac8', 'Leave Service', 'Microservice', '.NET 8 / C#', 'Azure Container Apps', 'Backend', 'Calendar', 600, 320),
        createNode('ac9', 'Analytics Service', 'Microservice', 'Python + FastAPI', 'Azure Container Apps', 'Backend', 'BarChart3', 750, 320),
        createNode('ac10', 'Notification Service', 'Microservice', 'Node.js', 'Azure Functions', 'Backend', 'Bell', 150, 440),
        createNode('ac11', 'Azure SQL DB', 'Database', 'SQL Server 2022', 'Azure SQL Database', 'Data', 'Database', 300, 460),
        createNode('ac12', 'Redis Cache', 'Cache', 'Redis 7', 'Azure Cache for Redis', 'Data', 'Zap', 450, 460),
        createNode('ac13', 'Blob Storage', 'Storage', 'Azure Blob', 'Azure Blob Storage', 'Data', 'HardDrive', 600, 460),
        createNode('ac14', 'AI Search', 'Search', 'Azure AI Search', 'Azure AI Search', 'Data', 'Search', 750, 460),
        createNode('ac15', 'Service Bus', 'Messaging', 'Azure Service Bus', 'Azure Service Bus', 'Infrastructure', 'ArrowLeftRight', 150, 560),
        createNode('ac16', 'Monitoring', 'Observability', 'Azure Monitor', 'Azure Monitor', 'Infrastructure', 'Activity', 350, 580),
        createNode('ac17', 'Log Analytics', 'Observability', 'Log Analytics Workspace', 'Azure Log Analytics', 'Infrastructure', 'FileText', 550, 580),
      ]

      edges = [
        { id: 'e1', source: 'ac1', target: 'ac2', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e2', source: 'ac2', target: 'ac3', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e3', source: 'ac2', target: 'ac4', label: 'HTTPS', animated: true, style: { stroke: '#3B82F6', strokeWidth: 2 } },
        { id: 'e4', source: 'ac4', target: 'ac5', label: 'Authenticate', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
        { id: 'e5', source: 'ac4', target: 'ac6', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e6', source: 'ac4', target: 'ac7', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e7', source: 'ac4', target: 'ac8', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e8', source: 'ac4', target: 'ac9', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e9', source: 'ac6', target: 'ac11', label: 'Write', animated: true, style: { stroke: '#F59E0B', strokeWidth: 1.5 } },
        { id: 'e10', source: 'ac7', target: 'ac11', label: 'Write', animated: true, style: { stroke: '#F59E0B', strokeWidth: 1.5 } },
        { id: 'e11', source: 'ac8', target: 'ac11', label: 'Write', animated: true, style: { stroke: '#F59E0B', strokeWidth: 1.5 } },
        { id: 'e12', source: 'ac6', target: 'ac12', label: 'Cache Read', animated: false, style: { stroke: '#10B981', strokeWidth: 1.5 } },
        { id: 'e13', source: 'ac7', target: 'ac12', label: 'Cache Read', animated: false, style: { stroke: '#10B981', strokeWidth: 1.5 } },
        { id: 'e14', source: 'ac8', target: 'ac15', label: 'Publish Event', animated: true, style: { stroke: '#6B7280', strokeWidth: 1.5 } },
        { id: 'e15', source: 'ac15', target: 'ac10', label: 'Consume', animated: true, style: { stroke: '#6B7280', strokeWidth: 1.5 } },
        { id: 'e16', source: 'ac9', target: 'ac14', label: 'Query Index', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e17', source: 'ac11', target: 'ac13', label: 'Backup', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
      ]

      techRecommendations = [
        { category: 'Frontend', technology: 'React 18 + TypeScript', confidence: 95, reason: 'Provides component-driven reuse, type-safety, and optimized virtual DOM updates for employee tables.', alternatives: ['Angular 17', 'Vue.js 3'] },
        { category: 'Backend', technology: '.NET 8 / C#', confidence: 92, reason: 'High performance RESTful Web API container instances executing enterprise policies natively.', alternatives: ['Java Spring Boot', 'Python FastAPI'] },
        { category: 'Database', technology: 'Azure SQL Database', confidence: 94, reason: 'Elastic pool SQL instances ensuring ACID transactions and automated backup retention schedules.', alternatives: ['PostgreSQL 16', 'Oracle 23c'] }
      ]
    } else if (isFastAPI) {
      // React + FastAPI + PostgreSQL
      nodes = [
        createNode('ac1', 'Users', 'Client', 'Browser / Mobile', '-', 'Presentation', 'Users', 400, 0),
        createNode('ac2', 'Web Portal', 'Frontend', 'React 18 + TypeScript', 'AWS Amplify', 'Presentation', 'Globe', 400, 90),
        createNode('ac3', 'CDN', 'Content Delivery', 'Amazon CloudFront', 'AWS CloudFront', 'Presentation', 'Cloud', 650, 90),
        createNode('ac4', 'API Gateway', 'Gateway', 'Amazon API Gateway', 'AWS API Gateway', 'Middleware', 'Shield', 400, 200),
        createNode('ac5', 'Auth Service', 'Microservice', 'FastAPI OAuth2', 'AWS Cognito', 'Backend', 'Key', 150, 320),
        createNode('ac6', 'Core Application', 'Backend App', 'Python + FastAPI', 'AWS ECS Fargate', 'Backend', 'Server', 400, 320),
        createNode('ac7', 'PostgreSQL DB', 'Database', 'PostgreSQL 16', 'Amazon RDS Aurora', 'Data', 'Database', 250, 460),
        createNode('ac8', 'S3 Storage', 'Storage', 'AWS S3', 'Amazon S3 Bucket', 'Data', 'HardDrive', 550, 460),
        createNode('ac9', 'AI Core Service', 'AI Engine', 'OpenAI API (RAG)', 'AWS Bedrock Integration', 'Backend', 'Brain', 650, 320),
        createNode('ac10', 'RabbitMQ', 'Messaging', 'RabbitMQ Cluster', 'Amazon MQ', 'Infrastructure', 'ArrowLeftRight', 150, 460),
        createNode('ac11', 'Observability Stack', 'Monitoring', 'Prometheus + Grafana', 'Amazon CloudWatch', 'Infrastructure', 'Activity', 400, 580),
      ]

      edges = [
        { id: 'e1', source: 'ac1', target: 'ac2', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e2', source: 'ac2', target: 'ac3', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e3', source: 'ac2', target: 'ac4', label: 'HTTPS', animated: true, style: { stroke: '#3B82F6', strokeWidth: 2 } },
        { id: 'e4', source: 'ac4', target: 'ac5', label: 'Authenticate', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
        { id: 'e5', source: 'ac4', target: 'ac6', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e6', source: 'ac6', target: 'ac7', label: 'Read/Write', animated: true, style: { stroke: '#F59E0B', strokeWidth: 1.5 } },
        { id: 'e7', source: 'ac6', target: 'ac8', label: 'Store Asset', animated: true, style: { stroke: '#10B981', strokeWidth: 1.5 } },
        { id: 'e8', source: 'ac6', target: 'ac9', label: 'Prompt RAG', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
        { id: 'e9', source: 'ac6', target: 'ac10', label: 'Publish Event', animated: true, style: { stroke: '#6B7280', strokeWidth: 1.5 } },
        { id: 'e10', source: 'ac6', target: 'ac11', label: 'APM Logs', animated: false, style: { stroke: '#10B981', strokeWidth: 1.5 } },
      ]

      techRecommendations = [
        { category: 'Frontend', technology: 'React 18 + TypeScript', confidence: 95, reason: 'Provides component-driven reuse, type-safety, and optimized virtual DOM updates for employee tables.', alternatives: ['Angular 17', 'Vue.js 3'] },
        { category: 'Backend', technology: 'Python + FastAPI', confidence: 90, reason: 'Asynchronous Python performance, auto OpenAPI specs generator, and seamless Python AI package matches.', alternatives: ['.NET 8', 'Node.js'] },
        { category: 'Database', technology: 'PostgreSQL 16', confidence: 93, reason: 'Highly reliable open-source relational database supporting JSON columns and rich indexing formats.', alternatives: ['MySQL 8', 'MongoDB'] }
      ]
    } else {
      // Angular + Spring Boot + MongoDB
      nodes = [
        createNode('ac1', 'Users', 'Client', 'Browser / Mobile', '-', 'Presentation', 'Users', 400, 0),
        createNode('ac2', 'Web Portal', 'Frontend', 'Angular 17 + TypeScript', 'AWS Amplify', 'Presentation', 'Globe', 400, 90),
        createNode('ac3', 'CDN', 'Content Delivery', 'Amazon CloudFront', 'AWS CloudFront', 'Presentation', 'Cloud', 650, 90),
        createNode('ac4', 'API Gateway', 'Gateway', 'Spring Cloud Gateway', 'AWS ECS', 'Middleware', 'Shield', 400, 200),
        createNode('ac5', 'Auth Service', 'Microservice', 'Spring Security OAuth2', 'Keycloak', 'Backend', 'Key', 150, 320),
        createNode('ac6', 'Core Application', 'Backend App', 'Java Spring Boot 3', 'AWS ECS Fargate', 'Backend', 'Server', 400, 320),
        createNode('ac7', 'MongoDB Atlas', 'Database', 'MongoDB 7', 'MongoDB Atlas Cloud', 'Data', 'Database', 250, 460),
        createNode('ac8', 'S3 Storage', 'Storage', 'AWS S3', 'Amazon S3 Bucket', 'Data', 'HardDrive', 550, 460),
        createNode('ac9', 'AI Core Service', 'AI Engine', 'OpenAI API (RAG)', 'AWS Bedrock Integration', 'Backend', 'Brain', 650, 320),
        createNode('ac10', 'Apache Kafka', 'Messaging', 'Kafka Cluster', 'Amazon MSK', 'Infrastructure', 'ArrowLeftRight', 150, 460),
        createNode('ac11', 'Observability Stack', 'Monitoring', 'Prometheus + Grafana', 'Amazon CloudWatch', 'Infrastructure', 'Activity', 400, 580),
      ]

      edges = [
        { id: 'e1', source: 'ac1', target: 'ac2', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e2', source: 'ac2', target: 'ac3', animated: false, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e3', source: 'ac2', target: 'ac4', label: 'HTTPS', animated: true, style: { stroke: '#3B82F6', strokeWidth: 2 } },
        { id: 'e4', source: 'ac4', target: 'ac5', label: 'Authenticate', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
        { id: 'e5', source: 'ac4', target: 'ac6', label: 'Route Call', animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } },
        { id: 'e6', source: 'ac6', target: 'ac7', label: 'Read/Write', animated: true, style: { stroke: '#F59E0B', strokeWidth: 1.5 } },
        { id: 'e7', source: 'ac6', target: 'ac8', label: 'Store Asset', animated: true, style: { stroke: '#10B981', strokeWidth: 1.5 } },
        { id: 'e8', source: 'ac6', target: 'ac9', label: 'Prompt RAG', animated: true, style: { stroke: '#8B5CF6', strokeWidth: 1.5 } },
        { id: 'e9', source: 'ac6', target: 'ac10', label: 'Publish Event', animated: true, style: { stroke: '#6B7280', strokeWidth: 1.5 } },
        { id: 'e10', source: 'ac6', target: 'ac11', label: 'APM Logs', animated: false, style: { stroke: '#10B981', strokeWidth: 1.5 } },
      ]

      techRecommendations = [
        { category: 'Frontend', technology: 'Angular 17 + TypeScript', confidence: 95, reason: 'Provides strict modules, enterprise testing configurations, and comprehensive framework coverage.', alternatives: ['React', 'Vue.js 3'] },
        { category: 'Backend', technology: 'Java Spring Boot 3', confidence: 91, reason: 'Robust backend multi-threading, Spring Security integration, and stable JVM container layers.', alternatives: ['.NET 8', 'Go'] },
        { category: 'Database', technology: 'MongoDB 7', confidence: 94, reason: 'Flexible JSON collection schemas suitable for rapid OKR variations and review templates.', alternatives: ['Cosmos DB', 'PostgreSQL'] }
      ]
    }

    recommendations = [
      { id: 'REC1', title: 'Add API Rate Limiting', reason: 'No rate limiting detected on API Gateway. External-facing APIs are vulnerable to abuse and DDoS attacks.', impact: 'Critical', priority: 1, category: 'Security', applied: false },
      { id: 'REC2', title: 'Implement Circuit Breaker Pattern', reason: 'External integrations (ADP, SendGrid) lack fault tolerance. Service failures could cascade through the system.', impact: 'High', priority: 2, category: 'Reliability', applied: false },
      { id: 'REC3', title: 'Add Redis Cache Layer', reason: 'Frequently accessed data (employee profiles, org chart) should be cached to reduce database load by ~60%.', impact: 'High', priority: 3, category: 'Performance', applied: true },
      { id: 'REC4', title: 'Enable Disaster Recovery', reason: 'No DR configuration detected. Critical enterprise system requires cross-region failover and automated backup.', impact: 'Critical', priority: 4, category: 'Reliability', applied: false },
      { id: 'REC5', title: 'Add Field-Level Encryption', reason: 'PII data (SSN, salary, medical records) requires field-level encryption beyond TLS for GDPR/SOX compliance.', impact: 'Critical', priority: 5, category: 'Security', applied: false },
    ]

    validations = [
      { id: 'VW1', title: 'Authentication Service - Single Point of Failure', priority: 'Critical', description: 'Authentication service has no redundancy configured. A failure would lock out all users.', recommendedFix: 'Deploy Auth Service in active-active configuration across availability zones', category: 'Reliability', resolved: false },
      { id: 'VW2', title: 'Missing Audit Logging on DELETE Operations', priority: 'Critical', description: 'DELETE operations on Employee and Leave endpoints lack comprehensive audit trail logging.', recommendedFix: 'Add middleware to capture all destructive operations with before/after state', category: 'Compliance', resolved: false },
      { id: 'VW3', title: 'No CORS Policy Defined', priority: 'High', description: 'API Gateway lacks explicit CORS policy configuration, potentially allowing unauthorized cross-origin requests.', recommendedFix: 'Configure strict CORS whitelist on API Gateway with allowed origins and methods', category: 'Security', resolved: false },
    ]

    healthMetrics = [
      { name: 'Completeness', score: 85, maxScore: 100, recommendations: ['Add disaster recovery configuration', 'Define data backup strategy'] },
      { name: 'Security', score: 72, maxScore: 100, recommendations: ['Implement field-level encryption', 'Add API rate limiting'] },
      { name: 'Performance', score: 88, maxScore: 100, recommendations: ['Add connection pooling'] },
      { name: 'Scalability', score: 92, maxScore: 100, recommendations: [] },
    ]

    versions = [
      { id: 'v3', version: 'v3.0', name: 'Microservices & Cache Layer Integration', date: '2026-07-14', changes: 'Configured Redis Cache layer and split backend into separate Microservices.', components: 17, connections: 17, author: 'AI Architect' },
      { id: 'v2', version: 'v2.0', name: 'API Gateway & Security Update', date: '2026-07-10', changes: 'Introduced API Gateway, Auth Service, and logging.', components: 12, connections: 11, author: 'AI Architect' },
      { id: 'v1', version: 'v1.0', name: 'Initial Architecture Draft', date: '2026-07-08', changes: 'Basic monolith structure with relational SQL database.', components: 6, connections: 5, author: 'AI Architect' },
    ]
  }

  return {
    nodes,
    edges,
    recommendations,
    techStack: techRecommendations,
    validations,
    healthMetrics,
    versions,
  }
}

// Generate Database schema based on database type selected
export function generateDatabaseForType(dbType: string): DBEntity[] {
  const normalized = dbType.toLowerCase()
  const isDoc = normalized.includes('mongo') || normalized.includes('cosmos') || normalized.includes('document')
  const isGraph = normalized.includes('neo4j') || normalized.includes('graph')
  const isWideColumn = normalized.includes('cassandra') || normalized.includes('wide') || normalized.includes('column')
  const isKeyValue = normalized.includes('redis') || normalized.includes('key') || normalized.includes('val')
  const isDynamo = normalized.includes('dynamo')

  if (isDoc) {
    // Document Database schema (MongoDB/Cosmos DB)
    return [
      {
        id: 'E1', name: 'employees', description: 'Employee profiles and details (Document Collection)',
        fields: [
          { name: '_id', type: 'ObjectId', pk: true, description: 'Unique document identifier' },
          { name: 'firstName', type: 'String', description: 'Employee first name' },
          { name: 'lastName', type: 'String', description: 'Employee last name' },
          { name: 'email', type: 'String', description: 'Corporate email address' },
          { name: 'department', type: 'Object { id: ObjectId, name: String }', description: 'Nested department subdocument' },
          { name: 'managerId', type: 'ObjectId', nullable: true, description: 'Reporting manager ID' },
          { name: 'designation', type: 'String', description: 'Job title' },
          { name: 'skills', type: 'Array [String]', description: 'List of employee skills' },
          { name: 'joinDate', type: 'Date', description: 'Date of joining' },
          { name: 'status', type: 'String (active|on_leave|terminated)', description: 'Employment status' },
          { name: 'location', type: 'String', description: 'Work office location' }
        ]
      },
      {
        id: 'E2', name: 'departments', description: 'Departments and hierarchy details (Document Collection)',
        fields: [
          { name: '_id', type: 'ObjectId', pk: true, description: 'Unique department ID' },
          { name: 'name', type: 'String', description: 'Department name' },
          { name: 'parentDeptId', type: 'ObjectId', nullable: true, description: 'Parent department reference' },
          { name: 'headEmployee', type: 'Object { id: ObjectId, name: String }', description: 'Department head info' },
          { name: 'costCenter', type: 'String', description: 'Cost center code' }
        ]
      },
      {
        id: 'E3', name: 'reviews', description: 'Performance reviews and 360 feedback (Document Collection)',
        fields: [
          { name: '_id', type: 'ObjectId', pk: true, description: 'Unique review record ID' },
          { name: 'employeeId', type: 'ObjectId', fk: 'employees._id', description: 'Target employee' },
          { name: 'reviewCycle', type: 'String (Q1-2026)', description: 'Quarterly/annual cycle key' },
          { name: 'overallRating', type: 'Number (Decimal)', description: 'Overall rating score' },
          { name: 'status', type: 'String', description: 'Cycle status' },
          { name: 'feedbackList', type: 'Array [Object { reviewerId: ObjectId, comment: String }]', description: 'Nested peer/manager feedbacks' }
        ]
      },
      {
        id: 'E4', name: 'goals', description: 'Employee goals and OKRs (Document Collection)',
        fields: [
          { name: '_id', type: 'ObjectId', pk: true, description: 'Unique goal ID' },
          { name: 'employeeId', type: 'ObjectId', fk: 'employees._id', description: 'Goal owner' },
          { name: 'title', type: 'String', description: 'Goal title' },
          { name: 'description', type: 'String', description: 'Goal details' },
          { name: 'progress', type: 'Number (0-100)', description: 'Progress percentage' },
          { name: 'keyResults', type: 'Array [Object { krId: String, title: String, completed: Boolean }]', description: 'List of Measurable Key Results' }
        ]
      }
    ]
  } else if (isGraph) {
    // Graph Database schema (Neo4j)
    return [
      {
        id: 'E1', name: 'Employee (Node)', description: 'Represents employee entities in the graph',
        fields: [
          { name: 'employeeId', type: 'String (Property)', pk: true, description: 'Unique business identifier' },
          { name: 'name', type: 'String (Property)', description: 'Full name' },
          { name: 'email', type: 'String (Property)', description: 'Corporate email' },
          { name: 'designation', type: 'String (Property)', description: 'Job title' },
          { name: 'REPORTS_TO (Edge)', type: 'Relationship', fk: 'Employee', description: 'Points to manager employee node' },
          { name: 'BELONGS_TO (Edge)', type: 'Relationship', fk: 'Department', description: 'Connects employee to their department node' },
          { name: 'HAS_GOAL (Edge)', type: 'Relationship', fk: 'Goal', description: 'Connects employee to goals' }
        ]
      },
      {
        id: 'E2', name: 'Department (Node)', description: 'Represents organizational department nodes',
        fields: [
          { name: 'departmentId', type: 'String (Property)', pk: true, description: 'Unique department ID' },
          { name: 'name', type: 'String (Property)', description: 'Department department name' },
          { name: 'costCenter', type: 'String (Property)', description: 'Associated cost center' },
          { name: 'SUB_DEPARTMENT_OF (Edge)', type: 'Relationship', fk: 'Department', description: 'Connects to parent department' }
        ]
      },
      {
        id: 'E3', name: 'Goal (Node)', description: 'Represents goal nodes in the organization',
        fields: [
          { name: 'goalId', type: 'String (Property)', pk: true, description: 'Unique goal ID' },
          { name: 'title', type: 'String (Property)', description: 'Goal title' },
          { name: 'progress', type: 'Integer (Property)', description: 'Progress score (0-100)' },
          { name: 'ALIGNS_WITH (Edge)', type: 'Relationship', fk: 'Goal', description: 'Links sub-goals to company objectives' }
        ]
      },
      {
        id: 'E4', name: 'LeaveRequest (Node)', description: 'Represents leave requests in the organization',
        fields: [
          { name: 'requestId', type: 'String (Property)', pk: true, description: 'Leave request ID' },
          { name: 'leaveType', type: 'String (Property)', description: 'Sick, annual, personal' },
          { name: 'days', type: 'Float (Property)', description: 'Count of days requested' },
          { name: 'APPROVED_BY (Edge)', type: 'Relationship', fk: 'Employee', description: 'Connects request to approving manager' }
        ]
      }
    ]
  } else if (isWideColumn) {
    // Wide-Column (Cassandra)
    return [
      {
        id: 'E1', name: 'employees_by_department', description: 'Employee lookup table partitioned by department_id',
        fields: [
          { name: 'department_id', type: 'uuid', pk: true, description: 'Partition Key' },
          { name: 'employee_id', type: 'uuid', pk: true, description: 'Clustering Key (ASC)' },
          { name: 'first_name', type: 'text', description: 'Regular column' },
          { name: 'last_name', type: 'text', description: 'Regular column' },
          { name: 'email', type: 'text', description: 'Regular column' },
          { name: 'designation', type: 'text', description: 'Regular column' }
        ]
      },
      {
        id: 'E2', name: 'reviews_by_employee_year', description: 'Performance reviews table partitioned by employee_id and sorted by review_year',
        fields: [
          { name: 'employee_id', type: 'uuid', pk: true, description: 'Partition Key' },
          { name: 'review_year', type: 'int', pk: true, description: 'Clustering Key (DESC)' },
          { name: 'review_id', type: 'uuid', pk: true, description: 'Clustering Key (ASC)' },
          { name: 'reviewer_id', type: 'uuid', description: 'Regular column' },
          { name: 'rating', type: 'decimal', description: 'Regular column' },
          { name: 'status', type: 'text', description: 'Regular column' }
        ]
      },
      {
        id: 'E3', name: 'goals_by_status', description: 'Goals lookup table partitioned by status',
        fields: [
          { name: 'status', type: 'text', pk: true, description: 'Partition Key' },
          { name: 'goal_id', type: 'uuid', pk: true, description: 'Clustering Key' },
          { name: 'employee_id', type: 'uuid', description: 'Regular column' },
          { name: 'title', type: 'text', description: 'Regular column' },
          { name: 'progress', type: 'int', description: 'Regular column' }
        ]
      }
    ]
  } else if (isKeyValue) {
    // Key-Value Store (Redis)
    return [
      {
        id: 'E1', name: 'user:session:<session_id>', description: 'Session hashes tracking active user logins (Hash Key)',
        fields: [
          { name: 'userId', type: 'Hash Field', pk: true, description: 'Logged in employee identifier' },
          { name: 'role', type: 'Hash Field', description: 'RBAC user role' },
          { name: 'createdAt', type: 'Hash Field', description: 'Session creation timestamp' },
          { name: 'TTL', type: '3600 seconds', description: 'Key expiration duration' }
        ]
      },
      {
        id: 'E2', name: 'dept:employees:<dept_id>', description: 'Sets storing employee ids under each department (Set Key)',
        fields: [
          { name: 'members', type: 'Set Value (String)', pk: true, description: 'Unique list of employee IDs' },
          { name: 'TTL', type: 'Persistent', description: 'Permanent key' }
        ]
      },
      {
        id: 'E3', name: 'performance:review:cache:<review_id>', description: 'Cached review JSON payloads (String Key)',
        fields: [
          { name: 'value', type: 'String (JSON)', pk: true, description: 'Serialized review details object' },
          { name: 'TTL', type: '7200 seconds', description: 'Cache expiration (2 hours)' }
        ]
      },
      {
        id: 'E4', name: 'notification:queue', description: 'List queue for outbound email reminders (List Key)',
        fields: [
          { name: 'elements', type: 'List Element (String)', pk: true, description: 'Raw email notification payloads' },
          { name: 'TTL', type: 'Persistent', description: 'Permanent queue' }
        ]
      }
    ]
  } else if (isDynamo) {
    // DynamoDB single-table design representation
    return [
      {
        id: 'E1', name: 'employees_table', description: 'DynamoDB table storing employee profiles and details (Single-Table Design)',
        fields: [
          { name: 'PK', type: 'String (DEPARTMENT#<dept_id>)', pk: true, description: 'Partition Key' },
          { name: 'SK', type: 'String (EMPLOYEE#<employee_id>)', pk: true, description: 'Sort Key' },
          { name: 'email', type: 'String', description: 'Employee corporate email' },
          { name: 'firstName', type: 'String', description: 'Employee first name' },
          { name: 'lastName', type: 'String', description: 'Employee last name' },
          { name: 'designation', type: 'String', description: 'Job title / designation' },
          { name: 'status', type: 'String (active|on_leave|terminated)', description: 'Employment status' },
          { name: 'location', type: 'String', description: 'Work office location' }
        ]
      },
      {
        id: 'E2', name: 'reviews_table', description: 'DynamoDB table storing performance reviews and 360 feedback',
        fields: [
          { name: 'PK', type: 'String (EMPLOYEE#<employee_id>)', pk: true, description: 'Partition Key' },
          { name: 'SK', type: 'String (REVIEW#<review_id>)', pk: true, description: 'Sort Key' },
          { name: 'overallRating', type: 'Number (Decimal)', description: 'Overall review score' },
          { name: 'status', type: 'String (submitted|approved)', description: 'Review approval status' },
          { name: 'reviewCycle', type: 'String', description: 'Review cycle key (e.g. Q2-2026)' }
        ]
      },
      {
        id: 'E3', name: 'goals_table', description: 'DynamoDB table storing employee goals and OKR metrics',
        fields: [
          { name: 'PK', type: 'String (EMPLOYEE#<employee_id>)', pk: true, description: 'Partition Key' },
          { name: 'SK', type: 'String (GOAL#<goal_id>)', pk: true, description: 'Sort Key' },
          { name: 'title', type: 'String', description: 'Goal title' },
          { name: 'progress', type: 'Number (0-100)', description: 'Goal completion percentage' }
        ]
      }
    ]
  } else {
    // Relational SQL Database Schema (SQL Server/MySQL/PostgreSQL/Oracle)
    return [
      {
        id: 'E1', name: 'Employee', description: 'Core employee master data',
        fields: [
          { name: 'employee_id', type: 'UUID', pk: true, description: 'Unique employee identifier' },
          { name: 'first_name', type: 'VARCHAR(100)', description: 'Employee first name' },
          { name: 'last_name', type: 'VARCHAR(100)', description: 'Employee last name' },
          { name: 'email', type: 'VARCHAR(255)', description: 'Corporate email address' },
          { name: 'department_id', type: 'UUID', fk: 'Department.department_id', description: 'FK to Department' },
          { name: 'manager_id', type: 'UUID', fk: 'Employee.employee_id', nullable: true, description: 'FK to reporting manager' },
          { name: 'designation', type: 'VARCHAR(200)', description: 'Job title / designation' },
          { name: 'join_date', type: 'DATE', description: 'Date of joining' },
          { name: 'status', type: 'VARCHAR(50)', description: 'active, on_leave, terminated' },
        ]
      },
      {
        id: 'E2', name: 'Department', description: 'Organizational departments and hierarchy',
        fields: [
          { name: 'department_id', type: 'UUID', pk: true, description: 'Unique department identifier' },
          { name: 'name', type: 'VARCHAR(200)', description: 'Department name' },
          { name: 'parent_department_id', type: 'UUID', fk: 'Department.department_id', nullable: true, description: 'Parent department for hierarchy' },
          { name: 'head_employee_id', type: 'UUID', fk: 'Employee.employee_id', nullable: true, description: 'Department head' },
          { name: 'cost_center', type: 'VARCHAR(50)', description: 'Cost center code' },
        ]
      },
      {
        id: 'E3', name: 'PerformanceReview', description: 'Performance review cycles and ratings',
        fields: [
          { name: 'review_id', type: 'UUID', pk: true, description: 'Unique review identifier' },
          { name: 'employee_id', type: 'UUID', fk: 'Employee.employee_id', description: 'Employee being reviewed' },
          { name: 'reviewer_id', type: 'UUID', fk: 'Employee.employee_id', description: 'Reviewer' },
          { name: 'review_cycle', type: 'VARCHAR(20)', description: 'Review cycle (e.g., Q2-2026)' },
          { name: 'overall_rating', type: 'DECIMAL(3,2)', nullable: true, description: 'Overall rating' },
          { name: 'status', type: 'VARCHAR(50)', description: 'submitted, approved' }
        ]
      },
      {
        id: 'E4', name: 'Goal', description: 'Employee goals and OKRs',
        fields: [
          { name: 'goal_id', type: 'UUID', pk: true, description: 'Unique goal identifier' },
          { name: 'employee_id', type: 'UUID', fk: 'Employee.employee_id', description: 'Goal owner' },
          { name: 'title', type: 'VARCHAR(500)', description: 'Goal title' },
          { name: 'progress', type: 'INTEGER', description: 'Progress percentage (0-100)' },
          { name: 'status', type: 'VARCHAR(50)', description: 'on_track, completed, at_risk' }
        ]
      }
    ]
  }
}

// Generate reports section for Project
export function generateReportForProject(project: any, docs: any[], stats: any): { sections: ReportSection[] } {
  const docListStr = docs.map(d => `- **${d.documentInfo.name}** (${d.documentInfo.type}) - ${d.documentInfo.pages} pages, size: ${d.documentInfo.size}, parsed with ${d.documentInfo.confidence}% AI confidence.`).join('\n')

  return {
    sections: [
      {
        title: 'Cover Page',
        content: `**AI SOLUTION ARCHITECT COPILOT**
# SYSTEM ARCHITECTURE & BLUEPRINT REPORT

**Project Name**: ${project.name}
**Description**: ${project.description || 'Enterprise Solution Architecture & Systems Integration Blueprint.'}
**Date**: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
**Report Version**: 1.0 (Draft Blueprint)
**Author**: AI Copilot Systems Architect
**Classification**: Enterprise Confidential`
      },
      {
        title: 'Table of Contents',
        content: `1. **Cover Page**
2. **Table of Contents**
3. **Executive Summary**
4. **Project Overview**
5. **Uploaded Documents Summary**
6. **Requirement Analysis**
7. **Actors & Personas**
8. **Business Modules**
9. **Business Flow & Workflows**
10. **Solution Architecture Blueprint**
11. **Selected Technology Stack**
12. **Database Design & Models**
13. **Risks & Assumptions**
14. **Recommendations**
15. **Future Enhancements**
16. **Appendix**`
      },
      {
        title: 'Executive Summary',
        content: `This executive solution report details the architectural blueprint and systems analysis for the project "${project.name}". Based on automated AI parsing of ${stats.requirementsCount} requirements across ${stats.modulesCount} business modules, a modern technology stack based on **${stats.techStack}** has been designed. 

Key Metrics Summary:
- **Project Scope**: ${stats.modulesCount} business modules analyzed.
- **Architectural Footprint**: 11 core components mapped across 5 layers.
- **Data Blueprint**: ${stats.dbEntitiesCount} database entities/collections structured using **${stats.database}**.
- **AI Engine Health Index**: 85% overall confidence.

The recommended stack provides maximum scalability, robust security frameworks, and direct alignment with the enterprise compliance guidelines.`
      },
      {
        title: 'Project Overview',
        content: `The project "${project.name}" aims to resolve key business operational bottlenecks.
Description: ${project.description || 'Enterprise integration and automation project.'}

This document details the functional specifications, high-level requirements, and technical solution blueprints. By consolidating multiple source documents, the AI Copilot has compiled a single source of truth for the engineering, product, and architectural teams.`
      },
      {
        title: 'Uploaded Documents Summary',
        content: `The solution is designed based on the following input documents parsed by the AI processor:
${docListStr}

Each file was analyzed for actors, functional features, performance SLAs, and constraints. Cross-document reference validation was executed to identify gaps and conflicting business rules.`
      },
      {
        title: 'Requirement Analysis',
        content: `A total of **${stats.requirementsCount} requirements** were extracted from the documentation:
- **Functional Requirements**: Encompasses core portal interactions, workflow management, multi-channel notifications, and backend microservice triggers.
- **Non-Functional Requirements**: Mapped against performance SLAs (e.g., sub-200ms API response times), horizontal scalability metrics (10,000+ concurrent users), and data encryption protocols (AES-256 at rest, TLS 1.3 in transit).

The requirements are categorized by priority and validated for technical consistency.`
      },
      {
        title: 'Actors',
        content: `The system supports the following principal roles and external actors:
- **Business Analyst**: Initiates projects, uploads specifications, views requirements, reviews business flows, and exports reports.
- **Solution Architect**: Designs technologies, configures nodes, overrides deployment variables, and generates data structures.
- **Enterprise Architect**: Reviews security profiles, evaluates risk parameters, and issues project approvals.
- **Delivery Manager**: Reviews dashboards, exports charts, tracks progress SLAs, and coordinates sprint pipelines.
- **Admin**: Configures RBAC permissions, manages global settings, and audits session access logs.`
      },
      {
        title: 'Business Modules',
        content: `The solution is partitioned into the following functional business modules:
1. **Core Service Portal**: High-priority user interface and self-service integrations.
2. **Operations & Workflows**: Approval workflows, delegation, and scheduling engines.
3. **Analytics & Performance Tracking**: Real-time KPI dashboard, executive reporting, and history logs.
4. **Notification Gateway**: Multi-channel alerts (SMS, email, push notifications) and dispatch scheduling.
5. **Auditing & Compliance**: SOX/GDPR-compliant logging and historical change tracking.`
      },
      {
        title: 'Business Flow',
        content: `The process flow captures end-to-end user journeys:
- **Authentication Flow**: Validates credentials via SSO Identity Providers and issues JWT tokens.
- **Core Operations Workflows**: Initiates requests, runs validation logic, coordinates approval steps, and fires notification dispatch events.
- **Reporting & Sync Pipeline**: Aggregates raw transactions, executes batch analysis, and pushes data to downstream payroll/compliance sync endpoints.`
      },
      {
        title: 'Solution Architecture',
        content: `A microservices-based, containerized cloud architecture is recommended. It is structured into 5 tiers:
- **Presentation Layer**: Static web app hosting paired with a global CDN for optimized asset loading.
- **API Gateway/Middleware**: Centralized routing, authentication validation, and API rate limiting.
- **Backend Services**: Separate Dockerized container services executing core business operations.
- **Data Layer**: Relational/NoSQL database nodes, low-latency Redis cache replication, and secure object storage.
- **Infrastructure Layer**: Centralized message queuing, health monitoring, and audit log aggregation.`
      },
      {
        title: 'Selected Technology Stack',
        content: `The recommended tech stack is **${stats.techStack}**.

Technical Merits:
- **Frontend Framework**: Provides enterprise component scalability, fast routing, and type safety.
- **Backend Engines**: Offers high throughput APIs, asynchronous processing loops, and low resource overhead.
- **Database Engine (${stats.database})**: Guarantees data durability, transactional integrity, and optimized indexing configurations.
- **Observability**: Prometheus, Grafana, and ELK frameworks are recommended to achieve full operational visibility.`
      },
      {
        title: 'Database Design',
        content: `The data model is structured using **${stats.database}** specifications:
- **Primary Schema**: Configured with ${stats.dbEntitiesCount} main entities/collections handling master data.
- **Relationships**: Mapped through references (relational FKs, document embedding, or graph edges).
- **Security**: Field-level encryption is planned for fields containing PII data. Caching is enabled for high-read master tables.`
      },
      {
        title: 'Risks & Assumptions',
        content: `- **Assumption 1**: Active Directory or corporate Okta is configured for OIDC SSO.
- **Assumption 2**: Storage nodes will use cloud-native encrypted buckets with standard replication.
- **Risk 1**: Third-party API rate limits could impact sync schedules. *Mitigation*: Implement request queueing and dead-letter queues.
- **Risk 2**: Data quality during migration from legacy spreadsheets. *Mitigation*: Perform automated validation checks before import.`
      },
      {
        title: 'Recommendations',
        content: `1. **Rate Limiting**: Apply throttling on API gateways.
2. **Fault Tolerance**: Configure circuit breakers for external payroll integrations.
3. **Session Cache**: Use Redis to store sessions and cache frequent profile queries.
4. **Data Isolation**: Verify data residency constraints for compliance.`
      },
      {
        title: 'Future Enhancements',
        content: `1. **Multi-Region Failover**: Introduce cross-region active-active database clusters for hot disaster recovery.
2. **AI RAG Extensions**: Integrate vector-based search across historical project reports to automate solution discovery.
3. **Event-Driven Architecture**: Migrate REST notifications to reactive publish-subscribe messaging pipelines.`
      },
      {
        title: 'Appendix',
        content: `1. **API Specifications**: Draft blueprints for REST endpoints.
2. **Compliance Mappings**: SOC2 and GDPR checklist alignment audits.
3. **Developer Onboarding Guide**: Initial environment configuration instructions.`
      }
    ]
  }
}
