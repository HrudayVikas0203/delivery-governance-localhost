import { describe, expect, it } from 'vitest'
import { convertToMermaid, convertDBToSQL } from '../services/exportService'
import { sanitizeInput, checkRateLimit } from '../services/securityService'
import { computeItemDiffs, summarizeArtifactDiff } from '../services/versionDiffService'

describe('security utilities', () => {
  it('sanitizes script tags', () => {
    const raw = '<script>alert("xss")</script>'
    const sanitized = sanitizeInput(raw)

    expect(sanitized).not.toContain('<script>')
    expect(sanitized).toContain('&lt;script&gt;')
  })

  it('enforces the client-side rate limit window', () => {
    const key = `test-client-ip-${Date.now()}`

    for (let i = 0; i < 5; i += 1) {
      checkRateLimit(key, 5, 60_000)
    }

    expect(checkRateLimit(key, 5, 60_000)).toBe(false)
  })
})

describe('export utilities', () => {
  it('converts database entities into SQL DDL', () => {
    const entities = [
      {
        id: 'e1',
        name: 'Employee',
        description: 'Employee entity',
        fields: [
          { name: 'id', type: 'UUID', pk: true, description: 'PK' },
          { name: 'email', type: 'VARCHAR(255)', description: 'Email' },
        ],
      },
    ]

    const sql = convertDBToSQL(entities)

    expect(sql).toContain('CREATE TABLE employee')
    expect(sql).toContain('id UUID PRIMARY KEY')
  })

  it('converts flow data into Mermaid format', () => {
    const nodes = [{ id: 'n1', data: { label: 'Start Step' }, position: { x: 0, y: 0 } }]
    const edges = [{ id: 'e1', source: 'n1', target: 'n2', label: 'Flow' }]

    const mermaid = convertToMermaid(nodes as never, edges as never, 'Test Diagram')

    expect(mermaid).toContain('graph TD')
    expect(mermaid).toContain('n1["Start Step"]')
  })
})

describe('version diff utilities', () => {
  it('summarizes added, removed, and modified items', () => {
    const itemsA = [{ id: 'req-1', title: 'Login with OAuth' }, { id: 'req-2', title: 'Export PDF' }]
    const itemsB = [{ id: 'req-1', title: 'Login with OAuth2 & MFA' }, { id: 'req-3', title: 'Push Notifications' }]

    const diffs = computeItemDiffs(itemsA, itemsB, (item) => item.title)
    const summary = summarizeArtifactDiff('Requirements', 1, 2, diffs)

    expect(summary.addedCount).toBe(1)
    expect(summary.removedCount).toBe(1)
    expect(summary.modifiedCount).toBe(1)
  })
})

describe('dashboard requirement module aggregation', () => {
  it('correctly aggregates requirements by module dynamically', () => {
    const modules = [{ id: 'm1', name: 'Lead Management' }, { id: 'm2', name: 'Opportunity Pipeline' }]
    const functional = [
      { id: 'r1', code: 'FR-1', title: 'Lead Form', module: 'Lead Management' },
      { id: 'r2', code: 'FR-2', title: 'Lead Scoring', module: 'Lead Management' },
      { id: 'r3', code: 'FR-3', title: 'Pipeline View', module: 'Opportunity Pipeline' },
    ]
    const nonFunctional = [
      { id: 'nf1', code: 'NFR-1', title: 'Uptime', module: 'System-Wide' },
      { id: 'nf2', code: 'NFR-2', title: 'Latency', module: 'System-Wide' },
    ]

    const knownMap = new Map<string, string>()
    modules.forEach(m => knownMap.set(m.name.toLowerCase(), m.name))

    const matchModuleName = (raw: string): string => {
      const lower = raw.toLowerCase()
      if (knownMap.has(lower)) return knownMap.get(lower)!
      for (const [kLower, kDisplay] of knownMap.entries()) {
        if (lower.includes(kLower) || kLower.includes(lower)) return kDisplay
      }
      return raw
    }

    const allReqs = [...functional, ...nonFunctional]
    const map = new Map<string, { fullName: string; count: number }>()

    allReqs.forEach(r => {
      const matched = matchModuleName(r.module)
      const k = matched.toLowerCase()
      const existing = map.get(k)
      if (existing) {
        existing.count += 1
      } else {
        map.set(k, { fullName: matched, count: 1 })
      }
    })

    const items = Array.from(map.values()).filter(i => i.count > 0)
    const totalCount = items.reduce((a, b) => a + b.count, 0)
    expect(totalCount).toBe(5)
    expect(map.get('lead management')?.count).toBe(2)
    expect(map.get('opportunity pipeline')?.count).toBe(1)
    expect(map.get('system-wide')?.count).toBe(2)
  })

  it('handles fuzzy module name matching between requirements and business modules', () => {
    const modules = [{ id: 'm1', name: 'Core Processing Module' }, { id: 'm2', name: 'Identity & Access Management' }]
    const requirements = [
      { id: 'r1', module: 'Core Module' },
      { id: 'r2', module: 'Core Module' },
      { id: 'r3', module: 'Identity Management' },
      { id: 'r4', module: 'Infrastructure' },
    ]

    const knownMap = new Map<string, string>()
    modules.forEach(m => knownMap.set(m.name.toLowerCase(), m.name))

    const matchModuleName = (raw: string): string => {
      if (!raw || raw === 'Unassigned') return 'Unassigned'
      const lower = raw.toLowerCase().trim()
      if (knownMap.has(lower)) return knownMap.get(lower)!
      for (const [kLower, kDisplay] of knownMap.entries()) {
        if (lower.includes(kLower) || kLower.includes(lower)) return kDisplay
      }
      const stopWords = new Set(['and', '&', 'the', 'of', 'for', 'in', 'to', 'module', 'management', 'engine', 'system', 'processing', 'service', 'services'])
      const rawTokens = lower.split(/[\s\-_\/]+/).filter(w => w.length > 0 && !stopWords.has(w))
      if (rawTokens.length > 0) {
        let bestMatch: { display: string; overlapScore: number } | null = null
        for (const [kLower, kDisplay] of knownMap.entries()) {
          const kTokens = new Set(kLower.split(/[\s\-_\/]+/).filter(w => w.length > 0 && !stopWords.has(w)))
          let matchCount = 0
          for (const token of rawTokens) {
            if (kTokens.has(token)) matchCount++
          }
          if (matchCount > 0 && (!bestMatch || matchCount > bestMatch.overlapScore)) {
            bestMatch = { display: kDisplay, overlapScore: matchCount }
          }
        }
        if (bestMatch) return bestMatch.display
      }
      return raw
    }

    const map = new Map<string, number>()
    requirements.forEach(r => {
      const mod = matchModuleName(r.module).toLowerCase()
      map.set(mod, (map.get(mod) || 0) + 1)
    })

    const totalCount = Array.from(map.values()).reduce((a, b) => a + b, 0)
    expect(totalCount).toBe(4)
    expect(map.get('core processing module')).toBe(2)
    expect(map.get('identity & access management')).toBe(1)
    expect(map.get('infrastructure')).toBe(1)
  })
})
