import {
  saveVectorEmbeddings,
  getVectorEmbeddingsByProject,
  getDocumentsByProject,
  getRequirementsByProjectId,
  getBusinessFlowsByProjectId,
  getArchitecturesByProjectId,
  type VectorEmbeddingRecord,
  type StoredDocument,
} from './db'
import { monitoring } from './monitoringService'

/**
 * Computes a TF-IDF pseudo-vector representation for text semantic search
 */
function textToPseudoVector(text: string, vocab: string[]): number[] {
  const words = text.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/)
  const wordFreq: Record<string, number> = {}
  words.forEach(w => { if (w) wordFreq[w] = (wordFreq[w] || 0) + 1 })

  return vocab.map(w => wordFreq[w] || 0)
}

/**
 * Calculates Cosine Similarity between two numeric vectors
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  let dotProduct = 0
  let normA = 0
  let normB = 0

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i]
    normA += vecA[i] * vecA[i]
    normB += vecB[i] * vecB[i]
  }

  if (normA === 0 || normB === 0) return 0
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB))
}

/**
 * Ensures that all documents and artifacts for a project are indexed into vector embeddings
 */
export async function ensureProjectIndexedForRAG(projectId: string): Promise<void> {
  const existing = await getVectorEmbeddingsByProject(projectId)
  if (existing.length > 0) return

  const docs = await getDocumentsByProject(projectId)
  const reqsList = await getRequirementsByProjectId(projectId)
  const flows = await getBusinessFlowsByProjectId(projectId)
  const archs = await getArchitecturesByProjectId(projectId)

  const embeddings: VectorEmbeddingRecord[] = []

  // 1. Index Document Texts
  for (const doc of docs) {
    if (!doc.rawContent) continue
    const textChunks = doc.rawContent.split(/\n\n+/).filter(c => c.trim().length > 20)
    const fullText = doc.rawContent.toLowerCase().replace(/[^a-z0-9\s]/g, '')
    const vocab = Array.from(new Set(fullText.split(/\s+/).filter(w => w.length > 3))).slice(0, 300)

    textChunks.forEach((chunk, idx) => {
      embeddings.push({
        id: `vec-${doc.id}-text-${idx}`,
        docId: doc.id,
        projectId: doc.projectId,
        chunkIndex: idx,
        text: chunk.trim(),
        metadata: {
          docName: doc.name,
          sectionTitle: `Document Section ${idx + 1}`,
          contentType: 'DocumentText'
        },
        vector: textToPseudoVector(chunk, vocab),
        createdAt: new Date().toISOString()
      })
    })
  }

  // 2. Index Extracted Requirements & Modules
  for (const reqRecord of reqsList) {
    const docName = docs.find(d => d.id === reqRecord.docId)?.name || 'Project Requirements'
    const reqs = reqRecord

    if (reqs.overview) {
      embeddings.push({
        id: `vec-${reqRecord.id}-overview`,
        docId: reqRecord.docId,
        projectId: reqRecord.projectId,
        chunkIndex: 2000,
        text: `Project Overview: ${reqs.overview}`,
        metadata: { docName, sectionTitle: 'Project Overview', contentType: 'Requirement' },
        vector: textToPseudoVector(reqs.overview, []),
        createdAt: new Date().toISOString()
      })
    }

    reqs.functional.forEach((f, idx) => {
      const text = `Functional Requirement [${f.code}] (${f.title}): ${f.description}. Module: ${f.module}, Priority: ${f.priority}`
      embeddings.push({
        id: `vec-${reqRecord.id}-f-${idx}`,
        docId: reqRecord.docId,
        projectId: reqRecord.projectId,
        chunkIndex: 2100 + idx,
        text,
        metadata: { docName, sectionTitle: `Functional Requirement ${f.code}`, contentType: 'Requirement', code: f.code },
        vector: textToPseudoVector(text, []),
        createdAt: new Date().toISOString()
      })
    })

    reqs.nonFunctional.forEach((nf, idx) => {
      const text = `Non-Functional Requirement [${nf.code}] (${nf.title}): ${nf.description}. Category: ${nf.category}`
      embeddings.push({
        id: `vec-${reqRecord.id}-nf-${idx}`,
        docId: reqRecord.docId,
        projectId: reqRecord.projectId,
        chunkIndex: 2200 + idx,
        text,
        metadata: { docName, sectionTitle: `NFR ${nf.code}`, contentType: 'Requirement', code: nf.code },
        vector: textToPseudoVector(text, []),
        createdAt: new Date().toISOString()
      })
    })

    reqs.modules.forEach((m, idx) => {
      const text = `Business Module [${m.name}]: ${m.description}. Priority: ${m.priority}`
      embeddings.push({
        id: `vec-${reqRecord.id}-mod-${idx}`,
        docId: reqRecord.docId,
        projectId: reqRecord.projectId,
        chunkIndex: 2300 + idx,
        text,
        metadata: { docName, sectionTitle: `Module: ${m.name}`, contentType: 'Module' },
        vector: textToPseudoVector(text, []),
        createdAt: new Date().toISOString()
      })
    })
  }

  // 3. Index Business Flow Nodes
  for (const flow of flows) {
    flow.nodes.forEach((n, idx) => {
      const text = `Business Flow Step [${n.data.label}]: Type: ${n.type || 'Step'}. ${n.data.description || ''}`
      embeddings.push({
        id: `vec-${flow.id}-flow-${idx}`,
        docId: flow.docId,
        projectId: flow.projectId,
        chunkIndex: 3000 + idx,
        text,
        metadata: { docName: 'Business Flow Diagram', sectionTitle: `Flow Step: ${n.data.label}`, contentType: 'Architecture' },
        vector: textToPseudoVector(text, []),
        createdAt: new Date().toISOString()
      })
    })
  }

  // 4. Index Architecture Microservice Components
  for (const arch of archs) {
    arch.nodes.forEach((n, idx) => {
      const text = `Architecture Component [${n.data.label}]: Layer: ${n.data.layer}, Tech: ${n.data.technology}. ${n.data.description}`
      embeddings.push({
        id: `vec-${arch.id}-arch-${idx}`,
        docId: arch.docId,
        projectId: arch.projectId,
        chunkIndex: 4000 + idx,
        text,
        metadata: { docName: 'Solution Architecture', sectionTitle: `Arch Component: ${n.data.label}`, contentType: 'Architecture' },
        vector: textToPseudoVector(text, []),
        createdAt: new Date().toISOString()
      })
    })
  }

  if (embeddings.length > 0) {
    await saveVectorEmbeddings(embeddings)
  }
}

export interface RAGSearchResult {
  docName: string
  text: string
  sectionTitle?: string
  contentType: string
  score: number
}

/**
 * Retrieves relevant contexts for a user prompt using RAG vector & keyword search
 */
export async function retrieveRAGContext(
  projectId: string,
  query: string,
  topK = 5
): Promise<RAGSearchResult[]> {
  await ensureProjectIndexedForRAG(projectId)
  const embeddings = await getVectorEmbeddingsByProject(projectId)
  if (embeddings.length === 0) return []

  const words = query.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length > 2)
  if (words.length === 0) return []

  const queryVocab = Array.from(new Set(words))
  const queryVec = textToPseudoVector(query, queryVocab)

  // Score each embedding chunk strictly within this project
  const results: RAGSearchResult[] = embeddings.map(emb => {
    const chunkText = emb.text.toLowerCase()
    let keywordScore = 0

    words.forEach(w => {
      if (chunkText.includes(w)) keywordScore += 1
    })

    if (chunkText.includes(query.toLowerCase())) keywordScore += 5

    let cosSim = 0
    if (emb.vector && emb.vector.length > 0 && queryVec.length === emb.vector.length) {
      cosSim = cosineSimilarity(queryVec, emb.vector)
    }

    const totalScore = parseFloat((keywordScore + cosSim * 3).toFixed(2))

    return {
      docName: emb.metadata?.docName || 'Project Document',
      text: emb.text,
      sectionTitle: emb.metadata?.sectionTitle || 'Section',
      contentType: emb.metadata?.contentType || 'DocumentText',
      score: totalScore
    }
  })

  const matched = results
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)

  // System Audit & Latency Logging
  monitoring.log(
    'INFO',
    'AI',
    `Retrieved ${matched.length} RAG context chunks for query "${query.slice(0, 30)}..." in project [${projectId}]`,
    12,
    {
      query,
      projectId,
      chunksRetrieved: matched.length,
      topScore: matched[0]?.score || 0,
      documentsUsed: Array.from(new Set(matched.map(m => m.docName)))
    }
  )

  console.log('[RAG Service Log]', {
    projectId,
    query,
    chunksCount: matched.length,
    scores: matched.map(m => ({ doc: m.docName, section: m.sectionTitle, score: m.score }))
  })

  return matched
}
