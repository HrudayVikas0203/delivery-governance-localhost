import {
  getDocumentRecord,
  getDocumentsByProject,
  getRequirementsByDocId,
  getRequirementsByProjectId,
  saveRequirementVersion,
  getRequirementVersions,
  getBusinessFlowByDocId,
  saveBusinessFlowVersion,
  getBusinessFlowVersions,
  getArchitectureByDocId,
  saveArchitectureVersion,
  getArchitectureVersions,
  addAuditLog,
  type StoredDocument,
  type ExtractedRequirementsRecord,
  type RequirementVersionRecord,
  type StoredBusinessFlow,
  type BusinessFlowVersionRecord,
  type StoredArchitecture,
  type ArchitectureVersionRecord,
} from './db'
import { processDocumentJob, type ProgressCallback } from './documentProcessor'
import { exportArtifactElement, type ExportFormat } from './exportService'
import { logDocumentUpload, logRequirementRegeneration, logRequirementModification } from './auditLogger'
import { apiCache } from './apiCacheService'
import { monitoring } from './monitoringService'
import { backendApi } from './backendApi'
import type { AiConfig } from '../data/aiConfig'
import type { FlowNode, FlowEdge, ArchNode, ArchEdge, Project, ExecutiveArchitectureData } from '../data/types'

export interface APIUploadResponse {
  documentId: string
  name: string
  type: string
  size: string
  uploadedAt: string
  status: StoredDocument['status']
}

/**
 * 1. Upload Document API
 */
export async function uploadDocument(file: File, projectId: string): Promise<APIUploadResponse> {
  const uploaded = await backendApi.uploadDocument(file, projectId)
  await logDocumentUpload(projectId, uploaded.documentId, file.name)
  return {
    documentId: uploaded.documentId,
    name: uploaded.name,
    type: uploaded.type,
    size: uploaded.size,
    uploadedAt: uploaded.uploadedAt,
    status: uploaded.status as StoredDocument['status'],
  }
}

/**
 * 2. Process Document API
 */
export async function processDocument(
  file: File,
  docId: string,
  projectId: string,
  aiConfig: AiConfig,
  onProgress?: ProgressCallback
): Promise<ExtractedRequirementsRecord> {
  return processDocumentJob(file, docId, projectId, aiConfig, onProgress)
}

/**
 * 3. Get Processing Status API
 */
export async function getProcessingStatus(documentId: string): Promise<{
  documentId: string
  status: StoredDocument['status']
  confidence: number
  errorDetails?: string
}> {
  const doc = await getDocumentRecord(documentId)
  if (!doc) {
    throw new Error(`Document with ID '${documentId}' not found in database.`)
  }
  return {
    documentId: doc.id,
    status: doc.status,
    confidence: doc.confidence,
    errorDetails: doc.errorDetails,
  }
}

/**
 * 4. Retrieve Extracted Requirements API
 */
export async function retrieveExtractedRequirements(
  projectId: string,
  documentId?: string
): Promise<ExtractedRequirementsRecord | ExtractedRequirementsRecord[]> {
  if (documentId) {
    const req = await getRequirementsByDocId(documentId)
    if (!req) {
      throw new Error(`No extracted requirements found for document '${documentId}'.`)
    }
    return req
  }
  return getRequirementsByProjectId(projectId)
}

/**
 * 5. Regenerate Requirements API
 */
export async function regenerateRequirements(
  projectId: string,
  documentId: string,
  aiConfig: AiConfig,
  customPrompt?: string
): Promise<ExtractedRequirementsRecord> {
  const updatedRecord = await backendApi.generateRequirements(projectId, documentId, aiConfig)
  const versionSnapshot: RequirementVersionRecord = {
    id: `ver-${documentId}-v${updatedRecord.version}`,
    docId: documentId,
    projectId,
    version: updatedRecord.version,
    timestamp: updatedRecord.updatedAt,
    author: `AI Engine (${updatedRecord.generatorModel || aiConfig.defaultModel})`,
    changeType: 'Regenerated',
    changeSummary: customPrompt
      ? `Regenerated requirements with additional guidance`
      : `Regenerated requirements v${updatedRecord.version}`,
    requirementsSnapshot: updatedRecord,
  }
  await saveRequirementVersion(versionSnapshot)
  await logRequirementRegeneration(projectId, documentId, updatedRecord.version, updatedRecord.generatorModel || aiConfig.defaultModel)
  return updatedRecord
}

/**
 * 6. Update Requirements API
 */
export async function updateRequirements(
  projectId: string,
  documentId: string,
  updatedData: Partial<ExtractedRequirementsRecord>,
  user = 'Current User'
): Promise<ExtractedRequirementsRecord> {
  const updatedRecord = await backendApi.updateRequirements(documentId, {
    ...updatedData,
    projectId,
  })
  if (!updatedRecord) {
    throw new Error(`Failed to update requirements for document '${documentId}'.`)
  }
  const versionSnapshot: RequirementVersionRecord = {
    id: `ver-${documentId}-v${updatedRecord.version}`,
    docId: documentId,
    projectId,
    version: updatedRecord.version,
    timestamp: updatedRecord.updatedAt,
    author: user,
    changeType: 'Manual_Edit',
    changeSummary: `Manual modification of requirements (Version v${updatedRecord.version})`,
    requirementsSnapshot: updatedRecord,
  }
  await saveRequirementVersion(versionSnapshot)
  await logRequirementModification(projectId, documentId, 'Manual Update', user)

  return updatedRecord
}

// ================= PHASE 3 DESIGN ENDPOINTS ================= //

/**
 * Helper to fetch aggregated requirements for a project/document
 */
async function getAggregatedProjectRequirements(
  projectId: string,
  docId: string
): Promise<ExtractedRequirementsRecord> {
  let reqs = docId ? await getRequirementsByDocId(docId) : null

  if (!reqs && docId) {
    reqs = await backendApi.getRequirements(docId, projectId).catch(() => null)
  }

  if (!reqs) {
    throw new Error(`Requirements record for project '${projectId}' not found. Please upload a document and extract requirements first.`)
  }

  return reqs
}

export type DesignProgressCallback = (step: string) => void

/**
 * 7. Generate Business Flow API with Step Progress & Detailed Audit Logging
 */
export async function generateBusinessFlowAPI(
  projectId: string,
  docId: string,
  aiConfig: AiConfig,
  onProgress?: DesignProgressCallback
): Promise<StoredBusinessFlow> {
  const startTime = Date.now()

  // Step 1: Load selected project
  onProgress?.('Preparing project...')

  // Step 2 & 3 & 4: Retrieve latest documents and requirements
  onProgress?.('Loading requirements...')
  await getAggregatedProjectRequirements(projectId, docId)

  // Step 5: Invalidate previous AI cache & build fresh prompt
  onProgress?.('Generating with AI...')
  apiCache.clear()

  // Step 6 & 7: Call backend AI API and save version
  const newFlowRecord = await backendApi.generateBusinessFlow(projectId, docId, aiConfig)
  onProgress?.('Saving version...')

  const versionSnapshot: BusinessFlowVersionRecord = {
    id: `flow-ver-${newFlowRecord.docId}-v${newFlowRecord.version}`,
    docId: newFlowRecord.docId,
    projectId,
    version: newFlowRecord.version,
    timestamp: new Date().toISOString(),
    author: `AI Engine (${aiConfig.moduleModels.businessFlow || aiConfig.defaultModel})`,
    changeType: newFlowRecord.version > 1 ? 'Regenerated' : 'AI_Generated',
    changeSummary: `Business Flow generated (v${newFlowRecord.version}) with ${newFlowRecord.nodes.length} nodes`,
    flowSnapshot: newFlowRecord,
  }

  await saveBusinessFlowVersion(versionSnapshot)

  const processingTimeMs = Date.now() - startTime

  // Requirement 10 Logging
  monitoring.log('INFO', 'AI', `Business Flow regenerated for project ${projectId}`, processingTimeMs, {
    projectId,
    docId: newFlowRecord.docId,
    savedVersion: newFlowRecord.version,
    nodesCount: newFlowRecord.nodes.length,
    edgesCount: newFlowRecord.edges.length,
    processingTimeMs,
  })

  await addAuditLog({
    projectId,
    docId: newFlowRecord.docId,
    action: 'Business Flow Regenerated',
    detail: `Regenerated Business Flow (Version v${newFlowRecord.version}) with ${newFlowRecord.nodes.length} nodes in ${processingTimeMs}ms`,
    user: 'AI Engine',
    status: 'Success'
  })

  onProgress?.('Completed.')
  return newFlowRecord
}

/**
 * 8. Save Business Flow API
 */
export async function saveBusinessFlowAPI(
  projectId: string,
  docId: string,
  nodes: FlowNode[],
  edges: FlowEdge[],
  user = 'Current User'
): Promise<StoredBusinessFlow> {
  const updatedFlowRecord = await backendApi.saveBusinessFlow(docId, projectId, nodes, edges)

  const versionSnapshot: BusinessFlowVersionRecord = {
    id: `flow-ver-${docId}-v${updatedFlowRecord.version}`,
    docId,
    projectId,
    version: updatedFlowRecord.version,
    timestamp: updatedFlowRecord.updatedAt,
    author: user,
    changeType: 'Manual_Edit',
    changeSummary: `Manual edits saved to Business Flow (v${updatedFlowRecord.version})`,
    flowSnapshot: updatedFlowRecord,
  }

  await saveBusinessFlowVersion(versionSnapshot)
  await addAuditLog({
    projectId,
    docId,
    action: 'Business Flow Saved',
    detail: `Saved manual edits to Business Flow v${updatedFlowRecord.version}`,
    user,
    status: 'Info'
  })

  return updatedFlowRecord
}

/**
 * 9. Generate Solution Architecture API with Step Progress & Detailed Audit Logging
 */
export async function generateSolutionArchitectureAPI(
  projectId: string,
  docId: string,
  techStackDetails: Project['techStackDetails'],
  selectedTechStack: string,
  aiConfig: AiConfig,
  onProgress?: DesignProgressCallback
): Promise<StoredArchitecture> {
  const startTime = Date.now()

  // Step 1: Load selected project
  onProgress?.('Preparing project...')

  // The generation endpoint enriches the prompt from the current persisted requirements.
  // Avoid a duplicate client fetch; this flow must issue one generation request.
  onProgress?.('Generating with AI...')

  // Call configured LLM API once.
  const newArchRecord = await backendApi.generateArchitecture(projectId, docId, selectedTechStack, aiConfig)
  onProgress?.('Saving version...')

  const versionSnapshot: ArchitectureVersionRecord = {
    id: `arch-ver-${newArchRecord.docId}-v${newArchRecord.version}`,
    docId: newArchRecord.docId,
    projectId,
    version: newArchRecord.version,
    timestamp: new Date().toISOString(),
    author: `AI Engine (${aiConfig.moduleModels.architecture || aiConfig.defaultModel})`,
    changeType: newArchRecord.version > 1 ? 'Regenerated' : 'AI_Generated',
    changeSummary: `Solution Architecture generated (v${newArchRecord.version}) for stack ${selectedTechStack}`,
    architectureSnapshot: newArchRecord,
  }

  await saveArchitectureVersion(versionSnapshot)

  const processingTimeMs = Date.now() - startTime

  // Requirement 10 Logging
  monitoring.log('INFO', 'AI', `Solution Architecture regenerated for project ${projectId}`, processingTimeMs, {
    projectId,
    docId: newArchRecord.docId,
    savedVersion: newArchRecord.version,
    nodesCount: newArchRecord.nodes.length,
    edgesCount: newArchRecord.edges.length,
    processingTimeMs,
  })

  await addAuditLog({
    projectId,
    docId: newArchRecord.docId,
    action: 'Architecture Regenerated',
    detail: `Regenerated Solution Architecture (Version v${newArchRecord.version}) for ${selectedTechStack} in ${processingTimeMs}ms`,
    user: 'AI Engine',
    status: 'Success'
  })

  onProgress?.('Completed.')
  return newArchRecord
}

/**
 * 10. Save Solution Architecture API
 */
export async function saveSolutionArchitectureAPI(
  projectId: string,
  docId: string,
  nodes: ArchNode[],
  edges: ArchEdge[],
  techStackDetails: Project['techStackDetails'],
  executive?: ExecutiveArchitectureData,
  user = 'Current User'
): Promise<StoredArchitecture> {
  const updatedArchRecord = await backendApi.saveArchitecture(docId, projectId, nodes, edges, techStackDetails, executive)

  const versionSnapshot: ArchitectureVersionRecord = {
    id: `arch-ver-${docId}-v${updatedArchRecord.version}`,
    docId,
    projectId,
    version: updatedArchRecord.version,
    timestamp: updatedArchRecord.updatedAt,
    author: user,
    changeType: 'Manual_Edit',
    changeSummary: `Manual edits saved to Solution Architecture (v${updatedArchRecord.version})`,
    architectureSnapshot: updatedArchRecord,
  }

  await saveArchitectureVersion(versionSnapshot)
  await addAuditLog({
    projectId,
    docId,
    action: 'Architecture Saved',
    detail: `Saved manual edits to Solution Architecture v${updatedArchRecord.version}`,
    user,
    status: 'Info'
  })

  return updatedArchRecord
}

/**
 * 13. Export Design Artifact API
 */
export async function exportDesignArtifactAPI(
  artifactType: 'Business Flow' | 'Solution Architecture',
  format: ExportFormat,
  containerId: string,
  filename: string,
  data?: any,
  user = 'Current User'
) {
  await exportArtifactElement(containerId, format, filename, data)
  await addAuditLog({
    projectId: data?.projectId || 'current-project',
    docId: data?.docId,
    action: 'Artifact Exported',
    detail: `Exported '${artifactType}' in ${format} format (${filename})`,
    user,
    status: 'Success'
  })
}

export {
  getRequirementVersions,
  getDocumentsByProject,
  getBusinessFlowByDocId,
  getBusinessFlowVersions,
  getArchitectureByDocId,
  getArchitectureVersions,
}
