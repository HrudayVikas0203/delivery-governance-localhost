import type { Requirement, Actor, BusinessModule, BusinessRule, Assumption, Constraint, ExternalSystem, Risk, FlowNode, FlowEdge, ArchNode, ArchEdge, Project, ExecutiveArchitectureData } from '../data/types'

export interface StoredDocument {
  id: string
  name: string
  type: 'BRD' | 'HLRD' | 'FRD' | 'RFP' | 'SRS'
  pages: number
  confidence: number
  size: string
  uploadedAt: string
  projectId: string
  hash: string
  rawContent: string
  fileData?: ArrayBuffer | string
  status: 'Pending' | 'Processing' | 'Completed' | 'Failed'
  errorDetails?: string
}

export interface ExtractedRequirementsRecord {
  id: string
  docId: string
  projectId: string
  overview: string
  businessObjectives: string[]
  projectScope: {
    inScope: string[]
    outOfScope: string[]
  }
  stakeholders: { id: string; name: string; role: string; department: string }[]
  actors: Actor[]
  modules: BusinessModule[]
  functional: Requirement[]
  nonFunctional: Requirement[]
  businessRules: BusinessRule[]
  assumptions: Assumption[]
  constraints: Constraint[]
  externalSystems: ExternalSystem[]
  risks: Risk[]
  dependencies: { id: string; source: string; target: string; description: string }[]
  version: number
  updatedAt: string
  generatorModel: string
}

export interface RequirementVersionRecord {
  id: string
  docId: string
  projectId: string
  version: number
  timestamp: string
  author: string
  changeType: 'AI_Extracted' | 'Manual_Edit' | 'Regenerated'
  changeSummary: string
  requirementsSnapshot: ExtractedRequirementsRecord
}

export interface StoredBusinessFlow {
  id: string
  docId: string
  projectId: string
  nodes: FlowNode[]
  edges: FlowEdge[]
  version: number
  updatedAt: string
}

export interface BusinessFlowVersionRecord {
  id: string
  docId: string
  projectId: string
  version: number
  timestamp: string
  author: string
  changeType: 'AI_Generated' | 'Manual_Edit' | 'Regenerated'
  changeSummary: string
  flowSnapshot: StoredBusinessFlow
}

export interface StoredArchitecture {
  id: string
  docId: string
  projectId: string
  nodes: ArchNode[]
  edges: ArchEdge[]
  executive?: ExecutiveArchitectureData
  techStackDetails?: Project['techStackDetails']
  version: number
  updatedAt: string
}

export interface ArchitectureVersionRecord {
  id: string
  docId: string
  projectId: string
  version: number
  timestamp: string
  author: string
  changeType: 'AI_Generated' | 'Stack_Changed' | 'Manual_Edit' | 'Regenerated'
  changeSummary: string
  architectureSnapshot: StoredArchitecture
}

export interface AuditLogRecord {
  id: string
  projectId: string
  docId?: string
  action: string
  detail: string
  user: string
  timestamp: string
  status: 'Success' | 'Warning' | 'Error' | 'Info'
}

export interface VectorEmbeddingRecord {
  id: string
  docId: string
  projectId: string
  chunkIndex: number
  text: string
  metadata: {
    docName?: string
    sectionTitle?: string
    contentType: 'DocumentText' | 'Requirement' | 'Module' | 'Architecture' | 'Database' | 'Report'
    code?: string
  }
  vector: number[]
  createdAt: string
}

export interface AppNotificationRecord {
  id: string
  projectId?: string
  docId?: string
  title: string
  message: string
  type: 'info' | 'success' | 'warning' | 'error'
  timestamp: string
  read: boolean
  link?: string
}

export interface PromptTemplateRecord {
  id: string
  category: 'requirementExtraction' | 'businessFlow' | 'architecture' | 'reports' | 'aiChat'
  name: string
  promptText: string
  version: number
  updatedAt: string
  author: string
}

export interface PromptVersionRecord {
  id: string
  templateId: string
  category: string
  version: number
  promptText: string
  timestamp: string
  author: string
  changeSummary: string
}

export interface CollaborationCommentRecord {
  id: string
  projectId: string
  targetArtifact: 'Requirements' | 'Business Flow' | 'Solution Architecture'
  targetId?: string
  author: string
  userRole: string
  text: string
  mentions?: string[]
  resolved: boolean
  timestamp: string
}

export interface IntegrationConfigRecord {
  id: string
  platform: 'Jira' | 'Confluence' | 'GitHub' | 'GitLab' | 'Slack' | 'Teams'
  enabled: boolean
  endpointUrl: string
  apiKey?: string
  projectKey?: string
  webhookUrl?: string
}

export interface BackupRecord {
  id: string
  timestamp: string
  description: string
  dataJson: string
  sizeStr: string
}

const DB_NAME = 'AISolutionArchitectDB'
const DB_VERSION = 4

let dbInstance: IDBDatabase | null = null

export async function getDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)

    request.onerror = () => reject(request.error)

    request.onsuccess = () => {
      dbInstance = request.result
      resolve(dbInstance)
    }

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result

      if (!db.objectStoreNames.contains('documents')) {
        const docStore = db.createObjectStore('documents', { keyPath: 'id' })
        docStore.createIndex('projectId', 'projectId', { unique: false })
        docStore.createIndex('hash', 'hash', { unique: false })
      }

      if (!db.objectStoreNames.contains('requirements')) {
        const reqStore = db.createObjectStore('requirements', { keyPath: 'id' })
        reqStore.createIndex('projectId', 'projectId', { unique: false })
        reqStore.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('requirement_versions')) {
        const verStore = db.createObjectStore('requirement_versions', { keyPath: 'id' })
        verStore.createIndex('projectId', 'projectId', { unique: false })
        verStore.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('business_flows')) {
        const store = db.createObjectStore('business_flows', { keyPath: 'id' })
        store.createIndex('projectId', 'projectId', { unique: false })
        store.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('flow_versions')) {
        const store = db.createObjectStore('flow_versions', { keyPath: 'id' })
        store.createIndex('projectId', 'projectId', { unique: false })
        store.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('architectures')) {
        const store = db.createObjectStore('architectures', { keyPath: 'id' })
        store.createIndex('projectId', 'projectId', { unique: false })
        store.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('architecture_versions')) {
        const store = db.createObjectStore('architecture_versions', { keyPath: 'id' })
        store.createIndex('projectId', 'projectId', { unique: false })
        store.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('audit_logs')) {
        const logStore = db.createObjectStore('audit_logs', { keyPath: 'id' })
        logStore.createIndex('projectId', 'projectId', { unique: false })
        logStore.createIndex('timestamp', 'timestamp', { unique: false })
      }

      if (!db.objectStoreNames.contains('vector_embeddings')) {
        const vecStore = db.createObjectStore('vector_embeddings', { keyPath: 'id' })
        vecStore.createIndex('projectId', 'projectId', { unique: false })
        vecStore.createIndex('docId', 'docId', { unique: false })
      }

      if (!db.objectStoreNames.contains('notifications')) {
        const notifStore = db.createObjectStore('notifications', { keyPath: 'id' })
        notifStore.createIndex('read', 'read', { unique: false })
      }

      if (!db.objectStoreNames.contains('prompt_templates')) {
        const store = db.createObjectStore('prompt_templates', { keyPath: 'id' })
        store.createIndex('category', 'category', { unique: false })
      }

      if (!db.objectStoreNames.contains('prompt_versions')) {
        const store = db.createObjectStore('prompt_versions', { keyPath: 'id' })
        store.createIndex('templateId', 'templateId', { unique: false })
      }

      if (!db.objectStoreNames.contains('collaboration_comments')) {
        const store = db.createObjectStore('collaboration_comments', { keyPath: 'id' })
        store.createIndex('projectId', 'projectId', { unique: false })
        store.createIndex('targetArtifact', 'targetArtifact', { unique: false })
      }

      if (!db.objectStoreNames.contains('integration_configs')) {
        const store = db.createObjectStore('integration_configs', { keyPath: 'id' })
        store.createIndex('platform', 'platform', { unique: true })
      }

      if (!db.objectStoreNames.contains('backups')) {
        db.createObjectStore('backups', { keyPath: 'id' })
      }
    }
  })
}

// Transaction Helpers
async function performTx<T>(
  storeName: string,
  mode: IDBTransactionMode,
  action: (store: IDBObjectStore) => IDBRequest
): Promise<T> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode)
    const store = tx.objectStore(storeName)
    const req = action(store)
    req.onsuccess = () => resolve(req.result as T)
    req.onerror = () => reject(req.error)
  })
}

// Document Operations
export async function saveDocumentRecord(doc: StoredDocument): Promise<void> {
  await performTx('documents', 'readwrite', store => store.put(doc))
}

export async function getDocumentRecord(id: string): Promise<StoredDocument | undefined> {
  return performTx<StoredDocument | undefined>('documents', 'readonly', store => store.get(id))
}

export async function getDocumentsByProject(projectId: string): Promise<StoredDocument[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('documents', 'readonly')
    const store = tx.objectStore('documents')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

export async function getAllDocumentRecords(): Promise<StoredDocument[]> {
  return performTx<StoredDocument[]>('documents', 'readonly', store => store.getAll())
}

// Requirement Operations
export async function saveRequirementsRecord(record: ExtractedRequirementsRecord): Promise<void> {
  await performTx('requirements', 'readwrite', store => store.put(record))
}

export async function getRequirementsByDocId(docId: string): Promise<ExtractedRequirementsRecord | undefined> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('requirements', 'readonly')
    const store = tx.objectStore('requirements')
    const index = store.index('docId')
    const req = index.get(docId)
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export async function getRequirementsByProjectId(projectId: string): Promise<ExtractedRequirementsRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('requirements', 'readonly')
    const store = tx.objectStore('requirements')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

// Version History Operations - Requirements
export async function saveRequirementVersion(versionRecord: RequirementVersionRecord): Promise<void> {
  await performTx('requirement_versions', 'readwrite', store => store.put(versionRecord))
}

export async function getRequirementVersions(docId: string): Promise<RequirementVersionRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('requirement_versions', 'readonly')
    const store = tx.objectStore('requirement_versions')
    const index = store.index('docId')
    const req = index.getAll(docId)
    req.onsuccess = () => {
      const versions = (req.result || []) as RequirementVersionRecord[]
      resolve(versions.sort((a, b) => b.version - a.version))
    }
    req.onerror = () => reject(req.error)
  })
}

// Business Flow Operations
export async function saveBusinessFlowRecord(record: StoredBusinessFlow): Promise<void> {
  await performTx('business_flows', 'readwrite', store => store.put(record))
}

export async function getBusinessFlowByDocId(docId: string): Promise<StoredBusinessFlow | undefined> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('business_flows', 'readonly')
    const store = tx.objectStore('business_flows')
    const index = store.index('docId')
    const req = index.get(docId)
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export async function getAllBusinessFlows(): Promise<StoredBusinessFlow[]> {
  return performTx<StoredBusinessFlow[]>('business_flows', 'readonly', store => store.getAll())
}

export async function saveBusinessFlowVersion(record: BusinessFlowVersionRecord): Promise<void> {
  await performTx('flow_versions', 'readwrite', store => store.put(record))
}

export async function getBusinessFlowVersions(docId: string): Promise<BusinessFlowVersionRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('flow_versions', 'readonly')
    const store = tx.objectStore('flow_versions')
    const index = store.index('docId')
    const req = index.getAll(docId)
    req.onsuccess = () => {
      const versions = (req.result || []) as BusinessFlowVersionRecord[]
      resolve(versions.sort((a, b) => b.version - a.version))
    }
    req.onerror = () => reject(req.error)
  })
}

// Solution Architecture Operations
export async function saveArchitectureRecord(record: StoredArchitecture): Promise<void> {
  await performTx('architectures', 'readwrite', store => store.put(record))
}

export async function getArchitectureByDocId(docId: string): Promise<StoredArchitecture | undefined> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('architectures', 'readonly')
    const store = tx.objectStore('architectures')
    const index = store.index('docId')
    const req = index.get(docId)
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export async function getAllArchitectures(): Promise<StoredArchitecture[]> {
  return performTx<StoredArchitecture[]>('architectures', 'readonly', store => store.getAll())
}

export async function saveArchitectureVersion(record: ArchitectureVersionRecord): Promise<void> {
  await performTx('architecture_versions', 'readwrite', store => store.put(record))
}

export async function getArchitectureVersions(docId: string): Promise<ArchitectureVersionRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('architecture_versions', 'readonly')
    const store = tx.objectStore('architecture_versions')
    const index = store.index('docId')
    const req = index.getAll(docId)
    req.onsuccess = () => {
      const versions = (req.result || []) as ArchitectureVersionRecord[]
      resolve(versions.sort((a, b) => b.version - a.version))
    }
    req.onerror = () => reject(req.error)
  })
}

export async function getBusinessFlowsByProjectId(projectId: string): Promise<StoredBusinessFlow[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('business_flows', 'readonly')
    const store = tx.objectStore('business_flows')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

export async function getArchitecturesByProjectId(projectId: string): Promise<StoredArchitecture[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('architectures', 'readonly')
    const store = tx.objectStore('architectures')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

// Audit Log Operations
export async function addAuditLog(log: Omit<AuditLogRecord, 'id' | 'timestamp'>): Promise<AuditLogRecord> {
  const newLog: AuditLogRecord = {
    ...log,
    id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    timestamp: new Date().toISOString()
  }
  await performTx('audit_logs', 'readwrite', store => store.put(newLog))
  return newLog
}

export async function getAuditLogsByProject(projectId: string): Promise<AuditLogRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('audit_logs', 'readonly')
    const store = tx.objectStore('audit_logs')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => {
      const logs = (req.result || []) as AuditLogRecord[]
      resolve(logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()))
    }
    req.onerror = () => reject(req.error)
  })
}

// Vector Embeddings Operations
export async function saveVectorEmbeddings(records: VectorEmbeddingRecord[]): Promise<void> {
  const db = await getDB()
  const tx = db.transaction('vector_embeddings', 'readwrite')
  const store = tx.objectStore('vector_embeddings')
  records.forEach(r => store.put(r))
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve()
    tx.onerror = () => reject(tx.error)
  })
}

export async function getVectorEmbeddingsByProject(projectId: string): Promise<VectorEmbeddingRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('vector_embeddings', 'readonly')
    const store = tx.objectStore('vector_embeddings')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => resolve(req.result || [])
    req.onerror = () => reject(req.error)
  })
}

// Notifications Operations
export async function addNotification(notif: Omit<AppNotificationRecord, 'id' | 'timestamp' | 'read'>): Promise<AppNotificationRecord> {
  const newNotif: AppNotificationRecord = {
    ...notif,
    id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString(),
    read: false,
  }
  await performTx('notifications', 'readwrite', store => store.put(newNotif))
  return newNotif
}

export async function getAllNotifications(): Promise<AppNotificationRecord[]> {
  const items = await performTx<AppNotificationRecord[]>('notifications', 'readonly', store => store.getAll())
  return (items || []).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
}

export async function markNotificationAsRead(id: string): Promise<void> {
  const db = await getDB()
  const tx = db.transaction('notifications', 'readwrite')
  const store = tx.objectStore('notifications')
  const req = store.get(id)
  req.onsuccess = () => {
    const item = req.result
    if (item) {
      item.read = true
      store.put(item)
    }
  }
}

// Prompt Templates & Versions
export async function savePromptTemplate(record: PromptTemplateRecord): Promise<void> {
  await performTx('prompt_templates', 'readwrite', store => store.put(record))
}

export async function getAllPromptTemplates(): Promise<PromptTemplateRecord[]> {
  const items = await performTx<PromptTemplateRecord[]>('prompt_templates', 'readonly', store => store.getAll())
  return items || []
}

export async function savePromptVersion(record: PromptVersionRecord): Promise<void> {
  await performTx('prompt_versions', 'readwrite', store => store.put(record))
}

export async function getPromptVersions(templateId: string): Promise<PromptVersionRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('prompt_versions', 'readonly')
    const store = tx.objectStore('prompt_versions')
    const index = store.index('templateId')
    const req = index.getAll(templateId)
    req.onsuccess = () => {
      const versions = (req.result || []) as PromptVersionRecord[]
      resolve(versions.sort((a, b) => b.version - a.version))
    }
    req.onerror = () => reject(req.error)
  })
}

// Collaboration Comments
export async function addCollaborationComment(comment: Omit<CollaborationCommentRecord, 'id' | 'timestamp' | 'resolved'>): Promise<CollaborationCommentRecord> {
  const newComment: CollaborationCommentRecord = {
    ...comment,
    id: `cmt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString(),
    resolved: false,
  }
  await performTx('collaboration_comments', 'readwrite', store => store.put(newComment))
  return newComment
}

export async function getCollaborationComments(projectId: string, artifact: string): Promise<CollaborationCommentRecord[]> {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const tx = db.transaction('collaboration_comments', 'readonly')
    const store = tx.objectStore('collaboration_comments')
    const index = store.index('projectId')
    const req = index.getAll(projectId)
    req.onsuccess = () => {
      const comments = ((req.result || []) as CollaborationCommentRecord[])
        .filter(c => c.targetArtifact === artifact)
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      resolve(comments)
    }
    req.onerror = () => reject(req.error)
  })
}

export async function resolveCollaborationComment(id: string): Promise<void> {
  const db = await getDB()
  const tx = db.transaction('collaboration_comments', 'readwrite')
  const store = tx.objectStore('collaboration_comments')
  const req = store.get(id)
  req.onsuccess = () => {
    const item = req.result
    if (item) {
      item.resolved = true
      store.put(item)
    }
  }
}

// Integrations
export async function saveIntegrationConfig(record: IntegrationConfigRecord): Promise<void> {
  await performTx('integration_configs', 'readwrite', store => store.put(record))
}

export async function getAllIntegrationConfigs(): Promise<IntegrationConfigRecord[]> {
  const items = await performTx<IntegrationConfigRecord[]>('integration_configs', 'readonly', store => store.getAll())
  return items || []
}

// Backups
export async function saveBackup(record: BackupRecord): Promise<void> {
  await performTx('backups', 'readwrite', store => store.put(record))
}

export async function getAllBackups(): Promise<BackupRecord[]> {
  const items = await performTx<BackupRecord[]>('backups', 'readonly', store => store.getAll())
  return (items || []).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
}
