export interface DiffItem {
  id: string
  label: string
  type: 'added' | 'removed' | 'modified' | 'unchanged'
  details?: string
}

export interface ArtifactDiffResult {
  artifact: string
  versionA: number
  versionB: number
  addedCount: number
  removedCount: number
  modifiedCount: number
  diffs: DiffItem[]
}

/**
 * Computes structural diff between two arrays of items by key
 */
export function computeItemDiffs<T extends { id?: string; name?: string; code?: string }>(
  itemsA: T[],
  itemsB: T[],
  getItemLabel: (item: T) => string
): DiffItem[] {
  const diffs: DiffItem[] = []
  const mapA = new Map<string, T>()
  const mapB = new Map<string, T>()

  itemsA.forEach(a => mapA.set(a.id || a.code || a.name || JSON.stringify(a), a))
  itemsB.forEach(b => mapB.set(b.id || b.code || b.name || JSON.stringify(b), b))

  // Added in B
  mapB.forEach((valB, key) => {
    if (!mapA.has(key)) {
      diffs.push({
        id: key,
        label: getItemLabel(valB),
        type: 'added',
        details: 'Added in newer version'
      })
    } else {
      const valA = mapA.get(key)!
      const jsonA = JSON.stringify(valA)
      const jsonB = JSON.stringify(valB)
      if (jsonA !== jsonB) {
        diffs.push({
          id: key,
          label: getItemLabel(valB),
          type: 'modified',
          details: 'Modified in newer version'
        })
      } else {
        diffs.push({
          id: key,
          label: getItemLabel(valB),
          type: 'unchanged'
        })
      }
    }
  })

  // Removed in B
  mapA.forEach((valA, key) => {
    if (!mapB.has(key)) {
      diffs.push({
        id: key,
        label: getItemLabel(valA),
        type: 'removed',
        details: 'Removed in newer version'
      })
    }
  })

  return diffs
}

/**
 * Calculates Version Comparison summary
 */
export function summarizeArtifactDiff(
  artifact: string,
  versionA: number,
  versionB: number,
  diffs: DiffItem[]
): ArtifactDiffResult {
  const addedCount = diffs.filter(d => d.type === 'added').length
  const removedCount = diffs.filter(d => d.type === 'removed').length
  const modifiedCount = diffs.filter(d => d.type === 'modified').length

  return {
    artifact,
    versionA,
    versionB,
    addedCount,
    removedCount,
    modifiedCount,
    diffs,
  }
}
