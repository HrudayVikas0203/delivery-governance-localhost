export interface LogEntry {
  id: string
  timestamp: string
  level: 'INFO' | 'WARN' | 'ERROR'
  source: 'API' | 'AI' | 'SYSTEM' | 'SECURITY'
  message: string
  latencyMs?: number
  details?: any
}

type TelemetryPayload = {
  location: string
  message: string
  data?: Record<string, unknown>
  hypothesisId?: string
  runId?: string
}

const configuredTelemetryUrl = import.meta.env.VITE_TELEMETRY_URL?.trim()
const normalizedTelemetryUrl = configuredTelemetryUrl
  ? configuredTelemetryUrl.replace(/\/$/, '')
  : ''

const isLocalhostTelemetry = /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?/i.test(normalizedTelemetryUrl)
const telemetryEndpoint = normalizedTelemetryUrl
  ? `${normalizedTelemetryUrl}/ingest/${import.meta.env.VITE_TELEMETRY_INGEST_KEY?.trim() || '6a4fa49f-fc54-4853-bf24-ae8cb1e75fcb'}`
  : ''

class MonitoringService {
  private logs: LogEntry[] = []
  private startTime = Date.now()
  private telemetryDisabled = !telemetryEndpoint || (import.meta.env.PROD && isLocalhostTelemetry)
  private telemetryFailureLogged = false

  log(level: LogEntry['level'], source: LogEntry['source'], message: string, latencyMs?: number, details?: any) {
    const entry: LogEntry = {
      id: `m-log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      level,
      source,
      message,
      latencyMs,
      details,
    }
    this.logs.unshift(entry)
    if (this.logs.length > 500) this.logs.pop()

    if (level === 'ERROR') {
      console.error(`[${source}] ${message}`, details)
    } else {
      console.log(`[${source}] ${message}`)
    }
  }

  getLogs(filter?: { level?: string; source?: string }): LogEntry[] {
    return this.logs.filter(l => {
      if (filter?.level && l.level !== filter.level) return false
      if (filter?.source && l.source !== filter.source) return false
      return true
    })
  }

  getHealthStatus() {
    const uptimeSeconds = Math.round((Date.now() - this.startTime) / 1000)
    const errorCount = this.logs.filter(l => l.level === 'ERROR').length
    const avgLatency = Math.round(
      this.logs.filter(l => l.latencyMs).reduce((sum, l) => sum + (l.latencyMs || 0), 0) /
        (this.logs.filter(l => l.latencyMs).length || 1)
    )

    return {
      status: errorCount > 10 ? 'DEGRADED' : 'HEALTHY',
      uptimeSeconds,
      avgLatencyMs: avgLatency || 45,
      totalLogEntries: this.logs.length,
      errorCount,
      timestamp: new Date().toISOString(),
    }
  }

  async sendTelemetry(payload: TelemetryPayload): Promise<void> {
    if (this.telemetryDisabled) {
      return
    }

    try {
      const response = await fetch(telemetryEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(import.meta.env.VITE_TELEMETRY_SESSION_ID?.trim()
            ? { 'X-Debug-Session-Id': import.meta.env.VITE_TELEMETRY_SESSION_ID.trim() }
            : {}),
        },
        body: JSON.stringify({
          sessionId: import.meta.env.VITE_TELEMETRY_SESSION_ID?.trim() || 'frontend',
          location: payload.location,
          message: payload.message,
          data: payload.data || {},
          timestamp: Date.now(),
          hypothesisId: payload.hypothesisId || '',
          runId: payload.runId || 'runtime',
        }),
      })

      if (!response.ok) {
        throw new Error(`Telemetry request failed with status ${response.status}`)
      }
    } catch (error) {
      this.telemetryDisabled = true
      if (!this.telemetryFailureLogged && import.meta.env.DEV) {
        this.telemetryFailureLogged = true
        console.info(
          '[SYSTEM] Optional telemetry endpoint unavailable. Telemetry disabled for this session.',
          error instanceof Error ? error.message : error
        )
      }
    }
  }
}

export const monitoring = new MonitoringService()
