import {
  addCollaborationComment,
  getCollaborationComments,
  resolveCollaborationComment,
  addAuditLog,
  type CollaborationCommentRecord,
} from './db'

export async function postComment(
  projectId: string,
  targetArtifact: 'Requirements' | 'Business Flow' | 'Solution Architecture',
  text: string,
  author: string,
  userRole: string,
  targetId?: string
): Promise<CollaborationCommentRecord> {
  const mentions: string[] = []
  const mentionMatches = text.match(/@(\w+)/g)
  if (mentionMatches) {
    mentions.push(...mentionMatches.map(m => m.substring(1)))
  }

  const comment = await addCollaborationComment({
    projectId,
    targetArtifact,
    targetId,
    author,
    userRole,
    text,
    mentions,
  })

  await addAuditLog({
    projectId,
    action: 'Comment Added',
    detail: `[${targetArtifact}] ${author} (${userRole}) commented: "${text.slice(0, 50)}..."`,
    user: author,
    status: 'Info'
  })

  return comment
}

export async function submitGovernanceReview(
  projectId: string,
  artifact: 'Requirements' | 'Business Flow' | 'Solution Architecture',
  decision: 'Approved' | 'Rejected' | 'Marked as Reviewed',
  user: string,
  detail = ''
): Promise<void> {
  await addAuditLog({
    projectId,
    action: `Governance ${decision}`,
    detail: `${artifact} was ${decision.toLowerCase()} by ${user}. ${detail}`,
    user,
    status: decision === 'Approved' ? 'Success' : decision === 'Rejected' ? 'Warning' : 'Info'
  })
}

export { getCollaborationComments, resolveCollaborationComment }
