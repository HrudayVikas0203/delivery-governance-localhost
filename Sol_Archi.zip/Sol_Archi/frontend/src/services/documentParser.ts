import * as pdfjsLib from 'pdfjs-dist'
import mammoth from 'mammoth'

// Set worker source for pdfjs-dist
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`

export interface ParsedDocumentResult {
  rawText: string
  pageCount: number
  characterCount: number
  detectedType: 'BRD' | 'HLRD' | 'FRD' | 'RFP' | 'SRS'
  hash: string
  sections: { title: string; content: string }[]
}

/**
 * Calculates SHA-256 hash of an ArrayBuffer file
 */
export async function calculateFileHash(buffer: ArrayBuffer): Promise<string> {
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
}

/**
 * Detects document type (BRD, FRD, SRS, HLRD, RFP) from filename and raw content
 */
export function detectDocumentType(fileName: string, content: string): 'BRD' | 'HLRD' | 'FRD' | 'RFP' | 'SRS' {
  const lowerName = fileName.toLowerCase()
  const lowerContent = content.slice(0, 3000).toLowerCase()

  if (lowerName.includes('brd') || lowerContent.includes('business requirement document')) return 'BRD'
  if (lowerName.includes('hlrd') || lowerContent.includes('high level requirement')) return 'HLRD'
  if (lowerName.includes('frd') || lowerContent.includes('functional requirement document')) return 'FRD'
  if (lowerName.includes('rfp') || lowerContent.includes('request for proposal')) return 'RFP'
  if (lowerName.includes('srs') || lowerContent.includes('software requirement specification')) return 'SRS'

  return 'BRD'
}

/**
 * Extract sections from structured raw text
 */
export function extractTextSections(rawText: string): { title: string; content: string }[] {
  const lines = rawText.split('\n')
  const sections: { title: string; content: string }[] = []
  let currentTitle = 'Overview'
  let currentBuffer: string[] = []

  for (const line of lines) {
    const trimmed = line.trim()
    // Identify heading lines (starts with 1., SECTION, #, or short uppercase string)
    const isHeading = /^(?:[0-9]+\.|\#{1,3}|SECTION\s+[0-9]+|[A-Z\s]{4,40}:?$)/.test(trimmed) && trimmed.length < 60

    if (isHeading && currentBuffer.length > 0) {
      sections.push({ title: currentTitle, content: currentBuffer.join('\n').trim() })
      currentTitle = trimmed.replace(/^[\#\d\.\s]+/, '').trim() || 'Section'
      currentBuffer = []
    } else {
      currentBuffer.push(line)
    }
  }

  if (currentBuffer.length > 0) {
    sections.push({ title: currentTitle, content: currentBuffer.join('\n').trim() })
  }

  return sections.length > 0 ? sections : [{ title: 'Main Content', content: rawText }]
}

/**
 * Parses PDF file ArrayBuffer into structured text
 */
export async function parsePDFDocument(buffer: ArrayBuffer): Promise<{ text: string; pageCount: number }> {
  try {
    const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(buffer) })
    const pdf = await loadingTask.promise
    const pageCount = pdf.numPages
    let fullText = ''

    for (let i = 1; i <= pageCount; i++) {
      const page = await pdf.getPage(i)
      const textContent = await page.getTextContent()
      const pageText = textContent.items
        .map((item: any) => ('str' in item ? item.str : ''))
        .join(' ')
      fullText += `\n--- Page ${i} ---\n` + pageText
    }

    return { text: fullText.trim(), pageCount }
  } catch (error) {
    throw new Error(`PDF Parsing Failed: ${error instanceof Error ? error.message : 'Invalid or corrupt PDF file'}`)
  }
}

/**
 * Parses DOCX file ArrayBuffer into structured text
 */
export async function parseDOCXDocument(buffer: ArrayBuffer): Promise<{ text: string; pageCount: number }> {
  try {
    const result = await mammoth.extractRawText({ arrayBuffer: buffer })
    const text = result.value.trim()
    // Estimate page count (~3000 chars per page)
    const estimatedPages = Math.max(1, Math.ceil(text.length / 3000))
    return { text, pageCount: estimatedPages }
  } catch (error) {
    throw new Error(`DOCX Parsing Failed: ${error instanceof Error ? error.message : 'Invalid or corrupt DOCX file'}`)
  }
}

/**
 * Master parser function for PDF or DOCX file
 */
export async function parseDocumentFile(file: File): Promise<ParsedDocumentResult> {
  const extension = file.name.split('.').pop()?.toLowerCase()
  if (extension !== 'pdf' && extension !== 'docx') {
    throw new Error(`Unsupported document format: .${extension}. Only PDF and DOCX files are supported.`)
  }

  const buffer = await file.arrayBuffer()
  if (!buffer || buffer.byteLength === 0) {
    throw new Error(`Empty Document Error: The file '${file.name}' contains 0 bytes and cannot be processed.`)
  }

  const hash = await calculateFileHash(buffer)

  let extracted: { text: string; pageCount: number }
  if (extension === 'pdf') {
    extracted = await parsePDFDocument(buffer)
  } else {
    extracted = await parseDOCXDocument(buffer)
  }

  if (!extracted.text || extracted.text.length < 20) {
    throw new Error(`Empty Text Error: Unable to extract text from '${file.name}'. The document may be empty or password protected.`)
  }

  const detectedType = detectDocumentType(file.name, extracted.text)
  const sections = extractTextSections(extracted.text)

  return {
    rawText: extracted.text,
    pageCount: extracted.pageCount,
    characterCount: extracted.text.length,
    detectedType,
    hash,
    sections,
  }
}
