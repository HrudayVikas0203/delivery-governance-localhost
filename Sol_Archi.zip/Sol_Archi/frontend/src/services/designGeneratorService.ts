import type { AiConfig } from '../data/aiConfig'
import type { ExtractedRequirementsRecord } from './db'
import type { FlowNode, FlowEdge, ArchNode, ArchEdge, DBEntity, Project } from '../data/types'
import { callConfiguredLLM } from './llmClient'

export interface FlowGenerationResponse {
  nodes: FlowNode[]
  edges: FlowEdge[]
}

export interface ArchitectureGenerationResponse {
  nodes: ArchNode[]
  edges: ArchEdge[]
}

export interface DatabaseDesignGenerationResponse {
  entities: DBEntity[]
}

/**
 * Universal LLM JSON Dispatcher using callConfiguredLLM
 */
async function callLLMForJSON<T>(
  prompt: string,
  systemPrompt: string,
  model: string,
  aiConfig: AiConfig
): Promise<T> {
  const content = await callConfiguredLLM(
    {
      prompt,
      systemPrompt,
      model,
      responseFormat: 'JSON Object',
    },
    aiConfig
  )

  let cleanJson = content.trim()
  if (cleanJson.startsWith('```')) {
    cleanJson = cleanJson.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim()
  }

  try {
    return JSON.parse(cleanJson) as T
  } catch (err: any) {
    throw new Error(`Failed to parse AI response JSON: ${err.message}`)
  }
}

/**
 * AI Business Flow Generator
 * Generates fresh business process flow from extracted requirements
 */
export async function generateBusinessFlowWithAI(
  reqs: ExtractedRequirementsRecord,
  aiConfig: AiConfig
): Promise<FlowGenerationResponse> {
  const systemPrompt = `You are an expert Enterprise Solution Architect and Business Process Modeling Specialist.
Generate a valid React Flow JSON graph representing an end-to-end Business Process Flow based on the provided project requirements.

Required JSON Structure:
{
  "nodes": [
    {
      "id": "node-id",
      "type": "flowNode",
      "position": {"x": 250, "y": 0},
      "data": {"label": "Node Label", "description": "Details..."},
      "style": {"background": "#10B981"}
    }
  ],
  "edges": [
    {
      "id": "edge-id",
      "source": "source-node-id",
      "target": "target-node-id",
      "label": "Action / Condition Label",
      "animated": true
    }
  ]
}

Rules:
1. MUST include a Start Node (green style "#10B981", id "n-start").
2. MUST include an End Node (red style "#EF4444", id "n-end").
3. Include Process Nodes (blue style "#3B82F6") representing core business functions.
4. Include Decision Nodes (purple style "#8B5CF6") representing validation checks or branching logic.
5. Include Parallel/User-System Interaction steps (orange style "#F59E0B").
6. Connect nodes logically using edges with descriptive labels.
7. Position nodes sequentially with increasing Y coordinates (0, 120, 240, 360, 480...) and X offsets for decision branches.`

  const prompt = `Generate a Business Process Flow for Project Requirements:

Overview: ${reqs.overview || 'Enterprise Business Solution'}

Business Modules:
${(reqs.modules || []).map(m => `- ${m.name}: ${m.description}`).join('\n')}

Functional Requirements:
${(reqs.functional || []).map(f => `- ${f.code} [${f.module}]: ${f.title} - ${f.description}`).join('\n')}

Non-Functional Requirements:
${(reqs.nonFunctional || []).map(n => `- ${n.code}: ${n.title} (${n.category})`).join('\n')}

Actors & Stakeholders:
${(reqs.actors || []).map(a => `- ${a.name} (${a.type}): ${a.description}`).join('\n')}

Business Rules:
${(reqs.businessRules || []).map(r => `- ${r.rule} [Module: ${r.module}]`).join('\n')}

Assumptions & Constraints:
Assumptions: ${(reqs.assumptions || []).map(a => a.assumption).join('; ')}
Constraints: ${(reqs.constraints || []).map(c => c.constraint).join('; ')}

Return valid React Flow JSON with "nodes" and "edges" reflecting all the above steps.`

  return callLLMForJSON<FlowGenerationResponse>(
    prompt,
    systemPrompt,
    aiConfig.moduleModels.businessFlow || aiConfig.defaultModel,
    aiConfig
  )
}

/**
 * AI Solution Architecture Generator
 * Generates solution architecture mapped to current requirements and technology stack
 */
export async function generateArchitectureWithAI(
  reqs: ExtractedRequirementsRecord,
  techStackDetails: Project['techStackDetails'] | undefined,
  selectedTechStack: string,
  aiConfig: AiConfig
): Promise<ArchitectureGenerationResponse> {
  const systemPrompt = `You are a Principal Enterprise Cloud Solution Architect.
Generate a valid React Flow JSON diagram representing a multi-layered Solution Architecture based on the system requirements and technology stack.

Required JSON Structure:
{
  "nodes": [
    {
      "id": "arch-1",
      "type": "archNode",
      "position": {"x": 250, "y": 50},
      "data": {
        "label": "Web Client Portal",
        "componentType": "Frontend",
        "technology": "React 18",
        "cloudService": "Azure App Service",
        "layer": "Presentation Layer",
        "description": "User UI portal for request submission",
        "icon": "Globe"
      }
    }
  ],
  "edges": [
    {
      "id": "e-1",
      "source": "arch-1",
      "target": "arch-2",
      "label": "HTTPS / REST",
      "animated": true
    }
  ]
}

Rules:
1. MUST generate components covering all required layers:
   - Frontend / Web App (Presentation Layer, icon "Globe")
   - API Gateway & Integration (API Layer, icon "Server")
   - Authentication / Identity Provider (Security Layer, icon "Shield")
   - Core Backend Microservices (Business Logic Layer, icon "Cpu")
   - Database / Data Storage (Data Layer, icon "Database")
   - AI / RAG Engine (AI Services Layer, icon "Sparkles")
   - Object Storage / Blob Storage (Storage Layer, icon "HardDrive")
   - External Systems (Integration Layer, icon "Globe")
2. Assign logical positions (x: 100 to 900, y: 50 to 500) arranged by layer.
3. Connect components with labeled directional edges specifying protocol/transport.`

  const prompt = `Generate Solution Architecture Diagram for:

Selected Tech Stack: ${selectedTechStack}
Frontend Framework: ${techStackDetails?.frontend || 'React'}
Backend Framework: ${techStackDetails?.backend || '.NET 8 API'}
Database Engine: ${techStackDetails?.database || 'SQL Server / PostgreSQL'}
Authentication: ${techStackDetails?.authentication || 'Azure AD OAuth2 / SAML'}
Cloud Platform: ${techStackDetails?.cloudPlatform || 'Microsoft Azure'}
Storage: ${techStackDetails?.storage || 'Azure Blob Storage'}
Messaging: ${techStackDetails?.messaging || 'RabbitMQ / Azure Service Bus'}
AI Services: ${techStackDetails?.aiServices || 'Azure OpenAI / Vector RAG'}
Monitoring: ${techStackDetails?.monitoring || 'Application Insights'}

Business Requirements Summary:
${reqs.overview}

Core Business Modules:
${(reqs.modules || []).map(m => `- ${m.name}: ${m.description}`).join('\n')}

Functional Requirements Count: ${(reqs.functional || []).length} items
External Systems: ${(reqs.externalSystems || []).map(e => e.name).join(', ') || 'Azure AD, Email Gateway'}

Return valid React Flow JSON with "nodes" and "edges".`

  return callLLMForJSON<ArchitectureGenerationResponse>(
    prompt,
    systemPrompt,
    aiConfig.moduleModels.architecture || aiConfig.defaultModel,
    aiConfig
  )
}

/**
 * AI Database Design Generator
 * Generates logical ER database model from extracted requirements
 */
export async function generateDatabaseDesignWithAI(
  reqs: ExtractedRequirementsRecord,
  databaseTech: string,
  aiConfig: AiConfig
): Promise<DatabaseDesignGenerationResponse> {
  const systemPrompt = `You are a Senior Lead Database Architect.
Generate a logical ER Database model in JSON format for the specified database technology based on business requirements.

Required JSON Structure:
{
  "entities": [
    {
      "id": "ent-1",
      "name": "Users",
      "description": "Core user identities and roles table",
      "fields": [
        {"name": "id", "type": "UUID", "pk": true, "description": "Primary Key"},
        {"name": "email", "type": "VARCHAR(255)", "nullable": false, "description": "User email address"},
        {"name": "created_at", "type": "TIMESTAMP", "description": "Record creation time"}
      ]
    }
  ]
}

Rules:
1. Identify entities corresponding to all core business modules and functional entities.
2. Define field data types appropriate for target database (${databaseTech}).
3. Mark primary keys with "pk": true.
4. Mark foreign keys with "fk": "ParentTable(id)".
5. Include comprehensive field descriptions.`

  const prompt = `Generate Logical ER Database Entities for Target Database: ${databaseTech}

System Overview:
${reqs.overview}

Business Modules:
${(reqs.modules || []).map(m => `- ${m.name}: ${m.description}`).join('\n')}

Key Functional Requirements:
${(reqs.functional || []).slice(0, 10).map(f => `- ${f.code}: ${f.title}`).join('\n')}

Business Rules & Constraints:
${(reqs.businessRules || []).map(b => `- ${b.rule}`).join('\n')}

Return valid JSON with "entities" list containing entities, attributes, primary keys, foreign keys, and descriptions.`

  return callLLMForJSON<DatabaseDesignGenerationResponse>(
    prompt,
    systemPrompt,
    aiConfig.moduleModels.database || aiConfig.defaultModel,
    aiConfig
  )
}
