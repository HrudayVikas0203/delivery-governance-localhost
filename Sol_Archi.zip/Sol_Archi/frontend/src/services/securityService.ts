import type { UserRole } from '../context/AuthContext'

export interface FileValidationResult {
  valid: boolean
  error?: string
}

const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024 // 25 MB
const ALLOWED_EXTENSIONS = ['PDF', 'DOCX', 'TXT', 'MD', 'JSON']

/**
 * Validates file upload for security (size, extension, MIME type, magic bytes)
 */
export async function validateFileUpload(file: File): Promise<FileValidationResult> {
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return { valid: false, error: `File size exceeds max limit of 25 MB (Actual: ${(file.size / 1024 / 1024).toFixed(1)} MB)` }
  }

  const ext = file.name.split('.').pop()?.toUpperCase() || ''
  if (!ALLOWED_EXTENSIONS.includes(ext)) {
    return { valid: false, error: `Invalid file format '.${ext}'. Supported formats: PDF, DOCX, TXT, MD, JSON` }
  }

  // Validate Magic Bytes for PDF and DOCX (ZIP container)
  try {
    const buffer = await file.slice(0, 4).arrayBuffer()
    const headerBytes = Array.from(new Uint8Array(buffer)).map(b => b.toString(16).padStart(2, '0')).join('')

    if (ext === 'PDF' && !headerBytes.startsWith('25504446')) { // %PDF
      return { valid: false, error: 'File header mismatch: corrupt or invalid PDF file.' }
    }

    if (ext === 'DOCX' && !headerBytes.startsWith('504b0304')) { // PK.. (ZIP container for docx)
      return { valid: false, error: 'File header mismatch: corrupt or invalid DOCX file.' }
    }
  } catch (e) {
    console.warn('Magic byte validation skipped:', e)
  }

  return { valid: true }
}

/**
 * Simple JWT Token Validation & Expiry Check
 */
export function validateJWT(token?: string): { valid: boolean; user?: any } {
  if (!token) return { valid: false }
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return { valid: false }
    const payload = JSON.parse(atob(parts[1]))
    if (payload.exp && Date.now() >= payload.exp * 1000) {
      return { valid: false }
    }
    return { valid: true, user: payload }
  } catch {
    return { valid: false }
  }
}

/**
 * Role-Based Access Control (RBAC) Permissions Matrix
 */
export const ROLE_PERMISSIONS: Record<UserRole, {
  canUploadDocs: boolean
  canEditRequirements: boolean
  canEditArchitecture: boolean
  canEditDatabase: boolean
  canGenerateReports: boolean
  canManageUsers: boolean
  canConfigureSystem: boolean
}> = {
  Admin: {
    canUploadDocs: true,
    canEditRequirements: true,
    canEditArchitecture: true,
    canEditDatabase: true,
    canGenerateReports: true,
    canManageUsers: true,
    canConfigureSystem: true,
  },
  'Enterprise Architect': {
    canUploadDocs: true,
    canEditRequirements: true,
    canEditArchitecture: true,
    canEditDatabase: true,
    canGenerateReports: true,
    canManageUsers: true,
    canConfigureSystem: true,
  },
  'Solution Architect': {
    canUploadDocs: true,
    canEditRequirements: true,
    canEditArchitecture: true,
    canEditDatabase: true,
    canGenerateReports: true,
    canManageUsers: false,
    canConfigureSystem: false,
  },
  'Business Analyst': {
    canUploadDocs: true,
    canEditRequirements: true,
    canEditArchitecture: false,
    canEditDatabase: false,
    canGenerateReports: true,
    canManageUsers: false,
    canConfigureSystem: false,
  },
  'Delivery Manager': {
    canUploadDocs: true,
    canEditRequirements: false,
    canEditArchitecture: false,
    canEditDatabase: false,
    canGenerateReports: true,
    canManageUsers: false,
    canConfigureSystem: false,
  },
}

/**
 * Client Rate Limiter
 */
const rateLimitMap = new Map<string, { count: number; lastReset: number }>()

export function checkRateLimit(key: string, maxRequests = 20, windowMs = 60000): boolean {
  const now = Date.now()
  const record = rateLimitMap.get(key) || { count: 0, lastReset: now }

  if (now - record.lastReset > windowMs) {
    record.count = 1
    record.lastReset = now
    rateLimitMap.set(key, record)
    return true
  }

  if (record.count >= maxRequests) {
    return false
  }

  record.count += 1
  rateLimitMap.set(key, record)
  return true
}

/**
 * Sanitize User Input against XSS Injection
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
}
