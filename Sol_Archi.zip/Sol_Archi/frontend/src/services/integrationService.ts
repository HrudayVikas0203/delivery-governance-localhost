import {
  saveIntegrationConfig,
  getAllIntegrationConfigs,
  addAuditLog,
  type IntegrationConfigRecord,
} from './db'

export const DEFAULT_INTEGRATIONS: IntegrationConfigRecord[] = [
  { id: 'int-jira', platform: 'Jira', enabled: true, endpointUrl: 'https://acme.atlassian.net', projectKey: 'EPWMS', apiKey: '••••••••' },
  { id: 'int-confluence', platform: 'Confluence', enabled: true, endpointUrl: 'https://acme.atlassian.net/wiki', projectKey: 'ARCH', apiKey: '••••••••' },
  { id: 'int-github', platform: 'GitHub', enabled: true, endpointUrl: 'https://api.github.com/repos/acme/epwms', apiKey: '••••••••' },
  { id: 'int-gitlab', platform: 'GitLab', enabled: false, endpointUrl: 'https://gitlab.com/api/v4/projects/101', apiKey: '' },
  { id: 'int-slack', platform: 'Slack', enabled: true, endpointUrl: 'https://hooks.slack.com/services/T00/B00/X00', webhookUrl: 'https://hooks.slack.com/services/T00/B00/X00' },
  { id: 'int-teams', platform: 'Teams', enabled: true, endpointUrl: 'https://outlook.office.com/webhook/xxx', webhookUrl: 'https://outlook.office.com/webhook/xxx' },
]

export async function initDefaultIntegrations(): Promise<void> {
  const existing = await getAllIntegrationConfigs()
  if (existing.length === 0) {
    for (const item of DEFAULT_INTEGRATIONS) {
      await saveIntegrationConfig(item)
    }
  }
}

export interface ExportIntegrationResult {
  success: boolean
  platform: string
  referenceUrl: string
  message: string
}

/**
 * Exports project artifact payload to Jira, Confluence, GitHub, GitLab, Slack, or Teams
 */
export async function exportToExternalPlatform(
  platform: 'Jira' | 'Confluence' | 'GitHub' | 'GitLab' | 'Slack' | 'Teams',
  artifactType: string,
  payloadData: any,
  user = 'Current User'
): Promise<ExportIntegrationResult> {
  const configs = await getAllIntegrationConfigs()
  const cfg = configs.find(c => c.platform === platform) || DEFAULT_INTEGRATIONS.find(c => c.platform === platform)

  if (!cfg || !cfg.enabled) {
    throw new Error(`Integration for '${platform}' is not enabled in settings.`)
  }

  await new Promise(r => setTimeout(r, 600)) // Simulate network request

  let refUrl = cfg.endpointUrl
  let msg = `Successfully exported ${artifactType} to ${platform}.`

  if (platform === 'Jira') {
    refUrl = `${cfg.endpointUrl}/browse/${cfg.projectKey || 'PROJ'}-101`
    msg = `Created 12 user stories in Jira project [${cfg.projectKey || 'PROJ'}].`
  } else if (platform === 'Confluence') {
    refUrl = `${cfg.endpointUrl}/display/${cfg.projectKey || 'ARCH'}/Solution+Architecture`
    msg = `Published Solution Architecture page to Confluence space [${cfg.projectKey || 'ARCH'}].`
  } else if (platform === 'GitHub') {
    refUrl = `${cfg.endpointUrl}/pull/42`
    msg = `Pushed database DDL migration script as PR #42 to GitHub.`
  } else if (platform === 'Slack' || platform === 'Teams') {
    msg = `Broadcasted ${artifactType} update notification card to ${platform} channel.`
  }

  await addAuditLog({
    projectId: payloadData?.projectId || 'current-project',
    action: `Exported to ${platform}`,
    detail: msg,
    user,
    status: 'Success'
  })

  return {
    success: true,
    platform,
    referenceUrl: refUrl,
    message: msg
  }
}

export { getAllIntegrationConfigs }

