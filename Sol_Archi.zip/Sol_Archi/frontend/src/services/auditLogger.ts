import { addAuditLog, getAuditLogsByProject, type AuditLogRecord } from './db'

export async function logDocumentUpload(projectId: string, docId: string, fileName: string, user = 'Current User') {
  return addAuditLog({
    projectId,
    docId,
    action: 'Document Uploaded',
    detail: `Uploaded document '${fileName}' (${docId}) for processing`,
    user,
    status: 'Info'
  })
}

export async function logProcessingStarted(projectId: string, docId: string, fileName: string, user = 'System') {
  return addAuditLog({
    projectId,
    docId,
    action: 'Processing Started',
    detail: `Started document parsing & requirement extraction for '${fileName}'`,
    user,
    status: 'Info'
  })
}

export async function logProcessingCompleted(projectId: string, docId: string, reqCount: number, confidence: number, user = 'System') {
  return addAuditLog({
    projectId,
    docId,
    action: 'Processing Completed',
    detail: `Extracted ${reqCount} requirements with ${confidence}% confidence score`,
    user,
    status: 'Success'
  })
}

export async function logProcessingFailed(projectId: string, docId: string, errorMessage: string, user = 'System') {
  return addAuditLog({
    projectId,
    docId,
    action: 'Processing Failed',
    detail: `Document processing error: ${errorMessage}`,
    user,
    status: 'Error'
  })
}

export async function logRequirementRegeneration(projectId: string, docId: string, version: number, model: string, user = 'Current User') {
  return addAuditLog({
    projectId,
    docId,
    action: 'Requirements Regenerated',
    detail: `Regenerated requirements (Version v${version}) using engine ${model}`,
    user,
    status: 'Success'
  })
}

export async function logRequirementModification(projectId: string, docId: string, reqCode: string, user = 'Current User') {
  return addAuditLog({
    projectId,
    docId,
    action: 'Requirement Modified',
    detail: `Manually updated requirement '${reqCode}'`,
    user,
    status: 'Info'
  })
}

export { getAuditLogsByProject, type AuditLogRecord }
