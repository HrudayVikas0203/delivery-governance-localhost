import { monitoring } from './monitoringService'

const configuredBaseUrl = import.meta.env.VITE_BACKEND_URL?.trim()
const BASE_URL = configuredBaseUrl
  ? configuredBaseUrl.replace(/\/$/, '')
  : ''

interface RequestOptions extends RequestInit {
  body?: BodyInit | null
  /** When true, 404 responses return null instead of throwing */
  allow404?: boolean
}

async function parseResponse<T>(response: Response, allow404 = false): Promise<T | null> {
  if (response.status === 404 && allow404) {
    return null
  }

  if (!response.ok) {
    let detail = ''
    let provider = ''
    try {
      const payload = await response.json()
      provider = typeof payload?.provider === 'string' ? payload.provider : ''
      if (typeof payload?.error === 'string' && payload?.error) {
        detail = payload.provider ? `[${payload.provider}] ${payload.error}` : payload.error
      } else if (typeof payload?.detail === 'string') {
        detail = payload.detail
      } else if (Array.isArray(payload?.detail)) {
        detail = payload.detail.map((item: { msg?: string }) => item?.msg).filter(Boolean).join(', ')
      }
    } catch {
      detail = await response.text()
    }

    const fallbackMessage = response.status >= 500
      ? 'Backend unavailable'
      : response.status === 429
        ? 'AI provider rate limit reached. Please try again later or select another configured AI provider.'
        : response.status === 404
          ? 'Requested backend resource was not found'
          : response.status === 413
            ? 'Upload failed: file exceeds the allowed size'
            : `Request failed with status ${response.status}`

    if (response.status === 429) {
      const message = 'AI provider rate limit reached. Please try again later or select another configured AI provider.'
      throw new Error(provider ? `[${provider}] ${message}` : message)
    }

    throw new Error(detail || fallbackMessage)
  }

  if (response.status === 204) {
    return undefined as T
  }

  return response.json() as Promise<T>
}

export async function httpRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { allow404, ...fetchOptions } = options
  const requestUrl = `${BASE_URL}${path}`
  void monitoring.sendTelemetry({
    location: 'httpClient.ts:httpRequest',
    message: 'API request start',
    data: {
      requestUrl,
      baseUrl: BASE_URL || '(relative-vite-proxy)',
      path,
      method: fetchOptions.method || 'GET',
      allow404: !!allow404,
    },
    hypothesisId: 'B',
    runId: 'pre-fix',
  })

  try {
    const response = await fetch(requestUrl, fetchOptions)
    void monitoring.sendTelemetry({
      location: 'httpClient.ts:httpRequest',
      message: 'API response received',
      data: { requestUrl, status: response.status, ok: response.ok, allow404: !!allow404 },
      hypothesisId: 'B',
      runId: 'pre-fix',
    })
    const parsed = await parseResponse<T>(response, allow404)
    if (parsed === null && allow404) {
      return null as T
    }
    return parsed as T
  } catch (error) {
    void monitoring.sendTelemetry({
      location: 'httpClient.ts:httpRequest',
      message: 'API request failed',
      data: {
        requestUrl,
        errorType: error instanceof Error ? error.constructor.name : typeof error,
        errorMessage: error instanceof Error ? error.message : String(error),
      },
      hypothesisId: 'B',
      runId: 'pre-fix',
    })
    if (error instanceof TypeError) {
      throw new Error('Backend unavailable. Check the FastAPI server URL or Vite proxy.')
    }
    throw error
  }
}

export { BASE_URL }
