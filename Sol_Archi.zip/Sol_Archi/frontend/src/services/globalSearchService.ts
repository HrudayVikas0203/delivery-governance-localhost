import {
  getDocumentsByProject,
  getRequirementsByProjectId,
  getAuditLogsByProject,
  type StoredDocument,
  type ExtractedRequirementsRecord,
} from './db'

export interface SearchResultItem {
  id: string
  title: string
  subtitle: string
  category: 'Projects' | 'Documents' | 'Requirements' | 'Modules' | 'Reports' | 'Audit'
  path: string
  snippet?: string
}

/**
 * Searches across projects, documents, requirements, modules, reports, and audit logs
 */
export async function executeGlobalSearch(
  projectId: string,
  query: string
): Promise<SearchResultItem[]> {
  const cleanQuery = query.trim().toLowerCase()
  if (!cleanQuery) return []

  const results: SearchResultItem[] = []

  // 1. Search Documents
  const docs = await getDocumentsByProject(projectId)
  docs.forEach(d => {
    if (d.name.toLowerCase().includes(cleanQuery) || d.rawContent.toLowerCase().includes(cleanQuery)) {
      results.push({
        id: `sr-doc-${d.id}`,
        title: d.name,
        subtitle: `Document (${d.type}) • ${d.size}`,
        category: 'Documents',
        path: '/upload',
        snippet: d.rawContent.slice(0, 100)
      })
    }
  })

  // 2. Search Requirements
  const reqsList = await getRequirementsByProjectId(projectId)
  reqsList.forEach(r => {
    r.functional.forEach(f => {
      if (f.code.toLowerCase().includes(cleanQuery) || f.title.toLowerCase().includes(cleanQuery) || f.description.toLowerCase().includes(cleanQuery)) {
        results.push({
          id: `sr-req-${f.id}`,
          title: `[${f.code}] ${f.title}`,
          subtitle: `Functional Requirement • Module: ${f.module}`,
          category: 'Requirements',
          path: '/requirements',
          snippet: f.description
        })
      }
    })

    r.nonFunctional.forEach(nf => {
      if (nf.code.toLowerCase().includes(cleanQuery) || nf.title.toLowerCase().includes(cleanQuery) || nf.description.toLowerCase().includes(cleanQuery)) {
        results.push({
          id: `sr-nfr-${nf.id}`,
          title: `[${nf.code}] ${nf.title}`,
          subtitle: `Non-Functional Requirement • Category: ${nf.category}`,
          category: 'Requirements',
          path: '/requirements',
          snippet: nf.description
        })
      }
    })

    r.modules.forEach(m => {
      if (m.name.toLowerCase().includes(cleanQuery) || m.description.toLowerCase().includes(cleanQuery)) {
        results.push({
          id: `sr-mod-${m.id}`,
          title: m.name,
          subtitle: `Business Module • Priority: ${m.priority}`,
          category: 'Modules',
          path: '/requirements',
          snippet: m.description
        })
      }
    })
  })

  // 3. Search Audit Logs
  const logs = await getAuditLogsByProject(projectId)
  logs.forEach(l => {
    if (l.action.toLowerCase().includes(cleanQuery) || l.detail.toLowerCase().includes(cleanQuery)) {
      results.push({
        id: `sr-log-${l.id}`,
        title: l.action,
        subtitle: `Audit Event by ${l.user} • ${new Date(l.timestamp).toLocaleTimeString()}`,
        category: 'Audit',
        path: '/',
        snippet: l.detail
      })
    }
  })

  return results.slice(0, 15)
}
