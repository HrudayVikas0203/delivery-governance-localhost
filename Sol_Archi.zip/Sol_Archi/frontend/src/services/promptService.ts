import {
  savePromptTemplate,
  getAllPromptTemplates,
  savePromptVersion,
  getPromptVersions,
  type PromptTemplateRecord,
  type PromptVersionRecord,
} from './db'

export const DEFAULT_PROMPT_TEMPLATES: PromptTemplateRecord[] = [
  {
    id: 'prompt-req',
    category: 'requirementExtraction',
    name: 'Requirement Extraction Prompt',
    promptText: `Analyze the provided document text and extract structured solution architecture requirements in valid JSON format. Focus on functional rules, non-functional latency SLA, and actor roles.`,
    version: 1,
    updatedAt: new Date().toISOString(),
    author: 'System Admin'
  },
  {
    id: 'prompt-flow',
    category: 'businessFlow',
    name: 'Business Flow Prompt',
    promptText: `Generate a Business Process Flow (React Flow nodes and edges) based on extracted requirements. Identify start, end, decision, and activity nodes.`,
    version: 1,
    updatedAt: new Date().toISOString(),
    author: 'System Admin'
  },
  {
    id: 'prompt-arch',
    category: 'architecture',
    name: 'Solution Architecture Prompt',
    promptText: `Generate Solution Architecture (nodes and edges) for the specified technology stack spanning Presentation, Middleware, Backend, Data, and Infrastructure layers.`,
    version: 1,
    updatedAt: new Date().toISOString(),
    author: 'System Admin'
  },
  {
    id: 'prompt-reports',
    category: 'reports',
    name: 'Executive Report Prompt',
    promptText: `Synthesize a professional multi-section executive solution report formatted in markdown with bullet points and bold section headers.`,
    version: 1,
    updatedAt: new Date().toISOString(),
    author: 'System Admin'
  },
  {
    id: 'prompt-chat',
    category: 'aiChat',
    name: 'AI Copilot Assistant Prompt',
    promptText: `You are an expert Enterprise Solution Architect Copilot. Answer the user's question using retrieved RAG contexts and active project state.`,
    version: 1,
    updatedAt: new Date().toISOString(),
    author: 'System Admin'
  }
]

export async function initDefaultPromptTemplates(): Promise<void> {
  const existing = await getAllPromptTemplates()
  if (existing.length === 0) {
    for (const tmpl of DEFAULT_PROMPT_TEMPLATES) {
      await savePromptTemplate(tmpl)
    }
  }
}

export async function updatePromptTemplate(
  id: string,
  newText: string,
  author = 'Admin User',
  summary = 'Updated prompt template'
): Promise<PromptTemplateRecord> {
  const templates = await getAllPromptTemplates()
  const tmpl = templates.find(t => t.id === id) || DEFAULT_PROMPT_TEMPLATES.find(t => t.id === id)
  if (!tmpl) throw new Error(`Prompt template '${id}' not found.`)

  const nextVer = tmpl.version + 1
  const updated: PromptTemplateRecord = {
    ...tmpl,
    promptText: newText,
    version: nextVer,
    updatedAt: new Date().toISOString(),
    author,
  }

  await savePromptTemplate(updated)

  const verRecord: PromptVersionRecord = {
    id: `pver-${id}-v${nextVer}`,
    templateId: id,
    category: tmpl.category,
    version: nextVer,
    promptText: newText,
    timestamp: new Date().toISOString(),
    author,
    changeSummary: summary,
  }

  await savePromptVersion(verRecord)
  return updated
}

export async function rollbackPromptTemplate(
  versionRecord: PromptVersionRecord
): Promise<PromptTemplateRecord> {
  return updatePromptTemplate(
    versionRecord.templateId,
    versionRecord.promptText,
    versionRecord.author,
    `Rollback to version v${versionRecord.version}`
  )
}

export { getPromptVersions, getAllPromptTemplates }
