import type { AiConfig } from '../data/aiConfig'
import type {
  ArchitectureVersionRecord,
  BusinessFlowVersionRecord,
  ExtractedRequirementsRecord,
  RequirementVersionRecord,
  StoredArchitecture,
  StoredBusinessFlow,
  StoredDocument,
} from './db'
import type { Project, Requirement, Actor, BusinessModule, BusinessRule, Assumption, Constraint, ExternalSystem, Risk, ExecutiveArchitectureData } from '../data/types'
import { httpRequest } from './httpClient'
import { normalizeExecutiveArchitecture } from '../components/ExecutiveArchitectureCanvas'

export interface BackendProject {
  id: string
  name: string
  description: string
  createdAt: string
  selectedTechStack: string
  selectedDatabase: string
  isStackConfirmed: boolean
}

export interface BackendUploadResponse {
  documentId: string
  name: string
  type: string
  size: string
  uploadedAt: string
  status: string
}

export interface BackendProjectDocument {
  documentId: string
  name: string
  type: string
  size: string
  uploadedAt: string
  status: string
  pageCount?: number
}

export interface BackendChatSource {
  documentId: string
  documentName: string
  chunkNumber: number
  chunkContent: string
  similarityScore: number
}

export interface BackendChatResponse {
  answer: string
  sources: BackendChatSource[]
  responseTimeMs: number
}

function mapDocument(doc: BackendProjectDocument, projectId: string): StoredDocument {
  return {
    id: doc.documentId,
    name: doc.name,
    type: (doc.type || 'BRD') as StoredDocument['type'],
    size: doc.size,
    uploadedAt: doc.uploadedAt,
    status: (doc.status || 'Completed') as StoredDocument['status'],
    projectId,
    pages: doc.pageCount ?? 0,
    confidence: doc.status === 'Completed' ? 100 : 0,
    hash: '',
    rawContent: '',
  }
}

function mapRequirements(record: any, projectId: string, docId: string): ExtractedRequirementsRecord | null {
  if (!record) {
    return null
  }

  const normalizeReq = (r: any, idx: number, defaultType: 'Functional' | 'Non-Functional'): Requirement => {
    if (typeof r === 'string') {
      return {
        id: `req-${defaultType.toLowerCase()}-${idx + 1}`,
        code: `${defaultType === 'Functional' ? 'FR' : 'NFR'}-${String(idx + 1).padStart(3, '0')}`,
        title: r.slice(0, 60),
        description: r,
        priority: 'Medium',
        category: 'General',
        module: 'General',
        status: 'Extracted',
        type: defaultType,
      }
    }
    const code = r?.code || r?.reqCode || r?.identifier || r?.id || `${defaultType === 'Functional' ? 'FR' : 'NFR'}-${String(idx + 1).padStart(3, '0')}`
    const title = r?.title || r?.name || r?.requirementName || r?.label || r?.summary || r?.description?.slice(0, 60) || `Requirement ${idx + 1}`
    const description = r?.description || r?.details || r?.desc || r?.summary || r?.text || r?.content || title
    const priority = r?.priority || r?.importance || r?.severity || r?.level || 'Medium'
    const category = r?.category || r?.domain || r?.type || r?.area || 'General'
    const moduleName = r?.module || r?.component || r?.feature || r?.systemModule || 'General'
    const status = r?.status || r?.state || r?.validationStatus || 'Extracted'
    const reqType = r?.type || defaultType

    return {
      id: r?.id || `req-${defaultType.toLowerCase()}-${idx + 1}-${code}`,
      code,
      title,
      description,
      priority,
      category,
      module: moduleName,
      status,
      type: reqType,
    }
  }

  const normalizeActor = (a: any, idx: number): Actor => {
    if (typeof a === 'string') {
      return { id: `act-${idx + 1}`, name: a, description: '', type: 'Primary', icon: 'User' }
    }
    return {
      id: a?.id || `act-${idx + 1}`,
      name: a?.name || a?.actorName || a?.title || a?.role || a?.label || `Actor ${idx + 1}`,
      description: a?.description || a?.desc || a?.details || a?.roleDescription || a?.summary || '',
      type: a?.type || a?.actorType || a?.category || 'Primary',
      icon: a?.icon || 'User',
    }
  }

  const normalizeModule = (m: any, idx: number): BusinessModule => {
    if (typeof m === 'string') {
      return { id: `mod-${idx + 1}`, name: m, description: '', priority: 'Medium', requirements: 0, status: 'Analyzed' }
    }
    return {
      id: m?.id || `mod-${idx + 1}`,
      name: m?.name || m?.moduleName || m?.title || m?.label || `Module ${idx + 1}`,
      description: m?.description || m?.desc || m?.summary || '',
      priority: m?.priority || m?.importance || 'Medium',
      requirements: typeof m?.requirements === 'number' ? m.requirements : (typeof m?.requirementCount === 'number' ? m.requirementCount : 0),
      status: m?.status || m?.state || 'Analyzed',
    }
  }

  const normalizeBusinessRule = (br: any, idx: number): BusinessRule => {
    if (typeof br === 'string') {
      return { id: `br-${idx + 1}`, rule: br, module: 'General' }
    }
    return {
      id: br?.id || `br-${idx + 1}`,
      rule: br?.rule || br?.ruleDescription || br?.description || br?.title || br?.name || br?.text || `Business Rule ${idx + 1}`,
      module: br?.module || br?.component || br?.category || 'General',
    }
  }

  const normalizeAssumption = (as: any, idx: number): Assumption => {
    if (typeof as === 'string') {
      return { id: `as-${idx + 1}`, assumption: as, category: 'Technical' }
    }
    return {
      id: as?.id || `as-${idx + 1}`,
      assumption: as?.assumption || as?.description || as?.title || as?.name || as?.text || `Assumption ${idx + 1}`,
      category: as?.category || as?.type || 'Technical',
    }
  }

  const normalizeConstraint = (c: any, idx: number): Constraint => {
    if (typeof c === 'string') {
      return { id: `c-${idx + 1}`, constraint: c, category: 'Architecture' }
    }
    return {
      id: c?.id || `c-${idx + 1}`,
      constraint: c?.constraint || c?.description || c?.title || c?.name || c?.text || `Constraint ${idx + 1}`,
      category: c?.category || c?.type || 'Architecture',
    }
  }

  const normalizeExternalSystem = (ext: any, idx: number): ExternalSystem => {
    if (typeof ext === 'string') {
      return { id: `ext-${idx + 1}`, name: ext, type: 'REST', integration: 'Inbound', direction: 'Inbound' }
    }
    return {
      id: ext?.id || `ext-${idx + 1}`,
      name: ext?.name || ext?.systemName || ext?.title || `External System ${idx + 1}`,
      type: ext?.type || ext?.systemType || 'REST',
      integration: ext?.integration || ext?.protocol || ext?.method || 'REST',
      direction: ext?.direction || ext?.flow || 'Inbound',
    }
  }

  const normalizeRisk = (r: any, idx: number): Risk => {
    if (typeof r === 'string') {
      return { id: `rsk-${idx + 1}`, risk: r, probability: 'Medium', impact: 'Medium', mitigation: '' }
    }
    return {
      id: r?.id || `rsk-${idx + 1}`,
      risk: r?.risk || r?.description || r?.title || r?.name || r?.text || `Risk ${idx + 1}`,
      probability: r?.probability || r?.likelihood || 'Medium',
      impact: r?.impact || r?.severity || 'Medium',
      mitigation: r?.mitigation || r?.mitigationStrategy || r?.resolution || '',
    }
  }

  const rawReq = record.requirements || record
  const functional = Array.isArray(rawReq.functional) ? rawReq.functional.map((r: any, idx: number) => normalizeReq(r, idx, 'Functional')) : []
  const nonFunctional = Array.isArray(rawReq.nonFunctional) ? rawReq.nonFunctional.map((r: any, idx: number) => normalizeReq(r, idx, 'Non-Functional')) : []
  const actors = Array.isArray(rawReq.actors) ? rawReq.actors.map((a: any, idx: number) => normalizeActor(a, idx)) : []
  const modules = Array.isArray(rawReq.modules) ? rawReq.modules.map((m: any, idx: number) => normalizeModule(m, idx)) : []
  const businessRules = Array.isArray(rawReq.businessRules) ? rawReq.businessRules.map((br: any, idx: number) => normalizeBusinessRule(br, idx)) : []
  const assumptions = Array.isArray(rawReq.assumptions) ? rawReq.assumptions.map((as: any, idx: number) => normalizeAssumption(as, idx)) : []
  const constraints = Array.isArray(rawReq.constraints) ? rawReq.constraints.map((c: any, idx: number) => normalizeConstraint(c, idx)) : []
  const externalSystems = Array.isArray(rawReq.externalSystems) ? rawReq.externalSystems.map((ext: any, idx: number) => normalizeExternalSystem(ext, idx)) : []
  const risks = Array.isArray(rawReq.risks) ? rawReq.risks.map((r: any, idx: number) => normalizeRisk(r, idx)) : []

  return {
    id: record.id || `req-rec-${docId}`,
    docId,
    projectId,
    overview: rawReq.overview || record.overview || '',
    businessObjectives: rawReq.businessObjectives || record.businessObjectives || [],
    projectScope: rawReq.projectScope || record.projectScope || { inScope: [], outOfScope: [] },
    stakeholders: rawReq.stakeholders || record.stakeholders || [],
    actors,
    modules,
    functional,
    nonFunctional,
    businessRules,
    assumptions,
    constraints,
    externalSystems,
    risks,
    dependencies: rawReq.dependencies || record.dependencies || [],
    version: record.version || 1,
    updatedAt: record.updatedAt || new Date().toISOString(),
    generatorModel: record.modelUsed || record.generatorModel || '',
  }
}

function mapFlow(record: any, projectId: string, docId: string): StoredBusinessFlow | null {
  if (!record) {
    return null
  }

  return {
    id: record.id || `flow-${docId}`,
    docId,
    projectId,
    nodes: record.nodes || [],
    edges: record.edges || [],
    version: record.version || 1,
    updatedAt: record.updatedAt || new Date().toISOString(),
  }
}

function buildDefaultExecutiveArchitecture(record: any): ExecutiveArchitectureData {
  return {
    templateId: 'enterpriseConsulting',
    themeId: 'corporateBlue',
    title: 'Enterprise Solution Architecture',
    subtitle: 'Consulting-ready operating blueprint',
    layoutNarrative: 'A compact layered view balancing stakeholders, capabilities, platforms, and outcomes.',
    generatedVariantId: 'default-fallback',
    layers: [
      {
        id: 'layer-1',
        name: '1. Experience & Business Users Domain',
        category: 'Experience Layer',
        items: [
          { id: 'u-1', name: 'Business Analysts Workspace', description: 'Requirements gathering & process modeling', businessPurpose: 'Enables rapid scoping and user story extraction.', technicalDetails: 'React SPA, Vite, Tailwind CSS, Lucide icons', icon: 'User', badge: 'Operations' },
          { id: 'u-2', name: 'Solution Architecture Portal', description: 'Technical topology & API design governance', businessPurpose: 'Empowers solution architects to refine cloud topology.', technicalDetails: 'TypeScript, React Flow, Cytoscape.js canvas', icon: 'UserCog', badge: 'Architect' },
          { id: 'u-3', name: 'Executive Strategy Dashboard', description: 'Portfolio alignment & technology standards', businessPurpose: 'Provides C-level visibility into enterprise ROI.', technicalDetails: 'Recharts analytics, PDF/PNG export engines', icon: 'Crown', badge: 'Leadership' },
          { id: 'u-4', name: 'AI Copilot Chat Assistant', description: 'Context-aware document Q&A engine', businessPurpose: 'Delivers real-time answers grounded in BRD docs.', technicalDetails: 'FastAPI streaming, RAG vector retrieval', icon: 'Brain', badge: 'AI Copilot' },
          { id: 'u-5', name: 'DevOps & SRE Command Hub', description: 'Deployment monitoring & release controls', businessPurpose: 'Monitors CI/CD pipelines and deployment status.', technicalDetails: 'GitHub Actions, Prometheus metrics', icon: 'Terminal', badge: 'DevOps' },
          { id: 'u-6', name: 'External Partner Developer Portal', description: 'Third-party API access and developer onboarding', businessPurpose: 'Secures external ecosystem integration.', technicalDetails: 'Azure APIM Developer Portal / OAuth2', icon: 'Globe', badge: 'External' }
        ]
      },
      {
        id: 'layer-2',
        name: '2. Business Capabilities & Core Services',
        category: 'Business Services',
        items: [
          { id: 'c-1', name: 'Requirement Extraction Engine', description: 'Automated BRD/RFP parsing & extraction', businessPurpose: 'Accelerates specification intake by 80%.', technicalDetails: 'FastAPI Python backend, Regex & LLM parsers', icon: 'FileText', badge: 'Capability' },
          { id: 'c-2', name: 'Business Process Flow Synthesizer', description: 'Flow diagram synthesis & state validation', businessPurpose: 'Converts unstructured text to BPMN state flows.', technicalDetails: 'Mermaid.js, Graphviz, PlantUML syntax generator', icon: 'Layers', badge: 'BPM Engine' },
          { id: 'c-3', name: 'Solution Architecture Synthesizer', description: 'Multi-tier cloud topology generation', businessPurpose: 'Synthesizes enterprise target state architectures.', technicalDetails: 'Azure OpenAI GPT-4o / Groq LLM router', icon: 'Cpu', badge: 'Core Engine' },
          { id: 'c-4', name: 'Database ER Schema Modeler', description: 'Relational & NoSQL schema design', businessPurpose: 'Generates DDL scripts and normalized tables.', technicalDetails: 'PostgreSQL DDL, ChromaDB vector collections', icon: 'Database', badge: 'Data Model' },
          { id: 'c-5', name: 'Governance & Sign-off Engine', description: 'Architectural decision reviews & approvals', businessPurpose: 'Enforces architectural compliance and audit tracking.', technicalDetails: 'JSON Web Tokens, Entra ID RBAC policies', icon: 'Shield', badge: 'Governance' },
          { id: 'c-6', name: 'Executive Deliverable Report Builder', description: 'Multi-section client report assembly', businessPurpose: 'Generates presentation-ready client deliverables.', technicalDetails: 'Node.js, PDFKit, Recharts PDF renderer', icon: 'BarChart3', badge: 'Reporting' }
        ]
      },
      {
        id: 'layer-3',
        name: '3. Core AI Platform & Intelligence',
        category: 'AI Platform',
        items: [
          { id: 'ai-1', name: 'LLM Multi-Model Orchestrator', description: 'Multi-provider routing across OpenAI & Anthropic', businessPurpose: 'Guarantees fallback availability and cost optimization.', technicalDetails: 'LangChain, LlamaIndex, Custom Python Async Router', icon: 'Brain', badge: 'AI Core' },
          { id: 'ai-2', name: 'RAG Context Building Pipeline', description: 'Semantic chunking & vector search indexing', businessPurpose: 'Eliminates AI hallucinations via strict document grounding.', technicalDetails: 'ChromaDB vector DB, OpenAI text-embedding-3', icon: 'Sparkles', badge: 'RAG Engine' },
          { id: 'ai-3', name: 'Prompt Template Manager', description: 'Structured prompt versioning and guardrails', businessPurpose: 'Standardizes consulting output formats across runs.', technicalDetails: 'Pydantic JSON schema validators', icon: 'Settings', badge: 'Prompts' },
          { id: 'ai-4', name: 'Response Validation Engine', description: 'Schema compliance and quality scoring', businessPurpose: 'Guarantees valid JSON payloads before UI render.', technicalDetails: 'FastAPI validation middleware, PyDantic v2', icon: 'CheckCircle2', badge: 'Evaluation' },
          { id: 'ai-5', name: 'AI Guardrails & PII Masking Pipeline', description: 'PII anonymization & safety verification', businessPurpose: 'Protects enterprise data privacy before LLM invocation.', technicalDetails: 'NeMo Guardrails, Presidio PII Masker', icon: 'Lock', badge: 'Safety' },
          { id: 'ai-6', name: 'Embedding Index Refresh Service', description: 'Asynchronous document vector synchronization', businessPurpose: 'Keeps RAG vector index up to date with new BRDs.', technicalDetails: 'Python Celery, ChromaDB HNSW Indexer', icon: 'Search', badge: 'Index' }
        ]
      },
      {
        id: 'layer-4',
        name: '4. Integration & API Gateway Layer',
        category: 'Integration & API Layer',
        items: [
          { id: 'int-1', name: 'REST & GraphQL API Gateway', description: 'Secure API endpoint routing & rate limiting', businessPurpose: 'Standardizes integration access for third-party systems.', technicalDetails: 'FastAPI CORS middleware, Nginx reverse proxy', icon: 'ArrowLeftRight', badge: 'Perimeter' },
          { id: 'int-2', name: 'Microsoft Entra ID / OAuth SSO', description: 'Enterprise identity & RBAC token verification', businessPurpose: 'Secures corporate assets with single sign-on.', technicalDetails: 'OAuth2 bearer tokens, JWT RS256 signatures', icon: 'Key', badge: 'Identity' },
          { id: 'int-3', name: 'Event Bus & Async Webhooks', description: 'Asynchronous event streaming and notifications', businessPurpose: 'Supports decoupling of background generation tasks.', technicalDetails: 'Python asyncio event queues, Celery worker pool', icon: 'Zap', badge: 'Messaging' },
          { id: 'int-4', name: 'Enterprise Connector Framework', description: 'Adapters for legacy ERP & SaaS platforms', businessPurpose: 'Integrates enterprise systems of record.', technicalDetails: 'Node.js microservices, gRPC protocol adapters', icon: 'Workflow', badge: 'Connector' },
          { id: 'int-5', name: 'Service Mesh & Internal Router', description: 'Zero-trust intra-service routing & telemetry', businessPurpose: 'Secures microservice-to-microservice traffic.', technicalDetails: 'Istio, Envoy Proxy, mTLS encryption', icon: 'Network', badge: 'Mesh' },
          { id: 'int-6', name: 'Real-Time Notification Broker', description: 'WebSockets & SSE push messaging', businessPurpose: 'Delivers real-time progress updates to frontend.', technicalDetails: 'WebSocket Server, Redis Pub/Sub', icon: 'Radio', badge: 'Realtime' }
        ]
      },
      {
        id: 'layer-5',
        name: '5. Core Data Platform & Storage',
        category: 'Data Platform',
        items: [
          { id: 'd-1', name: 'Relational Metadata Database Cluster', description: 'Structured projects, versions, & requirements', businessPurpose: 'Maintains system of record for all design assets.', technicalDetails: 'SQLite / PostgreSQL 16 with WAL journaling', icon: 'Database', badge: 'Relational DB' },
          { id: 'd-2', name: 'Vector Knowledge Database', description: 'High-dimensional embeddings for semantic search', businessPurpose: 'Enables sub-second semantic retrieval across BRDs.', technicalDetails: 'ChromaDB persistent vector store with HNSW index', icon: 'Search', badge: 'Vector DB' },
          { id: 'd-3', name: 'Secure Object Storage Vault', description: 'Encrypted storage for generated PDFs & exports', businessPurpose: 'Protects confidential client deliverables.', technicalDetails: 'Local blob storage / Azure Blob Storage AES-256', icon: 'HardDrive', badge: 'Object Storage' },
          { id: 'd-4', name: 'High-Performance Cache Cluster', description: 'Low-latency session & query cache', businessPurpose: 'Accelerates API response times and session lookups.', technicalDetails: 'Redis 7 / Azure Cache for Redis', icon: 'Zap', badge: 'Cache' },
          { id: 'd-5', name: 'Observability & Telemetry Vault', description: 'Centralized audit logging and metrics', businessPurpose: 'Guarantees SLA tracking and system health monitoring.', technicalDetails: 'Prometheus, OpenTelemetry, Azure Monitor', icon: 'Activity', badge: 'Telemetry' },
          { id: 'd-6', name: 'Container Compute Runtime Cluster', description: 'Microservices OCI container runtime execution', businessPurpose: 'Provides elastic container hosting environment.', technicalDetails: 'Docker containers, Azure Container Apps / AKS', icon: 'Boxes', badge: 'Compute' }
        ]
      }
    ],
    architecturalDecisions: [
      { id: 'ad-1', decision: 'Microservices & Layered Modular Design', whyChosen: 'Decouples AI processing engines from UI rendering, allowing independent scaling of heavy LLM extraction workloads.' },
      { id: 'ad-2', decision: 'API-First Open Integration Strategy', whyChosen: 'Exposes clean REST contracts enabling seamless connectivity with enterprise ERP, Azure DevOps, and Jira.' },
      { id: 'ad-3', decision: 'Role-Based Access Control (RBAC) & Entra ID SSO', whyChosen: 'Enforces strict organizational governance and enterprise identity compliance across all project artifacts.' },
      { id: 'ad-4', decision: 'RAG Vector Indexing for Contextual AI Chat', whyChosen: 'Eliminates AI hallucinations by grounding copilot responses strictly in uploaded BRD and RFP document chunks.' },
    ],
    businessValue: [
      { id: 'bv-1', title: '75% Faster Solution Design Cycles', description: 'Reduces time-to-architecture from weeks of manual diagramming to minutes of automated AI synthesis.' },
      { id: 'bv-2', title: 'Enhanced Architectural Governance', description: 'Ensures strict consistency, traceability, and version control across all enterprise solution designs.' },
      { id: 'bv-3', title: 'Reduced Operational Costs & Rework', description: 'Identifies missing requirements and integration bottlenecks early before expensive software build phases.' },
      { id: 'bv-4', title: 'Executive-Ready Consulting Deliverables', description: 'Generates professional multi-tier architecture diagrams ready for C-level leadership presentations.' },
    ],
    technologyHighlights: [
      { id: 'th-1', title: 'API-First Delivery', summary: 'Reusable service contracts support downstream integration and controlled change.', category: 'Integration', badge: 'Core' },
      { id: 'th-2', title: 'Cloud-Managed Data Services', summary: 'Managed persistence and storage reduce operational overhead while improving resilience.', category: 'Platform', badge: 'Managed' },
      { id: 'th-3', title: 'AI Grounding Layer', summary: 'Context retrieval keeps generated outputs aligned to approved source documents.', category: 'AI', badge: 'RAG' },
      { id: 'th-4', title: 'Governance Automation', summary: 'Versioning and approvals improve traceability across architecture iterations.', category: 'Controls', badge: 'Audit' },
    ],
    executiveInsights: [
      { id: 'ei-1', title: 'Primary transformation lever', description: 'Automation shortens architecture cycle time while increasing consistency.', badge: 'Speed' },
      { id: 'ei-2', title: 'Control point', description: 'Identity, audit, and approval layers create a defensible enterprise operating posture.', badge: 'Governance' },
      { id: 'ei-3', title: 'Scalability theme', description: 'Loose coupling between design services and delivery channels supports future expansion.', badge: 'Scale' },
    ]
  }
}

function mapArchitecture(record: any, projectId: string, docId: string): StoredArchitecture | null {
  if (!record) {
    return null
  }

  const rawExec = record.executive || buildDefaultExecutiveArchitecture(record)
  const executive = normalizeExecutiveArchitecture(rawExec)

  return {
    id: record.id || `arch-${docId}`,
    docId,
    projectId,
    nodes: record.nodes || [],
    edges: record.edges || [],
    executive,
    techStackDetails: record.techStackDetails,
    version: record.version || 1,
    updatedAt: record.updatedAt || new Date().toISOString(),
  }
}

export const backendApi = {
  async health() {
    return httpRequest('/health')
  },

  async listProjects(): Promise<BackendProject[]> {
    return httpRequest<BackendProject[]>('/api/projects')
  },

  async createProject(payload: {
    name: string
    description?: string
    selectedTechStack?: string
    selectedDatabase?: string
    isStackConfirmed?: boolean
  }): Promise<BackendProject> {
    return httpRequest<BackendProject>('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
  },

  async uploadDocument(file: File, projectId: string): Promise<BackendUploadResponse> {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('projectId', projectId)

    return httpRequest<BackendUploadResponse>('/api/documents/upload', {
      method: 'POST',
      body: formData,
    })
  },

  async listProjectDocuments(projectId: string): Promise<StoredDocument[]> {
    const response = await httpRequest<BackendProjectDocument[]>(`/api/documents/project/${projectId}`)
    return (response ?? []).map((doc) => mapDocument(doc, projectId))
  },

  async generateRequirements(projectId: string, docId: string, aiConfig: AiConfig): Promise<ExtractedRequirementsRecord> {
    const response = await httpRequest<any>('/api/requirements/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, docId, text: '', aiConfig }),
    })

    const record = mapRequirements(response, projectId, docId)
    if (!record) {
      throw new Error('Document processing failed: backend returned empty requirements')
    }
    return record
  },

  async getRequirements(docId: string, projectId: string): Promise<ExtractedRequirementsRecord | null> {
    const response = await httpRequest<{ documentId: string; requirements: any }>(`/api/requirements/${docId}`, { allow404: true })
    if (!response) return null
    return mapRequirements(response.requirements, projectId, docId)
  },

  async updateRequirements(docId: string, payload: Partial<ExtractedRequirementsRecord> & { projectId: string }) {
    const response = await httpRequest<{ payload: any }>(`/api/requirements/${docId}/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    return mapRequirements(response.payload, payload.projectId, docId)
  },

  async getRequirementVersions(docId: string): Promise<RequirementVersionRecord[]> {
    return []
  },

  async generateBusinessFlow(projectId: string, docId: string, aiConfig: AiConfig): Promise<StoredBusinessFlow> {
    const response = await httpRequest<any>('/api/business-flow/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, docId, aiConfig }),
    })
    const record = mapFlow(response, projectId, docId)
    if (!record) {
      throw new Error('Business flow generation failed')
    }
    return record
  },

  async getBusinessFlow(docId: string, projectId: string): Promise<StoredBusinessFlow | null> {
    const response = await httpRequest<{ businessFlow: any }>(`/api/business-flow/${docId}`, { allow404: true })
    if (!response) return null
    return mapFlow(response.businessFlow, projectId, docId)
  },

  async saveBusinessFlow(docId: string, projectId: string, nodes: any[], edges: any[]): Promise<StoredBusinessFlow> {
    const response = await httpRequest<{ payload: any }>(`/api/business-flow/${docId}/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ docId, projectId, nodes, edges }),
    })
    const record = mapFlow(response.payload, projectId, docId)
    if (!record) {
      throw new Error('Business flow save failed')
    }
    return record
  },

  async getBusinessFlowVersions(docId: string): Promise<BusinessFlowVersionRecord[]> {
    const response = await httpRequest<{ versions: any[] }>(`/api/business-flow/${docId}/versions`, { allow404: true })
    if (!response) return []
    return (response.versions || []).map((version) => ({
      id: version.id || `flow-ver-${docId}-v${version.version}`,
      docId,
      projectId: version.projectId,
      version: version.version,
      timestamp: version.timestamp || version.updatedAt || new Date().toISOString(),
      author: version.createdBy || version.author || 'System',
      changeType: version.changeType || 'Regenerated',
      changeSummary: version.changeSummary || `Business Flow v${version.version}`,
      flowSnapshot: mapFlow(version, version.projectId, docId)!,
    }))
  },

  async generateArchitecture(projectId: string, docId: string, techStack: string, aiConfig: AiConfig): Promise<StoredArchitecture> {
    const response = await httpRequest<any>('/api/architecture/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectId, docId, techStack, aiConfig }),
    })
    const record = mapArchitecture(response, projectId, docId)
    if (!record) {
      throw new Error('Architecture generation failed')
    }
    return record
  },

  async getArchitecture(docId: string, projectId: string): Promise<StoredArchitecture | null> {
    const response = await httpRequest<{ architecture: any }>(`/api/architecture/${docId}`, { allow404: true })
    if (!response) return null
    return mapArchitecture(response.architecture, projectId, docId)
  },

  async saveArchitecture(
    docId: string,
    projectId: string,
    nodes: any[],
    edges: any[],
    techStackDetails?: Project['techStackDetails'],
    executive?: ExecutiveArchitectureData
  ): Promise<StoredArchitecture> {
    const response = await httpRequest<{ payload: any }>(`/api/architecture/${docId}/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ docId, projectId, nodes, edges, techStackDetails, executive }),
    })
    const record = mapArchitecture(response.payload, projectId, docId)
    if (!record) {
      throw new Error('Architecture save failed')
    }
    return record
  },

  async getArchitectureVersions(docId: string): Promise<ArchitectureVersionRecord[]> {
    const response = await httpRequest<{ versions: any[] }>(`/api/architecture/${docId}/versions`, { allow404: true })
    if (!response) return []
    return (response.versions || []).map((version) => ({
      id: version.id || `arch-ver-${docId}-v${version.version}`,
      docId,
      projectId: version.projectId,
      version: version.version,
      timestamp: version.timestamp || version.updatedAt || new Date().toISOString(),
      author: version.createdBy || version.author || 'System',
      changeType: version.changeType || 'Regenerated',
      changeSummary: version.changeSummary || `Solution Architecture v${version.version}`,
      architectureSnapshot: mapArchitecture(version, version.projectId, docId)!,
    }))
  },

  async queryProjectChat(
    projectId: string,
    sessionId: string,
    question: string,
    history: { role: 'user' | 'assistant'; content: string }[],
    aiConfig: AiConfig,
    project: Project,
  ): Promise<BackendChatResponse> {
    return httpRequest<BackendChatResponse>('/api/chat/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        projectId,
        sessionId,
        question,
        history,
        aiConfig,
        projectMetadata: {
          id: project.id,
          name: project.name,
          description: project.description,
          selectedTechStack: project.selectedTechStack,
          selectedDatabase: project.selectedDatabase,
        },
      }),
    })
  },
}
