const isBrowser = typeof window !== 'undefined'

export const STORAGE_KEYS = {
  aiConfig: 'ai_copilot_config',
  activeProjectId: 'copilot_active_project_id',
  currentUser: 'copilot_user',
  allUsers: 'copilot_all_users',
  mfaPendingUser: 'copilot_mfa_pending_user',
} as const

function readValue<T>(storage: Storage, key: string): T | null {
  try {
    const raw = storage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch (error) {
    console.error(`Failed to read storage key "${key}"`, error)
    return null
  }
}

function writeValue(storage: Storage, key: string, value: unknown) {
  try {
    storage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Failed to write storage key "${key}"`, error)
  }
}

function removeValue(storage: Storage, key: string) {
  try {
    storage.removeItem(key)
  } catch (error) {
    console.error(`Failed to remove storage key "${key}"`, error)
  }
}

export const browserStorage = {
  getLocal<T>(key: string): T | null {
    return isBrowser ? readValue<T>(window.localStorage, key) : null
  },
  setLocal(key: string, value: unknown) {
    if (isBrowser) {
      writeValue(window.localStorage, key, value)
    }
  },
  removeLocal(key: string) {
    if (isBrowser) {
      removeValue(window.localStorage, key)
    }
  },
  getSession<T>(key: string): T | null {
    return isBrowser ? readValue<T>(window.sessionStorage, key) : null
  },
  setSession(key: string, value: unknown) {
    if (isBrowser) {
      writeValue(window.sessionStorage, key, value)
    }
  },
  removeSession(key: string) {
    if (isBrowser) {
      removeValue(window.sessionStorage, key)
    }
  },
}

export function readPersistedAuthUser<T>() {
  return browserStorage.getLocal<T>(STORAGE_KEYS.currentUser) ?? browserStorage.getSession<T>(STORAGE_KEYS.currentUser)
}

export function persistAuthUser(user: unknown, rememberUser: boolean) {
  if (rememberUser) {
    browserStorage.setLocal(STORAGE_KEYS.currentUser, user)
    browserStorage.removeSession(STORAGE_KEYS.currentUser)
    return
  }

  browserStorage.setSession(STORAGE_KEYS.currentUser, user)
  browserStorage.removeLocal(STORAGE_KEYS.currentUser)
}

export function clearAuthSession() {
  browserStorage.removeLocal(STORAGE_KEYS.currentUser)
  browserStorage.removeSession(STORAGE_KEYS.currentUser)
  browserStorage.removeSession(STORAGE_KEYS.mfaPendingUser)
}
