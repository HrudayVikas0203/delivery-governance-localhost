import { toPng, toSvg } from 'html-to-image'
import { jsPDF } from 'jspdf'
import type { FlowNode, FlowEdge, ArchNode, ArchEdge, DBEntity, DBField } from '../data/types'

export type ExportFormat = 'PNG' | 'SVG' | 'PDF' | 'Mermaid' | 'Draw.io' | 'PlantUML' | 'SQL' | 'JSON' | 'DOCX' | 'Markdown' | 'CSV' | 'HTML'

const PDF_MARGIN_PX = 24
const SINGLE_PAGE_SCALE_THRESHOLD = 0.6

function getElementExportBounds(element: HTMLElement) {
  const rect = element.getBoundingClientRect()

  return {
    width: Math.max(
      Math.ceil(rect.width),
      element.scrollWidth,
      element.clientWidth,
      element.offsetWidth
    ),
    height: Math.max(
      Math.ceil(rect.height),
      element.scrollHeight,
      element.clientHeight,
      element.offsetHeight
    ),
  }
}

function loadImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = () => reject(new Error('Failed to load rendered image for export.'))
    image.src = dataUrl
  })
}

async function exportPngToPdf(dataUrl: string, exportWidth: number, exportHeight: number, filename: string) {
  const pdf = new jsPDF({
    orientation: 'landscape',
    unit: 'px',
    format: 'a4',
  })

  const pageWidth = pdf.internal.pageSize.getWidth()
  const pageHeight = pdf.internal.pageSize.getHeight()
  const availableWidth = pageWidth - PDF_MARGIN_PX * 2
  const availableHeight = pageHeight - PDF_MARGIN_PX * 2
  const singlePageScale = Math.min(availableWidth / exportWidth, availableHeight / exportHeight)

  if (singlePageScale >= SINGLE_PAGE_SCALE_THRESHOLD || exportHeight * (availableWidth / exportWidth) <= availableHeight) {
    const scaledWidth = exportWidth * singlePageScale
    const scaledHeight = exportHeight * singlePageScale
    const x = (pageWidth - scaledWidth) / 2
    const y = (pageHeight - scaledHeight) / 2

    pdf.addImage(dataUrl, 'PNG', x, y, scaledWidth, scaledHeight)
    pdf.save(`${filename}.pdf`)
    return
  }

  const image = await loadImage(dataUrl)
  const scaleToWidth = availableWidth / exportWidth
  const sourceSliceHeight = Math.max(1, Math.floor(availableHeight / scaleToWidth))
  const sliceCanvas = document.createElement('canvas')
  const sliceContext = sliceCanvas.getContext('2d')

  if (!sliceContext) {
    throw new Error('Unable to prepare multi-page PDF export.')
  }

  sliceCanvas.width = image.width

  let offsetY = 0
  let isFirstPage = true

  while (offsetY < image.height) {
    const sliceHeight = Math.min(sourceSliceHeight, image.height - offsetY)
    sliceCanvas.height = sliceHeight
    sliceContext.clearRect(0, 0, sliceCanvas.width, sliceHeight)
    sliceContext.drawImage(
      image,
      0,
      offsetY,
      image.width,
      sliceHeight,
      0,
      0,
      image.width,
      sliceHeight
    )

    if (!isFirstPage) {
      pdf.addPage('a4', 'landscape')
    }

    const renderedHeight = sliceHeight * scaleToWidth
    pdf.addImage(
      sliceCanvas.toDataURL('image/png', 1),
      'PNG',
      PDF_MARGIN_PX,
      PDF_MARGIN_PX,
      availableWidth,
      renderedHeight
    )

    offsetY += sliceHeight
    isFirstPage = false
  }

  pdf.save(`${filename}.pdf`)
}

/**
 * Downloads a text file (Mermaid, Draw.io, PlantUML, SQL, JSON, etc.)
 */
export function downloadTextFile(content: string, filename: string, mimeType = 'text/plain') {
  const blob = new Blob([content], { type: mimeType })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

/**
 * Converts Business Flow or Architecture nodes and edges to Mermaid syntax
 */
export function convertToMermaid(
  nodes: (FlowNode | ArchNode)[],
  edges: (FlowEdge | ArchEdge)[],
  title = 'Design Diagram'
): string {
  let mermaidStr = `---
title: ${title}
---
graph TD
`
  nodes.forEach(n => {
    const label = 'data' in n && n.data?.label ? n.data.label : n.id
    const safeLabel = label.replace(/["\(\)\[\]]/g, '')
    mermaidStr += `  ${n.id}["${safeLabel}"]\n`
  })

  edges.forEach(e => {
    const labelStr = e.label ? `|"${e.label}"|` : ''
    mermaidStr += `  ${e.source} -->${labelStr} ${e.target}\n`
  })

  return mermaidStr
}

/**
 * Converts Database Entities to Mermaid ER Diagram
 */
export function convertDBToMermaid(entities: DBEntity[]): string {
  let syntax = 'erDiagram\n'
  entities.forEach(ent => {
    const safeName = ent.name.replace(/\s+/g, '')
    syntax += `    ${safeName} {\n`
    ent.fields.forEach(f => {
      const typeStr = f.type.replace(/[\(\),]/g, '_')
      const pkfk = f.pk ? 'PK' : f.fk ? 'FK' : ''
      syntax += `        ${typeStr} ${f.name} ${pkfk}\n`
    })
    syntax += '    }\n'
  })

  entities.forEach(ent => {
    const safeName = ent.name.replace(/\s+/g, '')
    ent.fields.forEach((f: DBField) => {
      if (typeof f.fk === 'string') {
        const parts = f.fk.split('.')
        if (parts.length >= 2) {
          const targetTable = parts[0].replace(/\s+/g, '')
          syntax += `    ${safeName} }o--|| ${targetTable} : "references"\n`
        }
      }
    })
  })
  return syntax
}

/**
 * Converts nodes and edges to Draw.io XML format
 */
export function convertToDrawIO(
  nodes: (FlowNode | ArchNode)[],
  edges: (FlowEdge | ArchEdge)[],
  title = 'Design Diagram'
): string {
  let xml = `<mxfile host="Electron" modified="${new Date().toISOString()}" agent="AI Solution Architect" version="21.0.0" type="device">
  <diagram id="diagram-1" name="${title}">
    <mxGraphModel dx="1000" dy="800" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="850" pageHeight="1100" math="0" shadow="0">
      <root>
        <mxCell id="0" />
        <mxCell id="1" parent="0" />
`
  nodes.forEach(n => {
    const label = 'data' in n && n.data?.label ? n.data.label : n.id
    const x = n.position?.x || 100
    const y = n.position?.y || 100
    xml += `        <mxCell id="${n.id}" value="${label}" style="rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;" vertex="1" parent="1">
          <mxGeometry x="${x}" y="${y}" width="140" height="50" as="geometry" />
        </mxCell>\n`
  })

  edges.forEach((e, idx) => {
    xml += `        <mxCell id="edge-${idx}" value="${e.label || ''}" style="edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;" edge="1" parent="1" source="${e.source}" target="${e.target}">
          <mxGeometry relative="1" as="geometry" />
        </mxCell>\n`
  })

  xml += `      </root>
    </mxGraphModel>
  </diagram>
</mxfile>`

  return xml
}

/**
 * Converts nodes and edges to PlantUML format
 */
export function convertToPlantUML(
  nodes: (FlowNode | ArchNode)[],
  edges: (FlowEdge | ArchEdge)[],
  title = 'Design Diagram'
): string {
  let puml = `@startuml
title ${title}
skinparam componentStyle uml2

`
  nodes.forEach(n => {
    const label = 'data' in n && n.data?.label ? n.data.label : n.id
    puml += `component [${label}] as ${n.id}\n`
  })

  puml += '\n'
  edges.forEach(e => {
    const labelStr = e.label ? ` : ${e.label}` : ''
    puml += `${e.source} --> ${e.target}${labelStr}\n`
  })

  puml += '@enduml\n'
  return puml
}

/**
 * Converts Database Entities to SQL DDL script
 */
export function convertDBToSQL(entities: DBEntity[]): string {
  let sql = `-- Generated SQL DDL Script by AI Solution Architect\n-- Created At: ${new Date().toISOString()}\n\n`
  entities.forEach(ent => {
    const tableName = ent.name.toLowerCase().replace(/\s+/g, '_')
    sql += `CREATE TABLE ${tableName} (\n`
    const fieldDefs = ent.fields.map(f => {
      const fieldName = f.name.toLowerCase().replace(/\s+/g, '_')
      let def = `  ${fieldName} ${f.type.toUpperCase()}`
      if (f.pk) def += ' PRIMARY KEY'
      if (!f.nullable && !f.pk) def += ' NOT NULL'
      return def
    })
    sql += fieldDefs.join(',\n')
    sql += `\n);\n\n`
  })
  return sql
}

/**
 * Master Artifact Exporter
 */
export async function exportArtifactElement(
  containerElementId: string,
  format: ExportFormat,
  filename: string,
  data?: {
    nodes?: (FlowNode | ArchNode)[]
    edges?: (FlowEdge | ArchEdge)[]
    entities?: DBEntity[]
    title?: string
  }
) {
  const safeTitle = data?.title || filename

  if (format === 'Mermaid') {
    const content = data?.entities
      ? convertDBToMermaid(data.entities)
      : convertToMermaid(data?.nodes || [], data?.edges || [], safeTitle)
    downloadTextFile(content, `${filename}.mermaid`, 'text/plain')
    return
  }

  if (format === 'Draw.io') {
    const content = convertToDrawIO(data?.nodes || [], data?.edges || [], safeTitle)
    downloadTextFile(content, `${filename}.drawio`, 'application/xml')
    return
  }

  if (format === 'PlantUML') {
    const content = convertToPlantUML(data?.nodes || [], data?.edges || [], safeTitle)
    downloadTextFile(content, `${filename}.puml`, 'text/plain')
    return
  }

  if (format === 'SQL') {
    const content = convertDBToSQL(data?.entities || [])
    downloadTextFile(content, `${filename}.sql`, 'text/sql')
    return
  }

  if (format === 'JSON') {
    const content = JSON.stringify(data || {}, null, 2)
    downloadTextFile(content, `${filename}.json`, 'application/json')
    return
  }

  // DOM Canvas Export (PNG, SVG, PDF)
  const el = document.getElementById(containerElementId) || document.querySelector('.react-flow') as HTMLElement
  if (!el) {
    throw new Error(`DOM Element with ID '${containerElementId}' not found for image rendering.`)
  }

  const exportRoot = (el.querySelector('[data-export-root="solution-architecture"]') as HTMLElement | null) || el
  const { width: exportWidth, height: exportHeight } = getElementExportBounds(exportRoot)
  const imageOptions = {
    cacheBust: true,
    backgroundColor: '#f8fafc',
    pixelRatio: 2,
    width: exportWidth,
    height: exportHeight,
  }

  if (format === 'PNG') {
    const dataUrl = await toPng(exportRoot, { ...imageOptions, quality: 0.95 })
    const a = document.createElement('a')
    a.href = dataUrl
    a.download = `${filename}.png`
    a.click()
    return
  }

  if (format === 'SVG') {
    const dataUrl = await toSvg(exportRoot, imageOptions)
    const a = document.createElement('a')
    a.href = dataUrl
    a.download = `${filename}.svg`
    a.click()
    return
  }

  if (format === 'PDF') {
    const dataUrl = await toPng(exportRoot, { ...imageOptions, quality: 0.95 })
    await exportPngToPdf(dataUrl, exportWidth || 1600, exportHeight || 900, filename)
    return
  }
}

/**
 * Compiles and exports the complete project solution package as a bundled JSON/ZIP payload
 */
export function exportProjectZipPackage(projectData: any, filename: string) {
  const payload = JSON.stringify(projectData, null, 2)
  downloadTextFile(payload, `${filename}_Full_Package.json`, 'application/json')
}
