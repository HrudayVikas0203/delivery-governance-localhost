import type { AiConfig } from '../data/aiConfig'
import { monitoring } from './monitoringService'

export interface LLMRequestOptions {
  prompt: string
  systemPrompt?: string
  model?: string
  responseFormat?: 'JSON Object' | 'Markdown' | 'Structured Text' | 'Raw Text'
  history?: { role: 'user' | 'assistant'; content: string }[]
}

/**
 * Universal Provider-Aware LLM Client Dispatcher
 * Routes requests to OpenAI, Anthropic Claude, Google Gemini, xAI Grok, Ollama, Custom Endpoint, or Azure OpenAI
 */
export async function callConfiguredLLM(
  options: LLMRequestOptions,
  aiConfig: AiConfig
): Promise<string> {
  const provider = (aiConfig.provider || 'OpenAI').trim()
  const apiKey = (aiConfig.apiKey || '').trim()
  const model = options.model || aiConfig.defaultModel || 'gpt-4o'
  const systemPrompt = options.systemPrompt || 'You are an Enterprise Solution Architect.'

  // Requirement 6: Check if provider or API key is unconfigured
  const needsApiKey = provider !== 'Ollama'
  if (needsApiKey && (!apiKey || apiKey.includes('••••'))) {
    const msg = `AI Provider '${provider}' is not configured with a valid API key. Please navigate to Settings -> AI Configuration to set your API key.`
    monitoring.log('WARN', 'AI', msg, 0, { provider, model })
    throw new Error(msg)
  }

  const startTime = Date.now()

  try {
    let resultText = ''

    if (provider === 'Anthropic Claude') {
      resultText = await callAnthropicClaude(options, apiKey, model, systemPrompt, aiConfig)
    } else if (provider === 'Google Gemini') {
      resultText = await callGoogleGemini(options, apiKey, model, systemPrompt, aiConfig)
    } else if (provider === 'xAI Grok') {
      resultText = await callOpenAICompatible(
        options,
        apiKey,
        model,
        systemPrompt,
        aiConfig,
        aiConfig.endpointUrl || 'https://api.x.ai/v1/chat/completions'
      )
    } else if (provider === 'Azure OpenAI') {
      resultText = await callAzureOpenAI(options, apiKey, model, systemPrompt, aiConfig)
    } else if (provider === 'Ollama') {
      resultText = await callOpenAICompatible(
        options,
        apiKey,
        model,
        systemPrompt,
        aiConfig,
        aiConfig.endpointUrl || 'http://localhost:11434/v1/chat/completions'
      )
    } else {
      // Default: OpenAI or Custom Endpoint
      const endpoint = aiConfig.endpointUrl || 'https://api.openai.com/v1/chat/completions'
      resultText = await callOpenAICompatible(options, apiKey, model, systemPrompt, aiConfig, endpoint)
    }

    const latencyMs = Date.now() - startTime
    monitoring.log('INFO', 'AI', `LLM call completed via provider '${provider}' [model: ${model}] in ${latencyMs}ms`, latencyMs)

    return resultText
  } catch (err: any) {
    const latencyMs = Date.now() - startTime
    monitoring.log('ERROR', 'AI', `LLM call failed for provider '${provider}': ${err.message}`, latencyMs)
    throw err
  }
}

/**
 * OpenAI / xAI Grok / Ollama / Custom API Handler
 */
async function callOpenAICompatible(
  options: LLMRequestOptions,
  apiKey: string,
  model: string,
  systemPrompt: string,
  aiConfig: AiConfig,
  endpoint: string
): Promise<string> {
  const messages = [
    { role: 'system', content: systemPrompt },
    ...(options.history || []),
    { role: 'user', content: options.prompt }
  ]

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  }
  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`
  }

  const payload: any = {
    model,
    messages,
    temperature: aiConfig.temperature ?? 0.7,
    max_tokens: aiConfig.maxTokens ?? 4096,
  }

  if (options.responseFormat === 'JSON Object' || aiConfig.responseFormat === 'JSON Object') {
    payload.response_format = { type: 'json_object' }
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    const errText = await response.text().catch(() => '')
    throw new Error(`${aiConfig.provider} API Error (${response.status}): ${errText || response.statusText}`)
  }

  const data = await response.json()
  const content = data.choices?.[0]?.message?.content
  if (!content) throw new Error(`${aiConfig.provider} API returned empty content.`)
  return content
}

/**
 * Anthropic Claude API Handler (v1/messages)
 */
async function callAnthropicClaude(
  options: LLMRequestOptions,
  apiKey: string,
  model: string,
  systemPrompt: string,
  aiConfig: AiConfig
): Promise<string> {
  const endpoint = aiConfig.endpointUrl || 'https://api.anthropic.com/v1/messages'

  const messages = [
    ...(options.history || []).map(h => ({ role: h.role === 'user' ? 'user' : 'assistant', content: h.content })),
    { role: 'user', content: options.prompt }
  ]

  const payload = {
    model,
    max_tokens: aiConfig.maxTokens || 4096,
    system: systemPrompt,
    messages,
    temperature: aiConfig.temperature ?? 0.7,
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    const errText = await response.text().catch(() => '')
    throw new Error(`Anthropic Claude API Error (${response.status}): ${errText || response.statusText}`)
  }

  const data = await response.json()
  const text = data.content?.[0]?.text
  if (!text) throw new Error('Anthropic Claude API returned empty response.')
  return text
}

/**
 * Google Gemini API Handler (generativelanguage.googleapis.com)
 */
async function callGoogleGemini(
  options: LLMRequestOptions,
  apiKey: string,
  model: string,
  systemPrompt: string,
  aiConfig: AiConfig
): Promise<string> {
  const modelName = model || 'gemini-1.5-pro'
  const endpoint = aiConfig.endpointUrl || `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`

  const contents = [
    {
      parts: [
        { text: `${systemPrompt}\n\nUser Prompt:\n${options.prompt}` }
      ]
    }
  ]

  const payload: any = {
    contents,
    generationConfig: {
      temperature: aiConfig.temperature ?? 0.7,
      maxOutputTokens: aiConfig.maxTokens ?? 4096,
    }
  }

  if (options.responseFormat === 'JSON Object' || aiConfig.responseFormat === 'JSON Object') {
    payload.generationConfig.responseMimeType = 'application/json'
  }

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    const errText = await response.text().catch(() => '')
    throw new Error(`Google Gemini API Error (${response.status}): ${errText || response.statusText}`)
  }

  const data = await response.json()
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text
  if (!text) throw new Error('Google Gemini API returned empty response.')
  return text
}

/**
 * Azure OpenAI API Handler
 */
async function callAzureOpenAI(
  options: LLMRequestOptions,
  apiKey: string,
  model: string,
  systemPrompt: string,
  aiConfig: AiConfig
): Promise<string> {
  const baseUrl = aiConfig.endpointUrl?.replace(/\/$/, '') || 'https://acme-openai.openai.azure.com'
  const endpoint = `${baseUrl}/openai/deployments/${model}/chat/completions?api-version=2024-02-01`

  const messages = [
    { role: 'system', content: systemPrompt },
    ...(options.history || []),
    { role: 'user', content: options.prompt }
  ]

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'api-key': apiKey,
    },
    body: JSON.stringify({
      messages,
      temperature: aiConfig.temperature ?? 0.7,
      max_tokens: aiConfig.maxTokens ?? 4096,
    })
  })

  if (!response.ok) {
    const errText = await response.text().catch(() => '')
    throw new Error(`Azure OpenAI API Error (${response.status}): ${errText || response.statusText}`)
  }

  const data = await response.json()
  const content = data.choices?.[0]?.message?.content
  if (!content) throw new Error('Azure OpenAI API returned empty content.')
  return content
}
