import {
  saveBackup,
  getAllBackups,
  getAllPromptTemplates,
  savePromptTemplate,
  getAllNotifications,
  saveDocumentRecord,
  saveRequirementsRecord,
  saveBusinessFlowRecord,
  saveArchitectureRecord,
  type BackupRecord,
} from './db'
import { downloadTextFile } from './exportService'

export async function createSystemBackup(description = 'Manual System Backup'): Promise<BackupRecord> {
  const promptTemplates = await getAllPromptTemplates()
  const notifications = await getAllNotifications()

  const backupData = {
    version: '5.0',
    timestamp: new Date().toISOString(),
    description,
    promptTemplates,
    notifications,
  }

  const jsonStr = JSON.stringify(backupData, null, 2)
  const sizeKb = (jsonStr.length / 1024).toFixed(1)

  const record: BackupRecord = {
    id: `backup-${Date.now()}`,
    timestamp: new Date().toISOString(),
    description,
    dataJson: jsonStr,
    sizeStr: `${sizeKb} KB`,
  }

  await saveBackup(record)
  return record
}

export function downloadBackupFile(backup: BackupRecord): void {
  const filename = `AI_Solution_Architect_Backup_${backup.timestamp.replace(/[:.]/g, '-')}.json`
  downloadTextFile(backup.dataJson, filename, 'application/json')
}

export async function restoreFromBackupJson(jsonString: string): Promise<boolean> {
  try {
    const data = JSON.parse(jsonString)
    if (!data.timestamp || !data.version) {
      throw new Error('Invalid backup file format: missing version header.')
    }
    // Restore prompt templates
    if (data.promptTemplates && Array.isArray(data.promptTemplates)) {
      for (const tmpl of data.promptTemplates) {
        await savePromptTemplate(tmpl)
      }
    }
    return true
  } catch (e) {
    console.error('Backup restoration failed:', e)
    throw e
  }
}

export { getAllBackups }
