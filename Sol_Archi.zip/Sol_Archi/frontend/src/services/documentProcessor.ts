import type { AiConfig } from '../data/aiConfig'
import { backendApi } from './backendApi'
import {
  saveDocumentRecord,
  saveRequirementVersion,
  saveRequirementsRecord,
  type ExtractedRequirementsRecord,
  type RequirementVersionRecord,
  type StoredDocument,
} from './db'
import {
  logProcessingCompleted,
  logProcessingFailed,
  logProcessingStarted,
} from './auditLogger'

export interface ProgressStep {
  id: string
  label: string
  status: 'pending' | 'in_progress' | 'completed' | 'failed'
}

export type ProgressCallback = (steps: ProgressStep[], currentStepIndex: number) => void

const INITIAL_STEPS: ProgressStep[] = [
  { id: '1', label: 'Uploading document to backend', status: 'pending' },
  { id: '2', label: 'Parsing document on backend', status: 'pending' },
  { id: '3', label: 'Generating requirements with configured AI provider', status: 'pending' },
  { id: '4', label: 'Saving extracted requirements', status: 'pending' },
]

export async function processDocumentJob(
  file: File,
  docId: string,
  projectId: string,
  aiConfig: AiConfig,
  onProgress?: ProgressCallback,
): Promise<ExtractedRequirementsRecord> {
  const steps = JSON.parse(JSON.stringify(INITIAL_STEPS)) as ProgressStep[]

  const updateStep = (index: number, status: ProgressStep['status']) => {
    steps[index].status = status
    onProgress?.([...steps], index)
  }

  try {
    updateStep(0, 'in_progress')
    await logProcessingStarted(projectId, docId, file.name)
    updateStep(0, 'completed')

    updateStep(1, 'in_progress')
    const documents = await backendApi.listProjectDocuments(projectId)
    const uploadedDocument = documents.find((item) => item.id === docId)
    if (!uploadedDocument) {
      throw new Error('Upload failed: backend did not return the new document')
    }
    await saveDocumentRecord(uploadedDocument as StoredDocument)
    updateStep(1, 'completed')

    updateStep(2, 'in_progress')
    const requirementsRecord = await backendApi.generateRequirements(projectId, docId, aiConfig)
    updateStep(2, 'completed')

    updateStep(3, 'in_progress')
    await saveRequirementsRecord(requirementsRecord)
    const versionSnapshot: RequirementVersionRecord = {
      id: `ver-${docId}-v${requirementsRecord.version}`,
      docId,
      projectId,
      version: requirementsRecord.version,
      timestamp: requirementsRecord.updatedAt,
      author: `AI Engine (${requirementsRecord.generatorModel || aiConfig.defaultModel})`,
      changeType: requirementsRecord.version > 1 ? 'Regenerated' : 'AI_Extracted',
      changeSummary: requirementsRecord.version > 1
        ? `Requirements regenerated for '${file.name}'`
        : `Initial AI requirement extraction from '${file.name}'`,
      requirementsSnapshot: requirementsRecord,
    }
    await saveRequirementVersion(versionSnapshot)
    updateStep(3, 'completed')

    const totalReqs = requirementsRecord.functional.length + requirementsRecord.nonFunctional.length
    await logProcessingCompleted(projectId, docId, totalReqs, uploadedDocument.confidence)

    return requirementsRecord
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Document processing failed'
    await logProcessingFailed(projectId, docId, message)
    const activeIndex = steps.findIndex((step) => step.status === 'in_progress')
    if (activeIndex !== -1) {
      updateStep(activeIndex, 'failed')
    }
    throw error
  }
}
