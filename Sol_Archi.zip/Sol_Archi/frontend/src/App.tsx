import { Suspense, lazy } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { Toaster } from 'sonner'
import ProtectedRoute from '@/components/auth/ProtectedRoute'
import AppLayout from '@/components/layout/AppLayout'
import { AppErrorBoundary } from '@/components/errors/AppErrorBoundary'
import { APP_ROUTES } from '@/config/routes'
import { AppProvider } from '@/context/AppContext'
import { AuthProvider } from '@/context/AuthContext'
import { DocumentProvider } from '@/context/DocumentContext'
import { NotificationProvider } from '@/context/NotificationContext'
import { useAuth } from '@/context/AuthContext'

const Dashboard = lazy(() => import('@/pages/Dashboard'))
const UploadCenter = lazy(() => import('@/pages/UploadCenter'))
const Requirements = lazy(() => import('@/pages/Requirements'))
const BusinessFlow = lazy(() => import('@/pages/BusinessFlow'))
const SolutionArchitecture = lazy(() => import('@/pages/SolutionArchitecture'))
const AiChat = lazy(() => import('@/pages/AiChat'))
const ExportCenter = lazy(() => import('@/pages/ExportCenter'))
const SettingsPage = lazy(() => import('@/pages/Settings'))
const SignIn = lazy(() => import('@/pages/SignIn'))
const AccessDenied = lazy(() => import('@/pages/AccessDenied'))
const UserManagement = lazy(() => import('@/pages/UserManagement'))

function AppShellFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
      <div className="text-sm font-medium text-muted-foreground">Loading workspace...</div>
    </div>
  )
}

function UnknownRouteRedirect() {
  const { isAuthenticated } = useAuth()
  return <Navigate to={isAuthenticated ? APP_ROUTES.dashboard : APP_ROUTES.signIn} replace />
}

export default function App() {
  return (
    <AppProvider>
      <DocumentProvider>
        <NotificationProvider>
          <AuthProvider>
            <BrowserRouter>
              <AppErrorBoundary>
                <Suspense fallback={<AppShellFallback />}>
                  <Routes>
                    <Route path={APP_ROUTES.signIn} element={<SignIn />} />

                    <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
                      <Route path={APP_ROUTES.dashboard} element={<Dashboard />} />
                      <Route path={APP_ROUTES.upload} element={<UploadCenter />} />
                      <Route path={APP_ROUTES.requirements} element={<Requirements />} />
                      <Route path={APP_ROUTES.businessFlow} element={<BusinessFlow />} />
                      <Route path={APP_ROUTES.architecture} element={<SolutionArchitecture />} />
                      <Route path={APP_ROUTES.aiChat} element={<AiChat />} />
                      <Route path={APP_ROUTES.export} element={<ExportCenter />} />
                      <Route path={APP_ROUTES.settings} element={<SettingsPage />} />
                      <Route path={APP_ROUTES.userManagement} element={<UserManagement />} />
                      <Route path={APP_ROUTES.accessDenied} element={<AccessDenied />} />
                    </Route>

                    <Route path="*" element={<UnknownRouteRedirect />} />
                  </Routes>
                </Suspense>
              </AppErrorBoundary>
            </BrowserRouter>
            <Toaster
              position="top-right"
              toastOptions={{
                style: {
                  background: 'var(--color-card)',
                  color: 'var(--color-foreground)',
                  border: '1px solid var(--color-border)',
                },
              }}
            />
          </AuthProvider>
        </NotificationProvider>
      </DocumentProvider>
    </AppProvider>
  )
}
