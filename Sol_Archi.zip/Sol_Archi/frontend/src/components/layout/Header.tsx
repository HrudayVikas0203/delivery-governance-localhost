import { useState, useEffect, useRef } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { APP_ROUTES, PAGE_TITLES } from '@/config/routes'
import { useApp } from '@/context/AppContext'
import { cn } from '@/lib/utils'
import { useAuth } from '@/context/AuthContext'
import { useDocuments } from '@/context/DocumentContext'
import {
  Search,
  Bell,
  Sun,
  Moon,
  Menu,
  X,
  ChevronRight,
  FileText,
  User,
  Cpu,
  Database,
  Settings,
  LogOut,
} from 'lucide-react'
import { toast } from 'sonner'
import { executeGlobalSearch } from '@/services/globalSearchService'

const searchableItems = [
  { label: 'Dashboard', path: APP_ROUTES.dashboard, icon: FileText, category: 'Pages' },
  { label: 'Upload Document', path: APP_ROUTES.upload, icon: FileText, category: 'Pages' },
  { label: 'Requirements', path: APP_ROUTES.requirements, icon: FileText, category: 'Pages' },
  { label: 'Business Flow', path: APP_ROUTES.businessFlow, icon: FileText, category: 'Pages' },
  { label: 'Solution Architecture', path: APP_ROUTES.architecture, icon: Cpu, category: 'Pages' },
  { label: 'AI Chat', path: APP_ROUTES.aiChat, icon: FileText, category: 'Pages' },
  { label: 'Export Center', path: APP_ROUTES.export, icon: FileText, category: 'Pages' },
  { label: 'Settings', path: APP_ROUTES.settings, icon: Settings, category: 'Pages' },
  { label: 'Employee Profile Management', path: APP_ROUTES.requirements, icon: User, category: 'Requirements' },
  { label: 'Goal Setting & OKR Management', path: APP_ROUTES.requirements, icon: User, category: 'Requirements' },
  { label: 'Performance Reviews', path: APP_ROUTES.requirements, icon: User, category: 'Requirements' },
  { label: 'Leave & Attendance', path: APP_ROUTES.requirements, icon: User, category: 'Requirements' },
  { label: 'Employee Service', path: APP_ROUTES.architecture, icon: Cpu, category: 'Architecture' },
  { label: 'API Gateway', path: APP_ROUTES.architecture, icon: Cpu, category: 'Architecture' },
  { label: 'Redis Cache', path: APP_ROUTES.architecture, icon: Cpu, category: 'Architecture' },
]

export default function Header() {
  const { state, setTheme, toggleSidebar } = useApp()
  const { currentUser, logout } = useAuth()
  const { resetContext, activeProjectId } = useDocuments()
  const navigate = useNavigate()
  const location = useLocation()
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [notifOpen, setNotifOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [searchResults, setSearchResults] = useState<{ id: string; title: string; subtitle: string; path: string }[]>([])
  const searchRef = useRef<HTMLDivElement>(null)
  const notifRef = useRef<HTMLDivElement>(null)
  const profileRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setSearchOpen(false)
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotifOpen(false)
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    const runSearch = async () => {
      try {
        const liveResults = await executeGlobalSearch(activeProjectId, searchQuery)
        setSearchResults(liveResults)
      } catch (error) {
        console.warn('Global search unavailable', error)
        setSearchResults([])
      }
    }

    void runSearch()
  }, [searchQuery, activeProjectId])

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
        event.preventDefault()
        setSearchOpen(true)
      }
      if (event.key === 'Escape') {
        setSearchOpen(false)
        setNotifOpen(false)
      }
    }

    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [])

  const handleLogout = () => {
    setProfileOpen(false)
    logout()
    resetContext()
    navigate(APP_ROUTES.signIn, { replace: true })
    toast.success('Successfully logged out')
  }

  const unreadCount = state.notifications.filter((notification) => !notification.read).length
  const pageTitle = PAGE_TITLES[location.pathname as keyof typeof PAGE_TITLES] || 'Dashboard'

  const filteredItems = searchQuery.trim()
    ? [
        ...searchResults,
        ...searchableItems
          .filter((item) => item.label.toLowerCase().includes(searchQuery.toLowerCase()) || item.category.toLowerCase().includes(searchQuery.toLowerCase()))
          .map((item) => ({ id: item.label, title: item.label, subtitle: item.category, path: item.path })),
      ]
    : []

  return (
    <header className="sticky top-0 z-30 h-16 bg-card/80 backdrop-blur-xl border-b border-border flex items-center justify-between px-6">
      <div className="flex items-center gap-4">
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-lg hover:bg-muted transition-colors lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">AI Copilot</span>
          <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/50" />
          <span className="font-semibold">{pageTitle}</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div ref={searchRef} className="relative">
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-muted/50 hover:bg-muted transition-colors text-sm text-muted-foreground"
          >
            <Search className="w-4 h-4" />
            <span className="hidden md:inline">Search...</span>
            <kbd className="hidden md:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono bg-background rounded border border-border ml-4">
              Ctrl+K
            </kbd>
          </button>

          {searchOpen && (
            <div className="absolute right-0 top-full mt-2 w-[420px] bg-card rounded-xl border border-border shadow-2xl overflow-hidden animate-scale-in">
              <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
                <Search className="w-4 h-4 text-muted-foreground" />
                <input
                  autoFocus
                  value={searchQuery}
                  onChange={(event) => setSearchQuery(event.target.value)}
                  placeholder="Search requirements, APIs, components..."
                  className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                />
                <button onClick={() => setSearchOpen(false)}>
                  <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                </button>
              </div>
              <div className="max-h-80 overflow-y-auto p-2">
                {searchQuery.trim() === '' ? (
                  <p className="text-xs text-muted-foreground text-center py-8">Type to search across all artifacts</p>
                ) : filteredItems.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-8">No results found</p>
                ) : (
                  filteredItems.map((item, index) => (
                    <button
                      key={`${item.id}-${index}`}
                      onClick={() => {
                        navigate(item.path)
                        setSearchOpen(false)
                        setSearchQuery('')
                      }}
                      className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg hover:bg-muted transition-colors text-left"
                    >
                      <Search className="w-4 h-4 text-muted-foreground" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{item.title}</p>
                        <p className="text-[11px] text-muted-foreground">{item.subtitle}</p>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        <button
          onClick={() => setTheme(state.theme === 'dark' ? 'light' : 'dark')}
          className="p-2.5 rounded-lg hover:bg-muted transition-colors"
        >
          {state.theme === 'dark' ? <Sun className="w-[18px] h-[18px]" /> : <Moon className="w-[18px] h-[18px]" />}
        </button>

        <div ref={notifRef} className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative p-2.5 rounded-lg hover:bg-muted transition-colors"
          >
            <Bell className="w-[18px] h-[18px]" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 flex items-center justify-center text-[9px] font-bold bg-primary text-primary-foreground rounded-full">
                {unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <div className="absolute right-0 top-full mt-2 w-[360px] bg-card rounded-xl border border-border shadow-2xl overflow-hidden animate-scale-in">
              <div className="px-4 py-3 border-b border-border flex items-center justify-between">
                <h3 className="text-sm font-semibold">Notifications</h3>
                <span className="text-[11px] text-primary cursor-pointer hover:underline">Mark all read</span>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {state.notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={cn(
                      'px-4 py-3 border-b border-border/50 hover:bg-muted/50 transition-colors cursor-pointer',
                      !notification.read && 'bg-primary/5',
                    )}
                  >
                    <div className="flex items-start gap-3">
                      {!notification.read && <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />}
                      <div className={cn('flex-1 min-w-0', notification.read && 'ml-5')}>
                        <p className="text-sm font-medium">{notification.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{notification.message}</p>
                        <p className="text-[10px] text-muted-foreground/60 mt-1">
                          {notification.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {currentUser && (
          <div className="flex items-center gap-2.5 ml-2 pl-2 border-l border-border">
            <div className="text-right hidden md:block select-none">
              <p className="text-xs font-bold text-foreground leading-tight">{currentUser.name}</p>
              <p className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider mt-0.5">{currentUser.role}</p>
            </div>
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white text-xs font-bold shadow hover:opacity-90 transition-opacity"
              >
                {currentUser.name.split(' ').map((name) => name[0]).join('')}
              </button>
              {profileOpen && (
                <div className="absolute right-0 top-full mt-2 w-52 bg-card border border-border rounded-xl shadow-2xl p-2 z-50 animate-scale-in">
                  <div className="px-2.5 py-2 border-b border-border/80 mb-1.5 text-left">
                    <p className="text-xs font-bold text-foreground truncate">{currentUser.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{currentUser.email}</p>
                    <span className="inline-block mt-1.5 px-2 py-0.5 text-[9px] font-bold bg-primary/10 text-primary rounded-md border border-primary/20">
                      {currentUser.role}
                    </span>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 w-full text-left px-2.5 py-2 rounded-lg text-xs font-semibold text-red-500 hover:bg-red-500/10 transition-colors"
                  >
                    <LogOut className="w-3.5 h-3.5" /> Sign Out
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
