import { Outlet } from 'react-router-dom'
import { useApp } from '@/context/AppContext'
import { cn } from '@/lib/utils'
import Sidebar from './Sidebar'
import Header from './Header'

export default function AppLayout() {
  const { state } = useApp()

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <div
        className={cn(
          'transition-all duration-300 ease-in-out',
          state.sidebarCollapsed ? 'ml-[68px]' : 'ml-[260px]'
        )}
      >
        <Header />
        <main className="p-6 pb-24 max-w-7xl mx-auto w-full min-h-[calc(100vh-64px)] overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
