import { useState, useMemo } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { APP_ROUTES } from '@/config/routes'
import { useApp } from '@/context/AppContext'
import { useDocuments } from '@/context/DocumentContext'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Upload,
  FileText,
  GitBranch,
  Cpu,
  MessageSquare,
  Download,
  Settings,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Zap,
  FolderGit,
  ChevronDown,
  Check,
  Plus,
  X,
  Users
} from 'lucide-react'
import { toast } from 'sonner'
import { useAuth } from '@/context/AuthContext'

const navItems = [
  { path: APP_ROUTES.dashboard, label: 'Dashboard', icon: LayoutDashboard },
  { path: APP_ROUTES.upload, label: 'Upload Document', icon: Upload },
  { path: APP_ROUTES.requirements, label: 'Requirements', icon: FileText },
  { path: APP_ROUTES.businessFlow, label: 'Business Flow', icon: GitBranch },
  { path: APP_ROUTES.architecture, label: 'Solution Architecture', icon: Cpu },
  { path: APP_ROUTES.aiChat, label: 'AI Chat', icon: MessageSquare },
  { path: APP_ROUTES.export, label: 'Export Center', icon: Download },
  { path: APP_ROUTES.settings, label: 'Settings', icon: Settings },
]

export default function Sidebar() {
  const { state, toggleSidebar } = useApp()
  const { 
    projects, 
    activeProjectId, 
    activeProject, 
    selectProject, 
    createProject
  } = useDocuments()
  const { currentUser, hasPermission } = useAuth()
  const location = useLocation()
  const collapsed = state.sidebarCollapsed

  const filteredNavItems = useMemo(() => {
    const items = [
      ...navItems,
      { path: APP_ROUTES.userManagement, label: 'User Directory', icon: Users }
    ]
    return items.filter(item => hasPermission(item.path))
  }, [hasPermission])

  // Dropdown & Modal state
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [showModal, setShowModal] = useState(false)

  // Form states for new project
  const [newProjName, setNewProjName] = useState('')
  const [newProjDesc, setNewProjDesc] = useState('')

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newProjName.trim()) {
      toast.error('Project Name is required')
      return
    }

    createProject(newProjName, newProjDesc, [])
    toast.success(`Project "${newProjName}" created successfully!`)
    
    // Reset Form
    setNewProjName('')
    setNewProjDesc('')
    setShowModal(false)
  }

  return (
    <>
      <aside
        className={cn(
          'fixed left-0 top-0 z-40 h-screen flex flex-col transition-all duration-300 ease-in-out',
          'bg-sidebar text-sidebar-foreground border-r border-sidebar-border',
          collapsed ? 'w-[68px]' : 'w-[260px]'
        )}
      >
        {/* Logo */}
        <div className={cn(
          'flex items-center h-16 px-4 border-b border-sidebar-border',
          collapsed ? 'justify-center' : 'gap-3'
        )}>
          <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary/20">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          {!collapsed && (
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-bold text-white truncate">AI Solution Architect</span>
              <span className="text-[10px] text-sidebar-foreground/60 flex items-center gap-1">
                <Zap className="w-2.5 h-2.5" />
                Copilot
              </span>
            </div>
          )}
        </div>

        {/* Projects Section */}
        <div className="px-3 py-3 border-b border-sidebar-border">
          {collapsed ? (
            <div className="flex justify-center relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className={cn(
                  "w-9 h-9 rounded-lg flex items-center justify-center hover:bg-sidebar-accent transition-colors relative",
                  dropdownOpen ? "bg-primary/20 text-primary" : "bg-sidebar-accent text-sidebar-foreground/70"
                )}
                title={activeProject.name}
              >
                <FolderGit className="w-5 h-5" />
              </button>
              
              {dropdownOpen && (
                <div className="absolute left-full ml-2 top-0 w-56 bg-sidebar-accent border border-sidebar-border rounded-lg shadow-xl py-1 z-50 animate-scale-in">
                  <div className="px-3 py-1.5 text-[10px] font-bold text-sidebar-foreground/40 uppercase border-b border-sidebar-border/40">Projects</div>
                  <div className="max-h-48 overflow-y-auto">
                    {projects.map((proj) => (
                      <button
                        key={proj.id}
                        onClick={() => {
                          selectProject(proj.id)
                          setDropdownOpen(false)
                        }}
                        className={cn(
                          "flex items-center justify-between w-full px-3 py-2 text-left text-xs hover:bg-sidebar/50 transition-colors text-sidebar-foreground hover:text-white",
                          proj.id === activeProjectId && "bg-primary/10 text-primary font-semibold"
                        )}
                      >
                        <span className="truncate pr-2">{proj.name}</span>
                        {proj.id === activeProjectId && <Check className="w-3 h-3 text-primary flex-shrink-0" />}
                      </button>
                    ))}
                  </div>
                  {currentUser?.role !== 'Delivery Manager' && (
                    <div className="border-t border-sidebar-border/40 mt-1 pt-1 px-1">
                      <button
                        onClick={() => {
                          setShowModal(true)
                          setDropdownOpen(false)
                        }}
                        className="flex items-center gap-1.5 w-full px-2 py-1.5 rounded text-[10px] font-semibold text-primary hover:bg-primary/10 transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" /> New Project
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="relative">
              <label className="text-[10px] font-semibold text-sidebar-foreground/40 uppercase tracking-wider block mb-1">Active Project</label>
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-sidebar-accent border border-sidebar-border hover:border-primary/40 text-left text-xs text-white font-medium transition-all"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <FolderGit className="w-4 h-4 text-primary flex-shrink-0" />
                  <span className="truncate">{activeProject.name}</span>
                </div>
                <ChevronDown className={cn("w-3 h-3 text-sidebar-foreground/60 transition-transform flex-shrink-0", dropdownOpen && "rotate-180")} />
              </button>
              
              {dropdownOpen && (
                <div className="absolute left-0 right-0 top-full mt-1.5 bg-sidebar-accent border border-sidebar-border rounded-lg shadow-xl py-1 z-50 animate-scale-in">
                  <div className="max-h-48 overflow-y-auto">
                    {projects.map((proj) => (
                      <button
                        key={proj.id}
                        onClick={() => {
                          selectProject(proj.id)
                          setDropdownOpen(false)
                        }}
                        className={cn(
                          "flex items-center justify-between w-full px-3 py-2 text-left text-xs hover:bg-sidebar/50 transition-colors text-sidebar-foreground hover:text-white",
                          proj.id === activeProjectId && "bg-primary/10 text-primary font-semibold"
                        )}
                      >
                        <span className="truncate pr-2">{proj.name}</span>
                        {proj.id === activeProjectId && <Check className="w-3.5 h-3.5 flex-shrink-0 text-primary" />}
                      </button>
                    ))}
                  </div>
                  {currentUser?.role !== 'Delivery Manager' && (
                    <div className="border-t border-sidebar-border/40 mt-1 pt-1 px-1">
                      <button
                        onClick={() => {
                          setShowModal(true)
                          setDropdownOpen(false)
                        }}
                        className="flex items-center gap-1.5 w-full px-2 py-1.5 rounded text-[11px] font-semibold text-primary hover:bg-primary/10 transition-colors"
                      >
                        <Plus className="w-3.5 h-3.5" /> New Project
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-3 px-2 overflow-y-auto space-y-0.5">
          {filteredNavItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-200 group relative',
                  collapsed && 'justify-center px-2',
                  isActive
                    ? 'bg-primary/15 text-primary'
                    : 'text-sidebar-foreground/70 hover:text-white hover:bg-sidebar-accent'
                )}
              >
                <Icon className={cn('w-[18px] h-[18px] flex-shrink-0', isActive && 'text-primary')} />
                {!collapsed && <span className="truncate">{item.label}</span>}
                {isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-primary rounded-r-full" />
                )}
                {collapsed && (
                  <div className="absolute left-full ml-2 px-2.5 py-1.5 bg-foreground text-background text-xs rounded-md whitespace-nowrap opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all pointer-events-none z-50 shadow-lg">
                    {item.label}
                  </div>
                )}
              </NavLink>
            )
          })}
        </nav>

        {/* Collapse Toggle */}
        <div className="p-2 border-t border-sidebar-border">
          <button
            onClick={toggleSidebar}
            className="flex items-center justify-center w-full py-2 rounded-lg text-sidebar-foreground/60 hover:text-white hover:bg-sidebar-accent transition-colors"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            {!collapsed && <span className="ml-2 text-xs">Collapse</span>}
          </button>
        </div>
      </aside>

      {/* New Project Modal Overlay */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-card border border-border w-full max-w-md rounded-xl p-5 shadow-2xl animate-scale-in text-foreground relative">
            <button 
              onClick={() => setShowModal(false)}
              className="absolute right-4 top-4 p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center text-primary">
                <FolderGit className="w-4 h-4" />
              </div>
              <h2 className="text-base font-bold">Create New Project</h2>
            </div>
            
            <form onSubmit={handleCreateProject} className="space-y-4 text-left">
              <div>
                <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block mb-1">Project Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. HealthCare ERP Core"
                  value={newProjName}
                  onChange={e => setNewProjName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary transition-colors"
                />
              </div>
              
              <div>
                <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider block mb-1">Description</label>
                <textarea
                  placeholder="Describe the objectives and components of this project solution..."
                  value={newProjDesc}
                  onChange={e => setNewProjDesc(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary transition-colors resize-none"
                />
              </div>





              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 text-xs font-medium rounded-lg border border-border hover:bg-muted transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
                >
                  Create Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
