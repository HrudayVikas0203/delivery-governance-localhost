import React from 'react'
import { Sparkles, RefreshCw, CheckCircle2, AlertCircle, X, RotateCcw } from 'lucide-react'

export const REGENERATION_STEPS = [
  'Preparing project...',
  'Loading requirements...',
  'Generating with AI...',
  'Processing response...',
  'Saving version...',
  'Completed.'
] as const

export type RegenerationStep = (typeof REGENERATION_STEPS)[number]

interface RegenerationProgressModalProps {
  isOpen: boolean
  title: string
  currentStep: string
  error: string | null
  onClose: () => void
  onRetry?: () => void
}

export const RegenerationProgressModal: React.FC<RegenerationProgressModalProps> = ({
  isOpen,
  title,
  currentStep,
  error,
  onClose,
  onRetry,
}) => {
  if (!isOpen) return null

  const activeIndex = REGENERATION_STEPS.indexOf(currentStep as RegenerationStep)
  const isCompleted = currentStep === 'Completed.'
  const progressPercent = error
    ? Math.max(15, (activeIndex >= 0 ? activeIndex : 1) * 20)
    : isCompleted
    ? 100
    : Math.max(10, (activeIndex >= 0 ? activeIndex + 1 : 1) * 16)

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-2xl border border-border p-6 max-w-md w-full space-y-5 shadow-2xl animate-scale-in text-foreground">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-primary/10 text-primary">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold leading-tight">{title}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Real-time LLM workflow synthesis</p>
            </div>
          </div>
          {(isCompleted || error) && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-medium">
            <span className="text-muted-foreground">Progress</span>
            <span className="text-primary font-bold">{Math.min(100, Math.round(progressPercent))}%</span>
          </div>
          <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                error ? 'bg-destructive' : isCompleted ? 'bg-emerald-500' : 'bg-primary'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Steps List */}
        <div className="space-y-2 py-1">
          {REGENERATION_STEPS.map((step, idx) => {
            const stepDone = activeIndex > idx || isCompleted
            const stepActive = activeIndex === idx && !isCompleted && !error
            const stepFailed = error && activeIndex === idx

            return (
              <div
                key={step}
                className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-xs transition-colors ${
                  stepFailed
                    ? 'border-destructive/40 bg-destructive/10 text-destructive'
                    : stepDone
                    ? 'border-emerald-500/20 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400 font-medium'
                    : stepActive
                    ? 'border-primary/40 bg-primary/10 text-primary font-semibold'
                    : 'border-border/40 bg-muted/20 text-muted-foreground/60'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <span className="font-mono text-[10px] opacity-75">0{idx + 1}</span>
                  <span>{step}</span>
                </span>
                {stepDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                ) : stepActive ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-primary" />
                ) : stepFailed ? (
                  <AlertCircle className="w-4 h-4 text-destructive" />
                ) : (
                  <div className="w-2 h-2 rounded-full bg-border/60" />
                )}
              </div>
            )
          })}
        </div>

        {/* Error Alert Box */}
        {error && (
          <div className="p-3.5 rounded-xl bg-destructive/10 border border-destructive/30 space-y-2">
            <div className="flex items-start gap-2.5 text-xs text-destructive font-medium">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <span className="font-bold">Regeneration Failed</span>
                <p className="mt-0.5 text-[11px] leading-relaxed opacity-90">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Actions Footer */}
        <div className="flex justify-end gap-2 border-t border-border/60 pt-3.5">
          {error ? (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-border text-xs font-semibold hover:bg-muted transition-colors"
              >
                Close
              </button>
              {onRetry && (
                <button
                  onClick={onRetry}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors shadow-sm"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Retry Regeneration
                </button>
              )}
            </>
          ) : isCompleted ? (
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              Done
            </button>
          ) : (
            <span className="text-[11px] text-muted-foreground italic flex items-center gap-1.5 py-1">
              <RefreshCw className="w-3 h-3 animate-spin text-primary" />
              Do not close window while AI synthesizes architecture...
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
