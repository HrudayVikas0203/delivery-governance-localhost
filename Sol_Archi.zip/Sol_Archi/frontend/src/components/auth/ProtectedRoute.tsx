import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { APP_ROUTES } from '@/config/routes'

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { currentUser, isAuthenticated, hasPermission } = useAuth()
  const location = useLocation()

  if (!isAuthenticated || !currentUser) {
    return <Navigate to={APP_ROUTES.signIn} state={{ from: location }} replace />
  }

  if (location.pathname === APP_ROUTES.accessDenied) {
    return <>{children}</>
  }

  if (!hasPermission(location.pathname)) {
    return <Navigate to={APP_ROUTES.accessDenied} replace />
  }

  return <>{children}</>
}
