import { useState, useEffect } from 'react'
import { useApp } from '@/context/AppContext'
import {
  AI_PROVIDERS,
  DEFAULT_AI_CONFIG,
  MODULE_LABEL_MAP,
  type AiConfig,
  type ModuleModelMapping,
} from '@/data/aiConfig'
import { cn } from '@/lib/utils'
import {
  Cpu,
  Sparkles,
  Save,
  RotateCcw,
  Check,
  Server,
  Sliders,
  Layers,
  Key,
  Globe,
  HelpCircle,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react'
import { toast } from 'sonner'

export function AiConfigurationSection() {
  const { state, updateAiConfig } = useApp()
  const [config, setConfig] = useState<AiConfig>(state.aiConfig)
  const [isSaved, setIsSaved] = useState(false)

  // Sync state if external config changes
  useEffect(() => {
    setConfig(state.aiConfig)
  }, [state.aiConfig])

  // Current provider definition
  const currentProviderDef = AI_PROVIDERS.find(p => p.name === config.provider) || AI_PROVIDERS[0]
  const availableModels = currentProviderDef.models

  // Handle Provider change: reset selected models if not in new provider's list
  const handleProviderChange = (newProviderName: string) => {
    const providerDef = AI_PROVIDERS.find(p => p.name === newProviderName) || AI_PROVIDERS[0]
    const defaultModelForNewProvider = providerDef.models[0]

    const newModuleModels: ModuleModelMapping = {
      requirementExtraction: providerDef.models.includes(config.moduleModels.requirementExtraction)
        ? config.moduleModels.requirementExtraction
        : defaultModelForNewProvider,
      businessFlow: providerDef.models.includes(config.moduleModels.businessFlow)
        ? config.moduleModels.businessFlow
        : defaultModelForNewProvider,
      architecture: providerDef.models.includes(config.moduleModels.architecture)
        ? config.moduleModels.architecture
        : defaultModelForNewProvider,
      reports: providerDef.models.includes(config.moduleModels.reports)
        ? config.moduleModels.reports
        : defaultModelForNewProvider,
      aiChat: providerDef.models.includes(config.moduleModels.aiChat)
        ? config.moduleModels.aiChat
        : defaultModelForNewProvider,
    }

    setConfig(prev => ({
      ...prev,
      provider: newProviderName,
      defaultModel: defaultModelForNewProvider,
      moduleModels: newModuleModels,
    }))
  }

  const handleModuleModelChange = (moduleKey: keyof ModuleModelMapping, model: string) => {
    setConfig(prev => ({
      ...prev,
      moduleModels: {
        ...prev.moduleModels,
        [moduleKey]: model,
      },
    }))
  }

  const handleSave = () => {
    updateAiConfig(config)
    setIsSaved(true)
    toast.success(`AI Configuration saved! Active Provider: ${config.provider}`)
    setTimeout(() => setIsSaved(false), 2000)
  }

  const handleReset = () => {
    setConfig(DEFAULT_AI_CONFIG)
    updateAiConfig(DEFAULT_AI_CONFIG)
    toast.info('AI Configuration reset to default settings.')
  }

  return (
    <div className="bg-card rounded-xl border border-border p-5 md:p-6 space-y-6 shadow-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border/60 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground flex items-center gap-2">
                AI Configuration
                <span className="text-[10px] font-semibold bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Admin Module
                </span>
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Configure global AI model providers, task assignment, hyper-parameters, and credentials
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-medium hover:bg-muted transition-colors text-muted-foreground"
            title="Reset to default AI configuration"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset
          </button>
          <button
            onClick={handleSave}
            className={cn(
              'flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all shadow',
              isSaved
                ? 'bg-emerald-600 text-white'
                : 'bg-primary text-primary-foreground hover:opacity-90'
            )}
          >
            {isSaved ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
            {isSaved ? 'Saved!' : 'Save Configuration'}
          </button>
        </div>
      </div>

      {/* Provider Selector */}
      <div className="space-y-3">
        <label className="text-xs font-bold text-foreground flex items-center gap-1.5 uppercase tracking-wider">
          <Server className="w-3.5 h-3.5 text-primary" />
          Select AI Provider
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
          {AI_PROVIDERS.map(p => {
            const isSelected = config.provider === p.name
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => handleProviderChange(p.name)}
                className={cn(
                  'flex flex-col text-left p-3 rounded-xl border-2 transition-all cursor-pointer relative',
                  isSelected
                    ? 'border-primary bg-primary/5 shadow-sm'
                    : 'border-border hover:border-primary/40 bg-card'
                )}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className="text-xs font-bold text-foreground">{p.name}</span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground line-clamp-2 leading-tight">
                  {p.description}
                </p>
                <div className="mt-2 text-[9px] font-mono text-primary/80 bg-primary/10 px-1.5 py-0.5 rounded w-max">
                  {p.models.length} Models
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Available Models & Primary Model */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-muted/20 p-4 rounded-xl border border-border/70">
        <div>
          <label className="text-xs font-semibold text-foreground flex items-center gap-1.5 mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Default Primary Model ({config.provider})
          </label>
          <p className="text-[11px] text-muted-foreground mb-2">
            Default fallback engine dynamically loaded for general processing tasks.
          </p>
          <select
            value={config.defaultModel}
            onChange={e => setConfig(prev => ({ ...prev, defaultModel: e.target.value }))}
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-xs font-mono font-medium outline-none focus:border-primary transition-colors"
          >
            {availableModels.map(m => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </div>

        {/* Dynamic Model Specs */}
        <div className="flex flex-col justify-center text-xs space-y-1 bg-background/60 p-3 rounded-lg border border-border/50">
          <div className="flex justify-between items-center text-[11px]">
            <span className="text-muted-foreground">Active Provider:</span>
            <span className="font-semibold font-mono text-primary">{config.provider}</span>
          </div>
          <div className="flex justify-between items-center text-[11px]">
            <span className="text-muted-foreground">Available Models:</span>
            <span className="font-mono text-foreground font-medium">{availableModels.join(', ')}</span>
          </div>
          <div className="flex justify-between items-center text-[11px]">
            <span className="text-muted-foreground">Endpoint Required:</span>
            <span className="font-mono text-foreground">
              {currentProviderDef.requiresEndpoint ? 'Yes (Configured below)' : 'Standard Managed Cloud'}
            </span>
          </div>
        </div>
      </div>

      {/* Task Model Assignment (Module Models) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-foreground flex items-center gap-1.5 uppercase tracking-wider">
            <Layers className="w-3.5 h-3.5 text-primary" />
            Task-Specific Model Assignment
          </label>
          <span className="text-[10px] text-muted-foreground">
            Configure specific AI models for individual solution lifecycle tasks
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {(Object.keys(config.moduleModels) as Array<keyof ModuleModelMapping>).map(key => {
            const label = MODULE_LABEL_MAP[key]
            return (
              <div
                key={key}
                className="flex items-center justify-between p-3 rounded-lg border border-border/80 bg-background hover:border-primary/30 transition-colors"
              >
                <div className="pr-2">
                  <p className="text-xs font-semibold text-foreground">{label}</p>
                  <p className="text-[10px] text-muted-foreground">Target processing engine</p>
                </div>
                <select
                  value={config.moduleModels[key]}
                  onChange={e => handleModuleModelChange(key, e.target.value)}
                  className="px-2.5 py-1.5 rounded-md border border-border bg-card text-xs font-mono outline-none focus:border-primary font-medium text-foreground min-w-[150px]"
                >
                  {availableModels.map(m => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
            )
          })}
        </div>
      </div>

      {/* Generation Hyperparameters & Controls */}
      <div className="space-y-4 pt-2 border-t border-border/60">
        <label className="text-xs font-bold text-foreground flex items-center gap-1.5 uppercase tracking-wider">
          <Sliders className="w-3.5 h-3.5 text-primary" />
          Model Parameters & Output Formatting
        </label>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Temperature */}
          <div className="p-3 rounded-xl border border-border bg-background space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-foreground">Temperature</span>
              <span className="font-mono font-bold text-primary bg-primary/10 px-2 py-0.5 rounded text-[11px]">
                {config.temperature}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={config.temperature}
              onChange={e => setConfig(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
              className="w-full accent-primary cursor-pointer h-1.5 bg-muted rounded-lg"
            />
            <div className="flex justify-between text-[9px] text-muted-foreground">
              <span>Deterministic (0.0)</span>
              <span>Creative (1.0)</span>
            </div>
          </div>

          {/* Max Tokens */}
          <div className="p-3 rounded-xl border border-border bg-background space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-foreground">Max Tokens</span>
              <span className="font-mono text-xs text-muted-foreground">Context Limit</span>
            </div>
            <select
              value={config.maxTokens}
              onChange={e => setConfig(prev => ({ ...prev, maxTokens: parseInt(e.target.value) }))}
              className="w-full px-3 py-1.5 rounded-lg border border-border bg-card text-xs font-mono outline-none focus:border-primary font-medium"
            >
              <option value={1024}>1,024 Tokens (Fast)</option>
              <option value={2048}>2,048 Tokens (Standard)</option>
              <option value={4096}>4,096 Tokens (High Detail)</option>
              <option value={8192}>8,192 Tokens (Extended Brief)</option>
              <option value={16384}>16,384 Tokens (Maximum Context)</option>
            </select>
            <p className="text-[9px] text-muted-foreground">Controls response length and context ceiling.</p>
          </div>

          {/* Response Format */}
          <div className="p-3 rounded-xl border border-border bg-background space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-foreground">Response Format</span>
              <span className="font-mono text-xs text-muted-foreground">Schema Enforcement</span>
            </div>
            <select
              value={config.responseFormat}
              onChange={e =>
                setConfig(prev => ({
                  ...prev,
                  responseFormat: e.target.value as AiConfig['responseFormat'],
                }))
              }
              className="w-full px-3 py-1.5 rounded-lg border border-border bg-card text-xs font-medium outline-none focus:border-primary font-mono"
            >
              <option value="JSON Object">JSON Object (Structured)</option>
              <option value="Markdown">Markdown (Formatted)</option>
              <option value="Structured Text">Structured Text</option>
              <option value="Raw Text">Raw Text</option>
            </select>
            <p className="text-[9px] text-muted-foreground font-normal">Specifies system response constraints.</p>
          </div>
        </div>
      </div>

      {/* Unconfigured Warning Box */}
      {(!config.apiKey || config.apiKey.trim() === '') && config.provider !== 'Ollama' && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs text-amber-600 dark:text-amber-400">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-bold text-foreground">API Key Required for Provider '{config.provider}'</span>
            <p className="text-[11px] opacity-90 leading-relaxed">
              No API Key is currently configured for <strong>{config.provider}</strong>. AI modules (Requirements, Business Flow, Architecture, and AI Chat) require a valid API key to function. Please enter your API Key below and click <strong>Save Configuration</strong>.
            </p>
          </div>
        </div>
      )}

      {/* Credentials, Timeout & Retry Count */}
      <div className="p-4 rounded-xl border border-border bg-muted/10 space-y-3">
        <h4 className="text-xs font-bold text-foreground flex items-center gap-1.5">
          <Globe className="w-3.5 h-3.5 text-primary" /> Endpoint, Timeout & Governance Retries
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="md:col-span-2">
            <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
              Endpoint URL
            </label>
            <input
              type="text"
              value={config.endpointUrl || ''}
              onChange={e => setConfig(prev => ({ ...prev, endpointUrl: e.target.value }))}
              placeholder="https://your-custom-endpoint.com/v1"
              className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-mono text-xs outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
              API Timeout (Seconds)
            </label>
            <input
              type="number"
              min={5}
              max={120}
              value={config.timeout || 30}
              onChange={e => setConfig(prev => ({ ...prev, timeout: parseInt(e.target.value) || 30 }))}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-mono text-xs outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
              Retry Count
            </label>
            <input
              type="number"
              min={0}
              max={5}
              value={config.retryCount || 3}
              onChange={e => setConfig(prev => ({ ...prev, retryCount: parseInt(e.target.value) || 0 }))}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-mono text-xs outline-none focus:border-primary"
            />
          </div>
          <div className="md:col-span-4">
            <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
              API Key / Access Token (Encrypted Storage)
            </label>
            <input
              type="password"
              value={config.apiKey || ''}
              onChange={e => setConfig(prev => ({ ...prev, apiKey: e.target.value }))}
              placeholder="Enter API Key / Token"
              className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-mono text-xs outline-none focus:border-primary"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
