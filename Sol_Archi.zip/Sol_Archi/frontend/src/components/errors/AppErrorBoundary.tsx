import React from 'react'

type AppErrorBoundaryState = {
  hasError: boolean
  errorMessage: string
}

export class AppErrorBoundary extends React.Component<React.PropsWithChildren, AppErrorBoundaryState> {
  state: AppErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  }

  static getDerivedStateFromError(error: Error): AppErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error.message || 'Unexpected application error.',
    }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Application render failure', error, errorInfo)
  }

  render() {
    if (!this.state.hasError) {
      return this.props.children
    }

    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-6">
        <div className="w-full max-w-xl rounded-2xl border border-border bg-card p-6 shadow-sm">
          <h1 className="text-lg font-semibold text-foreground">Application Error</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            The application hit a rendering error while loading the authenticated workspace.
          </p>
          <p className="mt-3 rounded-lg bg-muted px-3 py-2 text-xs font-mono text-muted-foreground break-words">
            {this.state.errorMessage}
          </p>
          <div className="mt-4 flex gap-2">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Reload
            </button>
            <button
              type="button"
              onClick={() => {
                window.location.href = '/signin'
              }}
              className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground"
            >
              Back To Sign In
            </button>
          </div>
        </div>
      </div>
    )
  }
}
