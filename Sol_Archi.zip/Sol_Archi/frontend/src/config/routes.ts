export const APP_ROUTES = {
  dashboard: '/',
  signIn: '/signin',
  upload: '/upload',
  requirements: '/requirements',
  businessFlow: '/business-flow',
  architecture: '/architecture',
  aiChat: '/ai-chat',
  export: '/export',
  settings: '/settings',
  userManagement: '/user-management',
  accessDenied: '/access-denied',
} as const

export type AppRoutePath = (typeof APP_ROUTES)[keyof typeof APP_ROUTES]

export interface AppRouteDefinition {
  path: AppRoutePath
  label: string
  pageTitle: string
  requiresAuth: boolean
}

export const APP_ROUTE_DEFINITIONS: AppRouteDefinition[] = [
  { path: APP_ROUTES.dashboard, label: 'Dashboard', pageTitle: 'Dashboard', requiresAuth: true },
  { path: APP_ROUTES.signIn, label: 'Sign In', pageTitle: 'Sign In', requiresAuth: false },
  { path: APP_ROUTES.upload, label: 'Upload Document', pageTitle: 'Upload Document', requiresAuth: true },
  { path: APP_ROUTES.requirements, label: 'Requirements', pageTitle: 'Requirements', requiresAuth: true },
  { path: APP_ROUTES.businessFlow, label: 'Business Flow', pageTitle: 'Business Flow', requiresAuth: true },
  { path: APP_ROUTES.architecture, label: 'Solution Architecture', pageTitle: 'Solution Architecture', requiresAuth: true },
  { path: APP_ROUTES.aiChat, label: 'AI Chat', pageTitle: 'AI Chat', requiresAuth: true },
  { path: APP_ROUTES.export, label: 'Export Center', pageTitle: 'Export Center', requiresAuth: true },
  { path: APP_ROUTES.settings, label: 'Settings', pageTitle: 'Settings', requiresAuth: true },
  { path: APP_ROUTES.userManagement, label: 'User Directory', pageTitle: 'User Directory', requiresAuth: true },
  { path: APP_ROUTES.accessDenied, label: 'Access Denied', pageTitle: 'Access Denied', requiresAuth: true },
]

export const PAGE_TITLES = Object.fromEntries(
  APP_ROUTE_DEFINITIONS.map((route) => [route.path, route.pageTitle]),
) as Record<AppRoutePath, string>
