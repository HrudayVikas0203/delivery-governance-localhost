import { useState, useEffect } from 'react'
import { useApp } from '@/context/AppContext'
import { useAuth } from '@/context/AuthContext'
import { cn } from '@/lib/utils'
import { AiConfigurationSection } from '@/components/AiConfigurationSection'
import {
  initDefaultPromptTemplates,
  getAllPromptTemplates,
  updatePromptTemplate,
  getPromptVersions,
  rollbackPromptTemplate,
} from '@/services/promptService'
import {
  initDefaultIntegrations,
  getAllIntegrationConfigs,
  exportToExternalPlatform,
} from '@/services/integrationService'
import {
  createSystemBackup,
  downloadBackupFile,
  restoreFromBackupJson,
  getAllBackups,
} from '@/services/backupService'
import {
  Sun, Moon, Monitor, User, Bell, Download, GitBranch, Info, FileCode2, Share2, Database, Shield, RotateCcw, Save, Check
} from 'lucide-react'
import { toast } from 'sonner'

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn(
        'relative w-10 h-[22px] rounded-full transition-colors',
        checked ? 'bg-primary' : 'bg-muted'
      )}
    >
      <div className={cn(
        'absolute top-[3px] w-4 h-4 rounded-full bg-white shadow transition-transform',
        checked ? 'translate-x-[22px]' : 'translate-x-[3px]'
      )} />
    </button>
  )
}

function PromptManagementSection() {
  const [templates, setTemplates] = useState<any[]>([])
  const [selectedId, setSelectedId] = useState('')
  const [text, setText] = useState('')
  const [versions, setVersions] = useState<any[]>([])

  useEffect(() => {
    initDefaultPromptTemplates().then(() => {
      getAllPromptTemplates().then(list => {
        setTemplates(list)
        if (list.length > 0) {
          setSelectedId(list[0].id)
          setText(list[0].promptText)
          getPromptVersions(list[0].id).then(setVersions)
        }
      })
    })
  }, [])

  const handleSelect = (id: string) => {
    setSelectedId(id)
    const tmpl = templates.find(t => t.id === id)
    if (tmpl) {
      setText(tmpl.promptText)
      getPromptVersions(id).then(setVersions)
    }
  }

  const handleSavePrompt = async () => {
    try {
      const updated = await updatePromptTemplate(selectedId, text)
      setTemplates(prev => prev.map(t => t.id === selectedId ? updated : t))
      const vers = await getPromptVersions(selectedId)
      setVersions(vers)
      toast.success(`Prompt template updated to version v${updated.version}!`)
    } catch (e) {
      toast.error('Failed to update prompt template.')
    }
  }

  return (
    <div className="bg-card rounded-xl border border-border p-5 space-y-4">
      <h3 className="text-sm font-semibold flex items-center gap-2">
        <FileCode2 className="w-4 h-4 text-primary" /> Prompt Template Manager & Version History
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="space-y-1">
          <label className="text-[10px] font-semibold text-muted-foreground uppercase">Prompt Category</label>
          <select
            value={selectedId}
            onChange={e => handleSelect(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-border bg-background text-xs font-medium outline-none focus:border-primary"
          >
            {templates.map(t => (
              <option key={t.id} value={t.id}>{t.name} (v{t.version})</option>
            ))}
          </select>
        </div>
        <div className="md:col-span-2 space-y-1">
          <div className="flex justify-between items-center">
            <label className="text-[10px] font-semibold text-muted-foreground uppercase">Template Text</label>
            <button
              onClick={handleSavePrompt}
              className="px-2.5 py-1 rounded bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1 hover:opacity-90 transition-opacity"
            >
              <Save className="w-3 h-3" /> Save New Version
            </button>
          </div>
          <textarea
            rows={4}
            value={text}
            onChange={e => setText(e.target.value)}
            className="w-full p-3 rounded-lg border border-border bg-background text-xs font-mono outline-none focus:border-primary resize-none"
          />
        </div>
      </div>

      {versions.length > 0 && (
        <div className="border-t border-border pt-3 space-y-2">
          <p className="text-xs font-semibold text-foreground">Version History & Rollbacks ({versions.length})</p>
          <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
            {versions.map(v => (
              <div key={v.id} className="flex items-center justify-between p-2 rounded bg-muted/40 border border-border/60 text-xs font-mono">
                <div>
                  <span className="font-bold text-primary mr-2">v{v.version}</span>
                  <span className="text-muted-foreground">{v.changeSummary}</span>
                </div>
                <button
                  onClick={async () => {
                    const restored = await rollbackPromptTemplate(v)
                    setText(restored.promptText)
                    toast.success(`Rolled back to v${v.version}!`)
                  }}
                  className="px-2 py-0.5 rounded bg-card border border-border hover:bg-muted text-[10px] flex items-center gap-1 font-sans font-semibold"
                >
                  <RotateCcw className="w-3 h-3 text-amber-500" /> Rollback
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function ExternalIntegrationsSection() {
  const [integrations, setIntegrations] = useState<any[]>([])

  useEffect(() => {
    initDefaultIntegrations().then(() => {
      getAllIntegrationConfigs().then(setIntegrations)
    })
  }, [])

  const handleTestExport = async (platform: any) => {
    toast.info(`Testing export adapter for ${platform}...`)
    try {
      const result = await exportToExternalPlatform(platform, 'Solution Design Package', { projectId: 'sample' })
      toast.success(result.message)
    } catch (e: any) {
      toast.error(e.message || 'Export failed')
    }
  }

  return (
    <div className="bg-card rounded-xl border border-border p-5 space-y-4">
      <h3 className="text-sm font-semibold flex items-center gap-2">
        <Share2 className="w-4 h-4 text-primary" /> External Platform Integrations (Jira, Confluence, GitHub, Teams, Slack)
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {integrations.map(cfg => (
          <div key={cfg.id} className="p-3 rounded-xl border border-border bg-background space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-foreground">{cfg.platform}</span>
              <span className={cn('px-2 py-0.5 rounded-full text-[9px] font-bold', cfg.enabled ? 'bg-emerald-500/15 text-emerald-600' : 'bg-muted text-muted-foreground')}>
                {cfg.enabled ? 'Active' : 'Disabled'}
              </span>
            </div>
            <p className="text-[10px] text-muted-foreground truncate font-mono">{cfg.endpointUrl}</p>
            <button
              onClick={() => handleTestExport(cfg.platform)}
              className="w-full py-1.5 rounded bg-muted/60 hover:bg-muted text-foreground text-xs font-semibold border border-border/80 transition-colors"
            >
              Test Dispatch
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

function BackupRecoverySection() {
  const [backups, setBackups] = useState<any[]>([])

  useEffect(() => {
    getAllBackups().then(setBackups)
  }, [])

  const handleCreateBackup = async () => {
    const record = await createSystemBackup()
    setBackups(prev => [record, ...prev])
    toast.success(`System backup snapshot created (${record.sizeStr})!`)
  }

  return (
    <div className="bg-card rounded-xl border border-border p-5 space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Database className="w-4 h-4 text-primary" /> Automated Backup & Snapshot Restoration
        </h3>
        <button
          onClick={handleCreateBackup}
          className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          Create Backup Snapshot
        </button>
      </div>
      {backups.length > 0 ? (
        <div className="space-y-2">
          {backups.slice(0, 3).map(b => (
            <div key={b.id} className="flex items-center justify-between p-2.5 rounded-lg border border-border bg-background text-xs">
              <div>
                <p className="font-semibold text-foreground">{b.description}</p>
                <p className="text-[10px] text-muted-foreground font-mono">{new Date(b.timestamp).toLocaleString()} • {b.sizeStr}</p>
              </div>
              <button
                onClick={() => downloadBackupFile(b)}
                className="px-2.5 py-1 rounded bg-muted hover:bg-muted/80 text-foreground border border-border text-[11px] font-semibold flex items-center gap-1"
              >
                <Download className="w-3 h-3" /> Download JSON
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">No backup snapshots created yet.</p>
      )}
    </div>
  )
}

function ProfileMFASection() {
  const { currentUser, toggleMFA } = useAuth()
  const mfaActive = currentUser?.mfaEnabled || false

  return (
    <div className="bg-card rounded-xl border border-border p-5 space-y-4">
      <h3 className="text-sm font-semibold flex items-center gap-2"><User className="w-4 h-4 text-primary" />Profile & Security (MFA)</h3>
      <div className="flex items-center gap-4 mb-4">
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white text-lg font-bold">
          {currentUser?.name.slice(0, 2).toUpperCase() || 'SA'}
        </div>
        <div>
          <p className="text-sm font-semibold">{currentUser?.name || 'Solution Architect'}</p>
          <p className="text-xs text-muted-foreground">{currentUser?.role || 'Enterprise Architect'}</p>
        </div>
      </div>

      <div className="flex items-center justify-between p-3 rounded-xl border border-border bg-background">
        <div>
          <p className="text-xs font-semibold text-foreground flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-primary" /> Multi-Factor Authentication (MFA)
          </p>
          <p className="text-[10px] text-muted-foreground">Requires 6-digit authenticator passcode on login</p>
        </div>
        <Toggle
          checked={mfaActive}
          onChange={v => {
            toggleMFA(v)
            toast.success(`Multi-Factor Authentication (MFA) ${v ? 'Enabled' : 'Disabled'}`)
          }}
        />
      </div>
    </div>
  )
}

export default function SettingsPage() {
  const { state, setTheme } = useApp()
  const [notifications, setNotifications] = useState({
    email: true, push: true, archChange: true, exportComplete: true, weeklyDigest: false,
  })
  const [exportPrefs, setExportPrefs] = useState({
    defaultFormat: 'PDF', includeMetadata: true, includeTimestamps: true, autoDownload: false,
  })
  const [diagramPrefs, setDiagramPrefs] = useState({
    theme: 'Light', showGrid: true, showMinimap: true, autoLayout: true, snapToGrid: true,
  })

  const themes = [
    { value: 'light' as const, label: 'Light', icon: Sun, desc: 'Clean, bright interface' },
    { value: 'dark' as const, label: 'Dark', icon: Moon, desc: 'Easy on the eyes' },
    { value: 'system' as const, label: 'System', icon: Monitor, desc: 'Follows OS preference' },
  ]

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted-foreground mt-1">Customize your AI Copilot experience</p>
      </div>

      {/* AI Configuration Section */}
      <AiConfigurationSection />


      {/* Prompt Management Module */}
      <PromptManagementSection />

      {/* External Integrations */}
      <ExternalIntegrationsSection />

      {/* Backup & Recovery */}
      <BackupRecoverySection />

      {/* Appearance */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold mb-4 flex items-center gap-2"><Sun className="w-4 h-4 text-primary" />Appearance</h3>
        <div className="grid grid-cols-3 gap-3">
          {themes.map(theme => {
            const Icon = theme.icon
            return (
              <button
                key={theme.value}
                onClick={() => setTheme(theme.value)}
                className={cn(
                  'flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all',
                  state.theme === theme.value ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/30'
                )}
              >
                <Icon className={cn('w-6 h-6', state.theme === theme.value ? 'text-primary' : 'text-muted-foreground')} />
                <span className="text-sm font-medium">{theme.label}</span>
                <span className="text-[10px] text-muted-foreground">{theme.desc}</span>
              </button>
            )
          })}
        </div>
      </div>

      {/* Profile & MFA */}
      <ProfileMFASection />

      {/* Notifications */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold mb-4 flex items-center gap-2"><Bell className="w-4 h-4 text-primary" />Notification Preferences</h3>
        <div className="space-y-3">
          {[
            { key: 'email', label: 'Email Notifications', desc: 'Receive email for important updates' },
            { key: 'push', label: 'Push Notifications', desc: 'Browser push notifications' },
            { key: 'archChange', label: 'Architecture Change Alerts', desc: 'Notified when architecture is modified' },
            { key: 'exportComplete', label: 'Export Completion Alerts', desc: 'Notified when exports are ready' },
            { key: 'weeklyDigest', label: 'Weekly Digest', desc: 'Weekly summary of all AI activity' },
          ].map(item => (
            <div key={item.key} className="flex items-center justify-between py-1">
              <div>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-[10px] text-muted-foreground">{item.desc}</p>
              </div>
              <Toggle
                checked={notifications[item.key as keyof typeof notifications]}
                onChange={v => setNotifications(prev => ({ ...prev, [item.key]: v }))}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Export Preferences */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold mb-4 flex items-center gap-2"><Download className="w-4 h-4 text-primary" />Export Preferences</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-1">
            <div><p className="text-sm font-medium">Default Format</p></div>
            <select
              value={exportPrefs.defaultFormat}
              onChange={e => setExportPrefs(prev => ({ ...prev, defaultFormat: e.target.value }))}
              className="px-3 py-1.5 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
            >
              <option>PDF</option><option>DOCX</option><option>PNG</option><option>JSON</option>
            </select>
          </div>
          {[
            { key: 'includeMetadata', label: 'Include Metadata', desc: 'Add generation metadata to exports' },
            { key: 'includeTimestamps', label: 'Include Timestamps', desc: 'Add timestamps to exported files' },
            { key: 'autoDownload', label: 'Auto-Download', desc: 'Automatically download after generation' },
          ].map(item => (
            <div key={item.key} className="flex items-center justify-between py-1">
              <div>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-[10px] text-muted-foreground">{item.desc}</p>
              </div>
              <Toggle
                checked={exportPrefs[item.key as keyof typeof exportPrefs] as boolean}
                onChange={v => setExportPrefs(prev => ({ ...prev, [item.key]: v }))}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Diagram Preferences */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold mb-4 flex items-center gap-2"><GitBranch className="w-4 h-4 text-primary" />Diagram Preferences</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-1">
            <div><p className="text-sm font-medium">Default Theme</p></div>
            <select
              value={diagramPrefs.theme}
              onChange={e => setDiagramPrefs(prev => ({ ...prev, theme: e.target.value }))}
              className="px-3 py-1.5 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
            >
              <option>Light</option><option>Dark</option><option>High Contrast</option>
            </select>
          </div>
          {[
            { key: 'showGrid', label: 'Show Grid', desc: 'Display grid on architecture canvas' },
            { key: 'showMinimap', label: 'Show Minimap', desc: 'Display minimap navigator' },
            { key: 'autoLayout', label: 'Auto Layout', desc: 'Automatically arrange components' },
            { key: 'snapToGrid', label: 'Snap to Grid', desc: 'Components snap to grid when moving' },
          ].map(item => (
            <div key={item.key} className="flex items-center justify-between py-1">
              <div>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-[10px] text-muted-foreground">{item.desc}</p>
              </div>
              <Toggle
                checked={diagramPrefs[item.key as keyof typeof diagramPrefs] as boolean}
                onChange={v => setDiagramPrefs(prev => ({ ...prev, [item.key]: v }))}
              />
            </div>
          ))}
        </div>
      </div>

      {/* About */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold mb-4 flex items-center gap-2"><Info className="w-4 h-4 text-primary" />About</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Application', value: 'AI Solution Architect Copilot' },
            { label: 'Version', value: '5.0.0 Enterprise' },
            { label: 'Build', value: '2026.07.21' },
            { label: 'Engine', value: 'Multi-LLM Prompt Governance Agent' },
          ].map(item => (
            <div key={item.label} className="bg-muted/30 rounded-lg p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{item.label}</p>
              <p className="text-sm font-medium mt-0.5">{item.value}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
