import { useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import type { UserRole } from '@/context/AuthContext'
import { toast } from 'sonner'
import {
  Users, UserCheck, ShieldAlert, Plus, ShieldCheck, Mail, Edit3, Trash, X
} from 'lucide-react'

export default function UserManagement() {
  const { users, updateUserRole, createUser } = useAuth()
  const [showAddModal, setShowAddModal] = useState(false)
  
  // New user form states
  const [newUserName, setNewUserName] = useState('')
  const [newUserEmail, setNewUserEmail] = useState('')
  const [newUserRole, setNewUserRole] = useState<UserRole>('Business Analyst')

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newUserName.trim() || !newUserEmail.trim()) {
      toast.error('Name and Email are required')
      return
    }

    createUser(newUserName, newUserEmail, newUserRole)
    toast.success(`User "${newUserName}" added with role ${newUserRole}`)
    
    // Reset
    setNewUserName('')
    setNewUserEmail('')
    setNewUserRole('Business Analyst')
    setShowAddModal(false)
  }

  // Count metrics
  const totalUsers = users.length
  const adminCount = users.filter(u => u.role === 'Admin').length
  const architectCount = users.filter(u => u.role === 'Solution Architect' || u.role === 'Enterprise Architect').length
  const analystCount = users.filter(u => u.role === 'Business Analyst').length
  const managerCount = users.filter(u => u.role === 'Delivery Manager').length

  return (
    <div className="space-y-6 animate-fade-in text-foreground">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">User & Role Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Admin console to assign roles, manage system directories, and audit access</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity shadow"
        >
          <Plus className="w-3.5 h-3.5" /> Add User
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: 'Directory Users', value: totalUsers, icon: Users, color: 'text-blue-500 bg-blue-500/10' },
          { label: 'Administrators', value: adminCount, icon: ShieldCheck, color: 'text-pink-500 bg-pink-500/10' },
          { label: 'Architects (SA/EA)', value: architectCount, icon: UserCheck, color: 'text-purple-500 bg-purple-500/10' },
          { label: 'Business Analysts', value: analystCount, icon: Edit3, color: 'text-emerald-500 bg-emerald-500/10' },
          { label: 'Delivery Managers', value: managerCount, icon: ShieldAlert, color: 'text-orange-500 bg-orange-500/10' },
        ].map((stat, i) => {
          const Icon = stat.icon
          return (
            <div key={i} className="bg-card rounded-xl border border-border px-4 py-3 flex items-center gap-3">
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0', stat.color)}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-lg font-bold leading-tight">{stat.value}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5 font-medium">{stat.label}</p>
              </div>
            </div>
          )
        })}
      </div>

      {/* Directory Table */}
      <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-sm">
        <div className="px-5 py-3.5 border-b border-border">
          <h3 className="text-sm font-semibold">User Directory</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/20">
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">User details</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Email Address</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Active Role</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Directory Source</th>
                <th className="text-right px-5 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {users.map(user => (
                <tr key={user.id} className="hover:bg-muted/10 transition-colors">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/10 to-primary/30 flex items-center justify-center font-bold text-xs text-primary">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-foreground truncate">{user.name}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">ID: {user.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5 text-xs text-muted-foreground font-mono">{user.email}</td>
                  <td className="px-5 py-3.5">
                    <select
                      value={user.role}
                      onChange={(e) => {
                        const newRole = e.target.value as UserRole
                        updateUserRole(user.id, newRole)
                        toast.success(`Role updated to ${newRole} for ${user.name}`)
                      }}
                      className="px-2.5 py-1.5 rounded-lg border border-border bg-background text-[11px] font-semibold outline-none focus:border-primary cursor-pointer transition-colors"
                    >
                      <option value="Business Analyst">Business Analyst</option>
                      <option value="Solution Architect">Solution Architect</option>
                      <option value="Enterprise Architect">Enterprise Architect</option>
                      <option value="Delivery Manager">Delivery Manager</option>
                      <option value="Admin">Admin</option>
                    </select>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="text-[9px] bg-primary/10 text-primary px-2.5 py-0.5 rounded-md font-bold uppercase font-mono">
                      Azure Entra ID
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-right">
                    <button
                      onClick={() => toast.info('Integration details available in production')}
                      className="p-1.5 rounded hover:bg-muted hover:text-red-500 text-muted-foreground transition-colors"
                      title="Deactivate User"
                    >
                      <Trash className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add User Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-card rounded-2xl border border-border w-full max-w-md overflow-hidden shadow-2xl animate-scale-in">
            <div className="px-5 py-4 border-b border-border flex items-center justify-between bg-muted/20">
              <h3 className="text-sm font-bold flex items-center gap-1.5 text-foreground">
                <Users className="w-4 h-4 text-primary" /> Create Directory Profile
              </h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded hover:bg-muted"><X className="w-4 h-4" /></button>
            </div>
            
            <form onSubmit={handleAddUser} className="p-5 space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Full Name</label>
                <input
                  type="text"
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full mt-1.5 px-3 py-2 rounded-xl border border-border bg-background text-xs outline-none focus:border-primary transition-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Email Address</label>
                <div className="relative mt-1.5">
                  <Mail className="w-3.5 h-3.5 text-muted-foreground absolute left-3 top-2.5" />
                  <input
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="e.g. john@company.com"
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-border bg-background text-xs outline-none focus:border-primary transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Directory Role Permission</label>
                <select
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value as UserRole)}
                  className="w-full mt-1.5 px-3 py-2 rounded-xl border border-border bg-background text-xs outline-none focus:border-primary transition-colors"
                >
                  <option value="Business Analyst">Business Analyst</option>
                  <option value="Solution Architect">Solution Architect</option>
                  <option value="Enterprise Architect">Enterprise Architect</option>
                  <option value="Delivery Manager">Delivery Manager</option>
                  <option value="Admin">Admin</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2 border-t border-border/60">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 rounded-xl border border-border text-xs font-semibold hover:bg-muted transition-colors text-muted-foreground"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-xs font-semibold hover:opacity-90 transition-opacity"
                >
                  Confirm Addition
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

// Simple cn utility local definition in case of importing issues
function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ')
}
