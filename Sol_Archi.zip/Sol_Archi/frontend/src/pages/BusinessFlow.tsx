import { useState, useCallback, useEffect, useMemo } from 'react'
import { useDocuments } from '@/context/DocumentContext'
import { cn } from '@/lib/utils'
import { useAuth } from '@/context/AuthContext'
import {
  ReactFlow, MiniMap, Controls, Background, BackgroundVariant, useNodesState, useEdgesState,
  type Node, type Edge, Panel, addEdge, Handle, Position,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { toast } from 'sonner'
import {
  Edit2, Save, Trash2, Plus, X, Layers, ChevronDown, Sparkles, History, Download, RefreshCw, FileText, Check
} from 'lucide-react'
import type { FlowNode, FlowEdge } from '@/data/types'
import { exportDesignArtifactAPI } from '@/services/api'
import type { ExportFormat } from '@/services/exportService'
import { submitGovernanceReview } from '@/services/collaborationService'
import { RegenerationProgressModal } from '@/components/RegenerationProgressModal'

// Custom node component for Business Flow
function CustomFlowNode({ data, selected }: any) {
  const color = data.color || '#3B82F6'

  return (
    <div
      className={cn(
        'px-4 py-2.5 rounded-lg shadow-sm text-white font-medium text-xs text-center min-w-[130px] relative border transition-all',
        selected ? 'ring-2 ring-primary border-primary scale-[1.02]' : 'border-transparent'
      )}
      style={{ backgroundColor: color }}
    >
      <Handle
        type="target"
        position={Position.Top}
        className="!w-2 !h-2 !bg-white !border-slate-500"
        style={{ top: -5 }}
      />
      <div>
        <p className="font-semibold text-xs">{data.label}</p>
        {data.description && <p className="text-[9px] opacity-80 mt-0.5">{data.description}</p>}
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        className="!w-2 !h-2 !bg-white !border-slate-500"
        style={{ bottom: -5 }}
      />
    </div>
  )
}

export default function BusinessFlow() {
  const {
    documentData,
    updateBusinessFlow,
    dbFlow,
    flowVersions,
    triggerGenerateBusinessFlow,
    restoreFlowVersion,
    activeProjectId,
    activeDocId,
  } = useDocuments()

  const [nodes, setNodes, onNodesChange] = useNodesState<Node>([])
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([])
  const [editMode, setEditMode] = useState(true)
  const [selectedNode, setSelectedNode] = useState<Node | null>(null)
  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null)

  // Dialog / Edit states
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showVersionModal, setShowVersionModal] = useState(false)
  const [exportMenuOpen, setExportMenuOpen] = useState(false)
  const [isRegenerating, setIsRegenerating] = useState(false)
  const [showProgressModal, setShowProgressModal] = useState(false)
  const [progressStep, setProgressStep] = useState('Preparing project...')
  const [regenerationError, setRegenerationError] = useState<string | null>(null)
  const [newNodeName, setNewNodeName] = useState('')
  const [newNodeDesc, setNewNodeDesc] = useState('')
  const [newNodeColor, setNewNodeColor] = useState('#3B82F6')

  // Connection Builder states
  const [connectTargetId, setConnectTargetId] = useState('')
  const [connectLabel, setConnectLabel] = useState('')

  const nodeTypes = useMemo(() => ({
    flowNode: CustomFlowNode,
  }), [])

  // Sync state when active document or dbFlow changes
  useEffect(() => {
    const flowNodes = documentData.businessFlow?.nodes ?? []
    const flowEdges = documentData.businessFlow?.edges ?? []

    const mappedNodes = flowNodes.map(n => ({
      ...n,
      type: 'flowNode',
      data: {
        ...(n.data ?? {}),
        color: n.style?.background || '#3B82F6',
      },
      style: undefined,
    }))

    setNodes(mappedNodes as Node[])
    setEdges(flowEdges as Edge[])
    setSelectedNode(null)
    setSelectedEdge(null)
    setConnectTargetId('')
    setConnectLabel('')
  }, [documentData, setNodes, setEdges])

  const onNodeClick = useCallback((_: any, node: Node) => {
    setSelectedNode(node)
    setSelectedEdge(null)
    setConnectTargetId('')
    setConnectLabel('')
  }, [])

  const onEdgeClick = useCallback((_: any, edge: Edge) => {
    setSelectedEdge(edge)
    setSelectedNode(null)
  }, [])

  const onConnect = useCallback((params: any) => {
    if (!editMode) return
    setEdges((eds) => addEdge({ ...params, animated: true, style: { stroke: '#94A3B8' } }, eds))
    toast.success('Connection created')
  }, [editMode, setEdges])

  const deleteSelectedNode = useCallback(() => {
    if (!selectedNode) return
    setNodes(nds => nds.filter(n => n.id !== selectedNode.id))
    setEdges(eds => eds.filter(e => e.source !== selectedNode.id && e.target !== selectedNode.id))
    setSelectedNode(null)
    toast.success('Node deleted')
  }, [selectedNode, setNodes, setEdges])

  const deleteSelectedEdge = useCallback(() => {
    if (!selectedEdge) return
    setEdges(eds => eds.filter(e => e.id !== selectedEdge.id))
    setSelectedEdge(null)
    toast.success('Connection deleted')
  }, [selectedEdge, setEdges])

  const renameNode = useCallback((id: string, newLabel: string) => {
    setNodes(nds => nds.map(n => {
      if (n.id === id) {
        return {
          ...n,
          data: { ...n.data, label: newLabel },
        }
      }
      return n
    }))
  }, [setNodes])

  const updateEdgeLabel = useCallback((id: string, newLabel: string) => {
    setEdges(eds => eds.map(e => {
      if (e.id === id) {
        return {
          ...e,
          label: newLabel,
        }
      }
      return e
    }))
  }, [setEdges])

  const handleConnectButton = () => {
    if (!selectedNode || !connectTargetId) return
    const newEdge: Edge = {
      id: `manual-edge-${Date.now()}`,
      source: selectedNode.id,
      target: connectTargetId,
      label: connectLabel || undefined,
      animated: true,
      style: { stroke: '#94A3B8' },
    }
    setEdges(eds => addEdge(newEdge, eds))
    setConnectTargetId('')
    setConnectLabel('')
    toast.success('Connection line added')
  }

  const addCustomNode = () => {
    if (!newNodeName.trim()) return
    const id = `bf-node-${Date.now()}`
    const newNode: Node = {
      id,
      type: 'flowNode',
      position: { x: 300, y: 150 },
      data: {
        label: newNodeName,
        description: newNodeDesc,
        color: newNodeColor,
      },
    }
    setNodes(nds => [...nds, newNode])
    setShowAddDialog(false)
    setNewNodeName('')
    setNewNodeDesc('')
    toast.success('Custom node added')
  }

  const saveChanges = () => {
    const serializedNodes: FlowNode[] = nodes.map(n => ({
      id: n.id,
      type: n.type || 'default',
      position: n.position,
      data: {
        label: ((n.data as any)?.label as string) || '',
        description: ((n.data as any)?.description as string) || '',
      },
      style: { background: ((n.data as any)?.color as string) || '#3B82F6' },
    }))
    updateBusinessFlow(serializedNodes, edges as FlowEdge[])
    setEditMode(false)
    toast.success('Business flow modifications saved')
  }

  const handleRegenerateFlow = async () => {
    if (isRegenerating) return
    setIsRegenerating(true)
    setShowProgressModal(true)
    setRegenerationError(null)
    setProgressStep('Preparing project...')

    try {
      await triggerGenerateBusinessFlow((step) => {
        setProgressStep(step)
      })
      toast.success('Business flow regenerated using AI!')
    } catch (e: any) {
      console.error('AI Flow Generation Error:', e)
      const msg = e?.message || 'AI Flow generation failed. Please check your AI API key and settings.'
      setRegenerationError(msg)
      toast.error(msg)
    } finally {
      setIsRegenerating(false)
    }
  }

  const handleExport = async (format: ExportFormat) => {
    setExportMenuOpen(false)
    try {
      const filename = `Business_Flow_${activeDocId || 'v1'}`
      await exportDesignArtifactAPI('Business Flow', format, 'business-flow-canvas', filename, {
        nodes,
        edges,
        projectId: activeProjectId,
        docId: activeDocId,
      })
      toast.success(`Business flow exported as ${format}!`)
    } catch (e) {
      toast.error(`Export to ${format} failed.`)
    }
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Business Flow Engine</h1>
          <p className="text-sm text-muted-foreground mt-1">AI-generated editable business process flow derived from extracted requirements</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Version History Button */}
          <button
            onClick={() => setShowVersionModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-muted transition-colors bg-card shadow-sm"
          >
            <History className="w-3.5 h-3.5 text-primary" />
            <span>Version: <strong className="text-primary">v{dbFlow ? dbFlow.version : 1}</strong></span>
          </button>

          {/* Governance Controls */}
          <div className="flex items-center gap-1 bg-muted/40 p-1 rounded-lg border border-border">
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'flow', 'Business Flow', 'Approved', 'Architect')
                toast.success('Business Flow marked as Approved!')
              }}
              className="px-2 py-1 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <Check className="w-3 h-3" /> Approve
            </button>
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'flow', 'Business Flow', 'Rejected', 'Architect')
                toast.warning('Business Flow marked as Rejected.')
              }}
              className="px-2 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <X className="w-3 h-3" /> Reject
            </button>
          </div>

          {/* AI Regenerate Button */}
          <button
            onClick={handleRegenerateFlow}
            disabled={isRegenerating}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-primary/10 border border-primary/20 hover:border-primary/50 text-primary rounded-lg text-xs font-semibold transition-colors"
          >
            {isRegenerating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {isRegenerating ? 'Generating...' : 'Regenerate AI Flow'}
          </button>

          {/* Export Dropdown */}
          <div className="relative">
            <button
              onClick={() => setExportMenuOpen(!exportMenuOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-border bg-card hover:bg-muted rounded-lg text-xs font-semibold transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> Export <ChevronDown className="w-3 h-3 ml-0.5" />
            </button>
            {exportMenuOpen && (
              <div className="absolute right-0 mt-1 w-40 bg-card border border-border rounded-xl shadow-xl z-50 py-1 text-xs">
                {(['PNG', 'SVG', 'PDF', 'Mermaid', 'Draw.io', 'PlantUML'] as ExportFormat[]).map(fmt => (
                  <button
                    key={fmt}
                    onClick={() => handleExport(fmt)}
                    className="w-full text-left px-3 py-1.5 hover:bg-primary/10 hover:text-primary transition-colors flex items-center justify-between"
                  >
                    <span>{fmt} Format</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {editMode ? (
            <button
              onClick={saveChanges}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-semibold hover:bg-emerald-700 transition-colors shadow"
            >
              <Save className="w-3.5 h-3.5" /> Save Flow
            </button>
          ) : (
            <button
              onClick={() => { setEditMode(true); toast.info('Flow Edit Mode enabled') }}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-semibold hover:opacity-90 transition-opacity shadow"
            >
              <Edit2 className="w-3.5 h-3.5" /> Edit Flow
            </button>
          )}
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-1 bg-card rounded-xl border border-border p-1.5 flex-wrap">
        {editMode && (
          <>
            <button
              onClick={() => setShowAddDialog(true)}
              className="flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold text-primary hover:bg-primary/10 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Add Node
            </button>
            {selectedNode && (
              <button
                onClick={deleteSelectedNode}
                className="flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold text-red-500 hover:bg-red-50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete Selected Node
              </button>
            )}
            {selectedEdge && (
              <button
                onClick={deleteSelectedEdge}
                className="flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-semibold text-red-500 hover:bg-red-50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete Selected Line
              </button>
            )}
          </>
        )}
      </div>

      {/* Node inspector panel when selected */}
      {selectedNode && editMode && (
        <div className="bg-card rounded-xl border border-border p-3 flex items-center justify-between gap-3 text-xs shadow-sm">
          <div className="flex items-center gap-2 flex-1">
            <span className="font-semibold text-muted-foreground">Edit Label:</span>
            <input
              type="text"
              value={(selectedNode.data as any)?.label || ''}
              onChange={e => renameNode(selectedNode.id, e.target.value)}
              className="px-2 py-1 rounded border border-border bg-background outline-none text-xs font-medium max-w-xs"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="font-semibold text-muted-foreground">Connect To:</span>
            <select
              value={connectTargetId}
              onChange={e => setConnectTargetId(e.target.value)}
              className="px-2 py-1 rounded border border-border bg-background text-xs outline-none"
            >
              <option value="">Select target node...</option>
              {nodes.filter(n => n.id !== selectedNode.id).map(n => (
                <option key={n.id} value={n.id}>{(n.data as any)?.label}</option>
              ))}
            </select>
            <input
              type="text"
              placeholder="Edge label (optional)"
              value={connectLabel}
              onChange={e => setConnectLabel(e.target.value)}
              className="px-2 py-1 rounded border border-border bg-background text-xs outline-none w-36"
            />
            <button
              onClick={handleConnectButton}
              disabled={!connectTargetId}
              className="px-3 py-1 rounded bg-primary text-primary-foreground font-semibold disabled:opacity-50 text-xs"
            >
              Link
            </button>
          </div>
        </div>
      )}

      {/* React Flow Canvas */}
      <div id="business-flow-canvas" className="h-[550px] bg-card rounded-xl border border-border overflow-hidden relative shadow-inner">
        {nodes.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold">No Business Flow Generated Yet</h3>
              <p className="text-xs text-muted-foreground mt-1 max-w-md">
                Generate an automated process flow diagram derived from your project requirements using AI.
              </p>
            </div>
            <button
              onClick={handleRegenerateFlow}
              disabled={isRegenerating}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity shadow cursor-pointer"
            >
              {isRegenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Generate Business Flow
            </button>
          </div>
        ) : (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={editMode ? onNodesChange : undefined}
            onEdgesChange={editMode ? onEdgesChange : undefined}
            onConnect={editMode ? onConnect : undefined}
            onNodeClick={onNodeClick}
            onEdgeClick={onEdgeClick}
            nodeTypes={nodeTypes}
            fitView
          >
            <Background variant={BackgroundVariant.Dots} gap={16} size={1} />
            <Controls />
            <MiniMap nodeStrokeWidth={3} zoomable pannable className="!bg-card !border-border" />
            <Panel position="top-right" className="bg-card/90 backdrop-blur border border-border px-3 py-1.5 rounded-lg text-[10px] text-muted-foreground shadow-sm">
              Interactive Business Flow Canvas
            </Panel>
          </ReactFlow>
        )}
      </div>

      {/* Add Node Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-sm w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-sm font-bold">Add Process Node</h3>
              <button onClick={() => setShowAddDialog(false)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Node Name</label>
                <input
                  type="text"
                  value={newNodeName}
                  onChange={e => setNewNodeName(e.target.value)}
                  placeholder="E.g., Validate Payroll Matrix"
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Description</label>
                <input
                  type="text"
                  value={newNodeDesc}
                  onChange={e => setNewNodeDesc(e.target.value)}
                  placeholder="E.g., Check employee salary tiers"
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Node Category Color</label>
                <div className="flex gap-2 mt-1.5">
                  {['#3B82F6', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444'].map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewNodeColor(c)}
                      className={cn('w-6 h-6 rounded-full border-2', newNodeColor === c ? 'border-primary scale-110' : 'border-transparent')}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 border-t border-border pt-3">
              <button onClick={() => setShowAddDialog(false)} className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium">Cancel</button>
              <button onClick={addCustomNode} className="px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold">Add Node</button>
            </div>
          </div>
        </div>
      )}

      {/* Version History Modal */}
      {showVersionModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-lg w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <History className="w-4 h-4 text-primary" /> Flow Version History
              </h3>
              <button onClick={() => setShowVersionModal(false)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
              {flowVersions.length === 0 ? (
                <div className="text-center py-6 text-xs text-muted-foreground">
                  No previous flow version snapshots found.
                </div>
              ) : (
                flowVersions.map(v => (
                  <div key={v.id} className="p-3 rounded-lg border border-border bg-muted/20 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-primary">Version v{v.version}</span>
                      <span className="text-[10px] text-muted-foreground">{new Date(v.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-xs font-medium text-foreground">{v.changeSummary}</p>
                    <div className="flex justify-between items-center text-[10px] text-muted-foreground pt-1 border-t border-border/40">
                      <span>Author: <strong className="text-foreground">{v.author}</strong></span>
                      <button
                        onClick={async () => {
                          await restoreFlowVersion(v)
                          setShowVersionModal(false)
                          toast.success(`Restored Flow Version v${v.version}!`)
                        }}
                        className="text-xs text-primary font-semibold hover:underline"
                      >
                        Restore Snapshot
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end border-t border-border pt-3">
              <button onClick={() => setShowVersionModal(false)} className="px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Regeneration Progress Modal */}
      <RegenerationProgressModal
        isOpen={showProgressModal}
        title="Regenerating Business Flow"
        currentStep={progressStep}
        error={regenerationError}
        onClose={() => setShowProgressModal(false)}
        onRetry={handleRegenerateFlow}
      />
    </div>
  )
}
