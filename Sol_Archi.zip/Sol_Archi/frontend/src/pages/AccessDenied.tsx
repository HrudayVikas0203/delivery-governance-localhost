import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { ShieldAlert, LogOut, ArrowLeft } from 'lucide-react'

export default function AccessDenied() {
  const navigate = useNavigate()
  const { currentUser, logout } = useAuth()

  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-foreground bg-background animate-scale-in">
      <div className="max-w-md w-full bg-card border border-border rounded-2xl shadow-xl p-8 text-center space-y-6">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-500/10 text-red-500">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <h2 className="text-xl font-bold tracking-tight">Access Denied</h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            You do not have the required authorization permissions to access this page. If you believe this is in error, contact your IT Systems Admin.
          </p>
        </div>

        <div className="bg-muted/40 rounded-xl p-4 border border-border/40 font-mono text-left text-xs space-y-2">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Active Profile:</span>
            <span className="font-semibold">{currentUser?.name || 'Unknown User'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Assigned Role:</span>
            <span className="font-bold text-red-500">{currentUser?.role || 'Guest'}</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 pt-2">
          <button
            onClick={() => navigate('/')}
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 bg-primary text-primary-foreground rounded-lg text-xs font-semibold hover:opacity-90 transition-opacity"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Return to Dashboard
          </button>
          
          <button
            onClick={() => {
              logout()
              navigate('/signin')
            }}
            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 border border-border rounded-lg text-xs font-semibold hover:bg-red-500/10 hover:text-red-500 hover:border-red-500/30 transition-all text-muted-foreground"
          >
            <LogOut className="w-3.5 h-3.5" /> Switch Account
          </button>
        </div>
      </div>
    </div>
  )
}
