import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { useApp } from '@/context/AppContext'
import { useDocuments } from '@/context/DocumentContext'
import { backendApi, type BackendChatSource } from '@/services/backendApi'
import {
  Send, Bot, User, Sparkles, MessageSquare, Plus, Trash2, BookOpen
} from 'lucide-react'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  sources?: BackendChatSource[]
}

interface ChatSession {
  id: string
  title: string
  createdAt: Date
  messages: Message[]
}

type PersistedMessage = {
  id?: unknown
  role?: unknown
  content?: unknown
  timestamp?: unknown
  sources?: unknown
}

type PersistedSession = {
  id?: unknown
  title?: unknown
  createdAt?: unknown
  messages?: unknown
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function toDate(value: unknown, fallback: Date): Date {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value
  }

  if (typeof value === 'string' || typeof value === 'number') {
    const parsed = new Date(value)
    if (!Number.isNaN(parsed.getTime())) {
      return parsed
    }
  }

  return fallback
}

function isBackendChatSource(value: unknown): value is BackendChatSource {
  if (!isRecord(value)) {
    return false
  }

  return (
    typeof value.documentId === 'string' &&
    typeof value.documentName === 'string' &&
    typeof value.chunkNumber === 'number' &&
    typeof value.chunkContent === 'string' &&
    typeof value.similarityScore === 'number'
  )
}

function normalizeMessage(value: unknown): Message | null {
  if (!isRecord(value)) {
    return null
  }

  const raw = value as PersistedMessage
  if (typeof raw.id !== 'string' || (raw.role !== 'user' && raw.role !== 'assistant') || typeof raw.content !== 'string') {
    return null
  }

  return {
    id: raw.id,
    role: raw.role,
    content: raw.content,
    timestamp: toDate(raw.timestamp, new Date()),
    sources: Array.isArray(raw.sources) ? raw.sources.filter((source): source is BackendChatSource => isBackendChatSource(source)) : undefined,
  }
}

function normalizeSession(value: unknown): ChatSession | null {
  if (!isRecord(value)) {
    return null
  }

  const raw = value as PersistedSession
  if (typeof raw.id !== 'string' || typeof raw.title !== 'string' || !Array.isArray(raw.messages)) {
    return null
  }

  const messages = raw.messages
    .map((message) => normalizeMessage(message))
    .filter((message): message is Message => message !== null)

  if (messages.length === 0) {
    return null
  }

  return {
    id: raw.id,
    title: raw.title,
    createdAt: toDate(raw.createdAt, messages[0].timestamp),
    messages,
  }
}

function formatMessageTime(timestamp: Date | string): string {
  const parsed = toDate(timestamp, new Date())
  return parsed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

function createWelcomeMessage(projectName: string, projectId: string, content?: string): Message {
  return {
    id: `welcome-${projectId}-${Date.now()}`,
    role: 'assistant',
    content: content ?? `Hello! I am your AI Solution Architect Copilot for **${projectName}**. Ask me any question about your uploaded project documents, requirements, architecture, or database design.`,
    timestamp: new Date(),
  }
}

function createDefaultSession(projectId: string, projectName: string): ChatSession {
  return {
    id: `session-default-${projectId}`,
    title: 'Current Analysis',
    createdAt: new Date(),
    messages: [createWelcomeMessage(projectName, projectId)],
  }
}

function loadSessionsFromStorage(storageKey: string, fallbackSession: ChatSession): ChatSession[] {
  try {
    const saved = localStorage.getItem(storageKey)
    if (!saved) {
      return [fallbackSession]
    }

    const parsed: unknown = JSON.parse(saved)
    if (!Array.isArray(parsed)) {
      return [fallbackSession]
    }

    const normalized = parsed
      .map((session) => normalizeSession(session))
      .filter((session): session is ChatSession => session !== null)

    return normalized.length > 0 ? normalized : [fallbackSession]
  } catch (error) {
    console.error('Failed to load chat sessions:', error)
    return [fallbackSession]
  }
}

const chatSuggestions = [
  'Summarize the uploaded requirements for this project.',
  'What business flow steps are currently documented?',
  'List the main architecture components and integrations.',
  'What database entities are implied by the requirements?',
]

export default function AiChat() {
  const { state } = useApp()
  const { activeProject, activeProjectId } = useDocuments()
  const { aiConfig } = state

  const storageKey = `copilot_chat_sessions_${activeProjectId}`
  const activeProjectName = activeProject?.name ?? 'Current Project'

  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const fallbackSession = createDefaultSession(activeProjectId, activeProjectName)
    return loadSessionsFromStorage(storageKey, fallbackSession)
  })

  const [activeSessionId, setActiveSessionId] = useState<string>(`session-default-${activeProjectId}`)
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fallbackSession = createDefaultSession(activeProjectId, activeProjectName)
    const loadedSessions = loadSessionsFromStorage(storageKey, fallbackSession)
    setSessions(loadedSessions)
    setActiveSessionId((currentId) => {
      const hasCurrentSession = loadedSessions.some((session) => session.id === currentId)
      return hasCurrentSession ? currentId : loadedSessions[0].id
    })
  }, [activeProjectId, activeProjectName, storageKey])

  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem(storageKey, JSON.stringify(sessions))
    }
  }, [sessions, storageKey])

  const activeSession = sessions.find((session) => session.id === activeSessionId) || sessions[0] || createDefaultSession(activeProjectId, activeProjectName)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [activeSession.messages, isTyping])

  const createNewSession = () => {
    const newSess: ChatSession = {
      id: `session-${Date.now()}`,
      title: `Conversation ${sessions.length + 1}`,
      createdAt: new Date(),
      messages: [
        createWelcomeMessage(
          activeProjectName,
          activeProjectId,
          `Hello! I am your AI Solution Architect Copilot for **${activeProjectName}**. Ask me about BRD requirements, business flows, architecture design, or database schemas.`,
        ),
      ],
    }
    setSessions((prev) => [newSess, ...prev])
    setActiveSessionId(newSess.id)
  }

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (sessions.length <= 1) return
    const updated = sessions.filter((session) => session.id !== id)
    setSessions(updated)
    if (activeSessionId === id) {
      setActiveSessionId(updated[0].id)
    }
  }

  const sendMessage = async (content: string) => {
    if (!content.trim() || isTyping) return

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: content.trim(),
      timestamp: new Date(),
    }

    setSessions((prev) => prev.map((session) => {
      if (session.id === activeSessionId) {
        return {
          ...session,
          messages: [...session.messages, userMsg],
          title: session.messages.length <= 1 ? content.slice(0, 25) : session.title,
        }
      }
      return session
    }))

    setInput('')
    setIsTyping(true)

    try {
      const chatResult = await backendApi.queryProjectChat(
        activeProjectId,
        activeSessionId,
        content,
        activeSession.messages.map((message) => ({ role: message.role, content: message.content })),
        aiConfig,
        activeProject,
      )

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: chatResult.answer,
        timestamp: new Date(),
        sources: chatResult.sources,
      }

      setSessions((prev) => prev.map((session) => {
        if (session.id === activeSessionId) {
          return { ...session, messages: [...session.messages, assistantMsg] }
        }
        return session
      }))
    } catch (error) {
      console.error('Chat error:', error)
      const message = error instanceof Error ? error.message : 'AI provider unavailable'
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: message,
        timestamp: new Date(),
      }

      setSessions((prev) => prev.map((session) => {
        if (session.id === activeSessionId) {
          return { ...session, messages: [...session.messages, assistantMsg] }
        }
        return session
      }))
    } finally {
      setIsTyping(false)
    }
  }

  return (
    <div className="animate-fade-in flex flex-col lg:flex-row gap-4 h-[calc(100vh-185px)] lg:h-[calc(100vh-150px)] min-h-[480px] overflow-hidden text-foreground">
      {/* Sessions Sidebar */}
      <div className="w-full lg:w-64 bg-card rounded-xl border border-border p-3 flex flex-col justify-between shrink-0 h-44 lg:h-full">
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h4 className="text-xs font-bold flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-primary" /> Chat Sessions
            </h4>
            <button
              onClick={createNewSession}
              className="p-1 rounded bg-primary/10 hover:bg-primary/20 text-primary transition-colors text-xs flex items-center gap-1 font-semibold"
              title="New Session"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-1 overflow-y-auto max-h-[260px] lg:max-h-[500px]">
            {sessions.map((session) => (
              <div
                key={session.id}
                onClick={() => setActiveSessionId(session.id)}
                className={cn(
                  'flex items-center justify-between px-3 py-2 rounded-lg text-xs transition-all cursor-pointer group',
                  activeSessionId === session.id
                    ? 'bg-primary text-primary-foreground font-semibold shadow-sm'
                    : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                )}
              >
                <span className="truncate max-w-[140px]">{session.title}</span>
                {sessions.length > 1 && (
                  <button
                    onClick={(e) => deleteSession(session.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-opacity"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="pt-2 border-t border-border text-[10px] text-muted-foreground flex items-center justify-between font-mono">
          <span>Engine: <strong>{aiConfig.provider}</strong></span>
          <span>RAG Active</span>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-card rounded-xl border border-border overflow-hidden h-[450px] lg:h-full">
        {/* Chat Header */}
        <div className="px-5 py-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-semibold flex items-center gap-2">
                AI Solution Architect Copilot
                <span className="text-[9px] font-mono font-semibold bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded-full">
                  RAG Vector Store Active
                </span>
              </h3>
              <p className="text-[10px] text-muted-foreground">
                Document-aware analysis for: <strong className="text-foreground">{activeProjectName}</strong>
              </p>
            </div>
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activeSession.messages.map((msg) => (
            <div key={msg.id} className={cn('flex gap-3', msg.role === 'user' && 'flex-row-reverse')}>
              <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0',
                msg.role === 'user' ? 'bg-primary' : 'bg-gradient-to-br from-primary to-purple-600'
              )}>
                {msg.role === 'user' ? <User className="w-3.5 h-3.5 text-white" /> : <Bot className="w-3.5 h-3.5 text-white" />}
              </div>
              <div className={cn(
                'max-w-[80%] rounded-xl px-4 py-3 text-sm space-y-2',
                msg.role === 'user'
                  ? 'bg-primary text-primary-foreground rounded-tr-sm'
                  : 'bg-muted/50 border border-border/60 rounded-tl-sm text-foreground'
              )}>
                <div className="whitespace-pre-wrap leading-relaxed text-xs md:text-sm">{msg.content}</div>

                {/* RAG Context Sources */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="pt-2 border-t border-border/40 text-[10px] space-y-1">
                    <span className="font-semibold text-muted-foreground uppercase flex items-center gap-1">
                      <BookOpen className="w-3 h-3 text-primary" /> RAG Retrieved Context Sources ({msg.sources.length}):
                    </span>
                    <div className="flex flex-col gap-1">
                      {msg.sources.map((src, i) => (
                        <div key={i} className="bg-background border border-border px-2 py-1 rounded font-mono text-muted-foreground text-[10px] flex items-center justify-between gap-2">
                          <span className="font-semibold text-foreground truncate max-w-[220px]">
                            [{src.documentName}] Chunk {src.chunkNumber}
                          </span>
                          <span className="text-[9px] text-primary font-bold">Score: {src.similarityScore}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <p className={cn('text-[9px]', msg.role === 'user' ? 'text-primary-foreground/60' : 'text-muted-foreground/60')}>
                  {formatMessageTime(msg.timestamp)}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 text-white animate-pulse" />
              </div>
              <div className="bg-muted/50 border border-border/60 rounded-xl rounded-tl-sm px-4 py-3 flex items-center gap-2 text-xs text-muted-foreground">
                <Sparkles className="w-3.5 h-3.5 text-primary animate-spin" />
                Searching vector embeddings & generating architectural response...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Suggestions Bar */}
        <div className="px-4 py-2 border-t border-border flex gap-2 overflow-x-auto bg-muted/10">
          {chatSuggestions.map((suggestion, i) => (
            <button
              key={i}
              onClick={() => sendMessage(suggestion)}
              className="flex-shrink-0 text-[11px] px-3 py-1 rounded-full border border-border text-muted-foreground hover:border-primary hover:text-primary transition-colors cursor-pointer bg-card"
            >
              {suggestion}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form
          onSubmit={(e) => { e.preventDefault(); sendMessage(input) }}
          className="px-4 py-3 border-t border-border"
        >
          <div className="flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask AI Copilot about ${activeProjectName}...`}
              className="flex-1 px-4 py-2.5 rounded-xl border border-border bg-background text-xs md:text-sm outline-none focus:border-primary transition-colors"
            />
            <button
              type="submit"
              disabled={!input.trim() || isTyping}
              className="px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-xs md:text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-4 h-4" /> Send
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
