import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { cn } from '@/lib/utils'
import { useApp } from '@/context/AppContext'
import { useDocuments } from '@/context/DocumentContext'
import {
  FileText, ListChecks, Boxes, Brain,
  Upload, Cpu, ShieldCheck, Download, MessageSquare,
  FileCheck, GitBranch, Files,
  Activity, LayoutGrid, Plus, Settings
} from 'lucide-react'
import { monitoring } from '@/services/monitoringService'

const quickActions = [
  { label: 'Upload Document', icon: Upload, path: '/upload', color: 'from-blue-500 to-blue-600' },
  { label: 'Generate Architecture', icon: Cpu, path: '/architecture', color: 'from-purple-500 to-purple-600' },
  { label: 'Run Validation', icon: ShieldCheck, path: '/architecture', color: 'from-emerald-500 to-emerald-600' },
  { label: 'Export Package', icon: Download, path: '/export', color: 'from-orange-500 to-orange-600' },
  { label: 'AI Chat', icon: MessageSquare, path: '/ai-chat', color: 'from-pink-500 to-pink-600' },
]

function CircularProgress({ value, size = 44, stroke = 4 }: { value: number; size?: number; stroke?: number }) {
  const r = (size - stroke) / 2
  const circ = 2 * Math.PI * r
  const offset = circ - (value / 100) * circ
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={stroke} className="text-muted/50" />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={stroke}
        strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round"
        className="text-primary transition-all duration-1000" />
    </svg>
  )
}

export default function Dashboard() {
  const navigate = useNavigate()
  const { state } = useApp()
  const {
    documentData,
    activeProject,
    availableDocuments,
    dbRequirements,
    dbDocuments,
    dbFlow,
    dbArchitecture,
    flowVersions,
    architectureVersions
  } = useDocuments()

  const [hoveredKpi, setHoveredKpi] = useState<number | null>(null)

  const { documentInfo, requirements, businessFlow } = documentData
  const { aiConfig } = state

  const safeModules = requirements?.modules ?? []
  const safeFunctional = requirements?.functional ?? []
  const safeNonFunctional = requirements?.nonFunctional ?? []
  const safeFlowNodes = businessFlow?.nodes ?? []

  void monitoring.sendTelemetry({
    location: 'Dashboard.tsx:render',
    message: 'Dashboard data snapshot',
    data: {
      modulesCount: safeModules.length,
      modulesWithMissingName: safeModules.filter(m => !m?.name).length,
      functionalCount: safeFunctional.length,
      flowNodesCount: safeFlowNodes.length,
    },
    hypothesisId: 'A',
    runId: 'pre-fix',
  })

  // Calculate version counts & last generated timestamp
  const totalDesignVersions = (flowVersions?.length ?? 0) + (architectureVersions?.length ?? 0)
  const lastGeneratedDate = dbArchitecture?.updatedAt || dbFlow?.updatedAt || activeProject.createdAt

  // Compile KPI Cards using real DB and Context metrics
  const kpiCards = useMemo(() => {
    const totalDocs = Math.max(activeProject.documents?.length ?? 0, dbDocuments?.length ?? 0)
    const docTypes = Array.from(new Set((availableDocuments ?? []).map(d => d?.type).filter(Boolean)))
    const docTypesStr = docTypes.length > 0 ? docTypes.join(', ') : 'None'

    const totalReqs = safeFunctional.length + safeNonFunctional.length
    const modulesCount = safeModules.length
    const flowStepsCount = safeFlowNodes.length
    const avgConfidence = dbRequirements ? 96 : (documentInfo?.confidence ?? 0)

    const pendingDocs = (dbDocuments ?? []).filter(d => d?.status === 'Processing' || d?.status === 'Pending').length
    const statusLabel = pendingDocs > 0 ? 'Processing Active' : 'Completed'

    return [
      { label: 'Total Documents', value: totalDocs, icon: Files, trend: `${documentInfo?.pages ?? 0} total pages`, color: 'text-blue-500', bg: 'bg-blue-500/10' },
      { label: 'Document Types', value: docTypes.length, icon: FileText, trend: docTypesStr, color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
      { label: 'Total Requirements', value: totalReqs, icon: ListChecks, trend: `${statusLabel} status`, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
      { label: 'Business Modules', value: modulesCount, icon: Boxes, trend: modulesCount > 0 ? 'All segments analyzed' : 'No modules yet', color: 'text-purple-500', bg: 'bg-purple-500/10' },
      { label: 'Generated Flows', value: flowStepsCount, icon: GitBranch, trend: flowStepsCount > 0 ? `v${dbFlow?.version || 1} flow snapshot` : 'Not generated', color: 'text-amber-500', bg: 'bg-amber-500/10' },
      { label: 'Overall AI Confidence', value: avgConfidence, icon: Brain, trend: 'AI Confidence score', color: 'text-indigo-500', bg: 'bg-indigo-500/10', isPercent: true },
    ]
  }, [activeProject, availableDocuments, safeFunctional, safeNonFunctional, safeModules, safeFlowNodes, documentInfo, dbRequirements, dbDocuments, dbFlow])

  return (
    <div className="space-y-6 animate-fade-in text-foreground">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Project Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">Enterprise AI Solution Design Overview</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Active AI Config Badge */}
          <button
            onClick={() => navigate('/settings')}
            className="flex items-center gap-2 text-xs bg-primary/10 border border-primary/20 hover:border-primary/50 text-primary px-3 py-1.5 rounded-full cursor-pointer transition-all shadow-sm group"
            title="Click to view & configure AI models"
          >
            <Cpu className="w-3.5 h-3.5 animate-pulse text-primary" />
            <div className="flex items-center gap-1 font-mono">
              <span className="text-[10px] text-muted-foreground font-semibold uppercase">Engine:</span>
              <span className="font-bold text-foreground group-hover:text-primary transition-colors">{aiConfig.provider}</span>
              <span className="text-muted-foreground/60">•</span>
              <span className="text-primary font-medium">{aiConfig.defaultModel}</span>
            </div>
            <Settings className="w-3 h-3 text-muted-foreground group-hover:rotate-45 transition-transform ml-0.5" />
          </button>

          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-full border border-border">
            <Activity className="w-3.5 h-3.5 text-emerald-500" />
            Selected Project: <span className="font-semibold text-foreground">{activeProject.name}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
        {kpiCards.map((kpi, i) => {
          const Icon = kpi.icon
          return (
            <div
              key={i}
              onMouseEnter={() => setHoveredKpi(i)}
              onMouseLeave={() => setHoveredKpi(null)}
              className={cn(
                'bg-card rounded-xl border border-border p-3.5 transition-all duration-300 cursor-default flex flex-col justify-between',
                hoveredKpi === i && 'shadow-lg border-primary/30 -translate-y-0.5'
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center', kpi.bg)}>
                  <Icon className={cn('w-4 h-4', kpi.color)} />
                </div>
                {kpi.isPercent && <CircularProgress value={typeof kpi.value === 'number' ? kpi.value : 0} size={28} stroke={2.5} />}
              </div>
              <div>
                <p className="text-xl font-bold leading-tight">{kpi.value}{kpi.isPercent ? '%' : ''}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5 font-medium truncate">{kpi.label}</p>
              </div>
              <p className="text-[9px] text-muted-foreground mt-2 border-t border-border/40 pt-1.5 truncate" title={kpi.trend}>
                {kpi.trend}
              </p>
            </div>
          )
        })}
      </div>

      {/* Project Summary Widget */}
      <div>
        <div className="bg-card rounded-xl border border-border p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 rounded bg-primary/10 flex items-center justify-center text-primary">
                <LayoutGrid className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-semibold">Project Summary & Status</h3>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Project Name</p>
                <p className="font-semibold text-foreground mt-0.5 truncate">{activeProject.name}</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Design Artifact Snapshots</p>
                <p className="text-muted-foreground mt-0.5 font-mono text-[11px]">
                  {totalDesignVersions > 0 ? `${totalDesignVersions} version snapshots recorded` : 'Initial v1 design models active'}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 border-t border-border/50 pt-2 mt-2">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase">Tech Stack</p>
                  <p className="font-medium text-foreground mt-0.5 truncate" title={activeProject.selectedTechStack}>{activeProject.selectedTechStack}</p>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase">Database</p>
                  <p className="font-medium text-foreground mt-0.5 truncate">{activeProject.selectedDatabase}</p>
                </div>
              </div>
              <div className="flex justify-between items-center border-t border-border/50 pt-2 mt-2">
                <span className="text-[10px] text-muted-foreground uppercase">Last Generated</span>
                <span className="font-medium text-muted-foreground text-[10px]">{new Date(lastGeneratedDate).toLocaleString()}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => navigate('/export')}
            className="w-full mt-4 py-2 text-xs font-semibold rounded-lg bg-primary/15 text-primary hover:bg-primary/25 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" /> Open Export Center
          </button>
        </div>
      </div>

      {/* Active AI Engine Banner & Model Mapping Overview */}
      <div className="bg-card rounded-xl border border-border p-4 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border/50 pb-2.5">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-foreground flex items-center gap-2">
                Active AI Engine Traceability
                <span className="text-[9px] font-semibold bg-primary/10 text-primary px-2 py-0.5 rounded-full font-mono">
                  {aiConfig.provider}
                </span>
              </h3>
              <p className="text-[10px] text-muted-foreground">
                Current active LLM provider and target model mapping across architecture services
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate('/settings')}
            className="self-start sm:self-center text-xs font-medium text-primary hover:underline flex items-center gap-1 bg-primary/5 px-2.5 py-1 rounded-lg border border-primary/20"
          >
            <Settings className="w-3 h-3" /> Change AI Configuration
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 pt-1">
          {[
            { label: 'Req. Extraction', model: aiConfig.moduleModels.requirementExtraction },
            { label: 'Business Flow', model: aiConfig.moduleModels.businessFlow },
            { label: 'Architecture', model: aiConfig.moduleModels.architecture },
            { label: 'AI Chat', model: aiConfig.moduleModels.aiChat },
          ].map((item, idx) => (
            <div key={idx} className="bg-muted/30 border border-border/60 rounded-lg p-2 flex flex-col justify-between">
              <span className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider truncate">{item.label}</span>
              <span className="text-xs font-mono font-bold text-primary truncate mt-0.5" title={item.model}>
                {item.model}
              </span>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-1 border-t border-border/40 font-mono">
          <span>Provider: <strong className="text-foreground">{aiConfig.provider}</strong></span>
          <span>Temp: <strong className="text-foreground">{aiConfig.temperature}</strong></span>
          <span>Max Tokens: <strong className="text-foreground">{aiConfig.maxTokens}</strong></span>
          <span>Format: <strong className="text-foreground">{aiConfig.responseFormat}</strong></span>
        </div>
      </div>

      {/* Bottom Row: Recent Documents + Recent Activity + Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent Documents Widget */}
        <div className="bg-card rounded-xl border border-border p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold">Project Documents ({availableDocuments.length})</h3>
              </div>
              <button
                onClick={() => navigate('/upload')}
                className="text-[10px] text-primary hover:underline font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" /> Add Document
              </button>
            </div>

            <div className="space-y-3 max-h-[190px] overflow-y-auto pr-1">
              {availableDocuments.length === 0 ? (
                <div className="text-center py-6 text-xs text-muted-foreground">
                  No documents uploaded yet. Upload a document to get started.
                </div>
              ) : availableDocuments.map((doc) => {
                const dbDoc = dbDocuments.find(d => d.id === doc.id)

                return (
                  <div key={doc.id} className="flex items-start justify-between p-2 rounded-lg bg-muted/30 border border-border/50 hover:border-primary/20 transition-all">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold truncate text-foreground">{doc.name ?? 'Untitled'}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5 flex items-center gap-1.5">
                        <span>{doc.type ?? '—'}</span>
                        {dbDoc && (
                          <>
                            <span>•</span>
                            <span>{dbDoc.pages ?? 0} pages</span>
                            <span>•</span>
                            <span>{dbDoc.size ?? '—'}</span>
                          </>
                        )}
                      </p>
                    </div>
                    {dbDoc && (
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-600 px-1.5 py-0.5 rounded font-medium ml-2">
                        {dbDoc.confidence ?? 0}%
                      </span>
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          <button
            onClick={() => navigate('/upload')}
            className="w-full mt-4 py-2 text-xs font-semibold rounded-lg bg-muted border border-border hover:bg-muted/80 transition-colors cursor-pointer"
          >
            Upload & Analyze Document
          </button>
        </div>

        {/* Recent AI Activity */}
        <div className="bg-card rounded-xl border border-border overflow-hidden flex flex-col justify-between p-5">
          <div>
            <h3 className="text-sm font-semibold mb-3">Recent AI Activity</h3>
            <div className="space-y-3 max-h-[200px] overflow-y-auto pr-1">
              {[
                { id: 'a1', action: 'Documents Synced', detail: `${availableDocuments.length} backend document(s) loaded for the active project.` },
                { id: 'a2', action: 'Requirements Ready', detail: safeFunctional.length + safeNonFunctional.length > 0 ? `${safeFunctional.length + safeNonFunctional.length} requirements available for review.` : 'No requirements generated yet.' },
                { id: 'a3', action: 'Business Flow Snapshot', detail: safeFlowNodes.length > 0 ? `${safeFlowNodes.length} flow nodes currently stored.` : 'Business flow not generated yet.' },
              ].map((activity, i) => (
                <div key={activity.id} className="flex gap-2.5 relative pb-1">
                  {i < 2 && <div className="absolute left-[11px] top-[26px] bottom-0 w-px bg-border" />}
                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 z-10">
                    <Activity className="w-3 h-3 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium">{activity.action}</p>
                    <p className="text-[9px] text-muted-foreground mt-0.5 truncate">{activity.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-card rounded-xl border border-border overflow-hidden p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold mb-3">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-2.5">
              {quickActions.map((action, i) => {
                const Icon = action.icon
                return (
                  <button
                    key={i}
                    onClick={() => navigate(action.path)}
                    className="flex flex-col items-center gap-1.5 p-2 rounded-xl border border-border hover:border-primary/30 hover:shadow-md transition-all duration-200 group bg-muted/20 cursor-pointer"
                  >
                    <div className={cn('w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center text-white transition-transform group-hover:scale-105', action.color)}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-[10px] font-semibold text-center truncate w-full">{action.label}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
