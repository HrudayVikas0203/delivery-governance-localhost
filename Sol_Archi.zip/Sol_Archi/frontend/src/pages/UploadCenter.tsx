import { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDropzone } from 'react-dropzone'
import { cn } from '@/lib/utils'
import { useDocuments } from '@/context/DocumentContext'
import {
  FileText, CheckCircle2, Loader2, CloudUpload, File,
  ArrowRight, Sparkles, AlertCircle, RefreshCw
} from 'lucide-react'
import { toast } from 'sonner'
import type { ProgressStep } from '@/services/documentProcessor'

type UploadState = 'idle' | 'uploading' | 'processing' | 'complete' | 'error'

const DEFAULT_STEPS: ProgressStep[] = [
  { id: '1', label: 'Uploading document to backend', status: 'pending' },
  { id: '2', label: 'Parsing PDF/DOCX structure', status: 'pending' },
  { id: '3', label: 'Running AI requirement extraction', status: 'pending' },
  { id: '4', label: 'Saving structured requirements', status: 'pending' },
  { id: '5', label: 'Generating business flow', status: 'pending' },
  { id: '6', label: 'Generating solution architecture', status: 'pending' },
]

export default function UploadCenter() {
  const navigate = useNavigate()
  const { loadDocument, activeDocId, availableDocuments, processUploadedFile } = useDocuments()
  const [uploadState, setUploadState] = useState<UploadState>('idle')
  const [uploadProgress, setUploadProgress] = useState(0)
  const [processingSteps, setProcessingSteps] = useState<ProgressStep[]>(DEFAULT_STEPS)
  const [fileName, setFileName] = useState('')
  const [errorMessage, setErrorMessage] = useState('')

  const handleFileProcess = async (file: File) => {
    setFileName(file.name)
    setUploadState('uploading')
    setUploadProgress(0)
    setErrorMessage('')
    setProcessingSteps(JSON.parse(JSON.stringify(DEFAULT_STEPS)))
    toast.info(`Uploading ${file.name}...`)

    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 85) {
          clearInterval(progressInterval)
          return 85
        }
        return prev + 15
      })
    }, 100)

    try {
      setUploadState('processing')
      setUploadProgress(100)
      await processUploadedFile(file, (steps) => {
        setProcessingSteps(steps)
      })
      clearInterval(progressInterval)
      setUploadState('complete')
      toast.success(`Successfully processed ${file.name}!`)
    } catch (err) {
      clearInterval(progressInterval)
      console.error(err)
      const msg = err instanceof Error ? err.message : 'Upload failed'
      setErrorMessage(msg)
      setUploadState('error')
      toast.error(msg)
    }
  }

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    if (rejectedFiles && rejectedFiles.length > 0) {
      const rej = rejectedFiles[0]
      const fileErr = rej.errors?.[0]?.message || 'Unsupported document format'
      toast.error(`File Rejected: ${fileErr}. Please upload a valid PDF or DOCX file.`)
      return
    }

    if (acceptedFiles.length === 0) return
    handleFileProcess(acceptedFiles[0])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    multiple: false,
    disabled: uploadState !== 'idle',
  })

  const reset = () => {
    setUploadState('idle')
    setUploadProgress(0)
    setProcessingSteps(DEFAULT_STEPS)
    setFileName('')
    setErrorMessage('')
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Upload Document</h1>
        <p className="text-sm text-muted-foreground mt-1">Upload BRD, HLRD, FRD, RFP, or SRS documents for AI analysis</p>
      </div>

      {/* Upload Area */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        {uploadState === 'idle' && (
          <div
            {...getRootProps()}
            className={cn(
              'p-12 flex flex-col items-center justify-center cursor-pointer transition-all duration-300 border-2 border-dashed rounded-xl m-4',
              isDragActive
                ? 'border-primary bg-primary/5 scale-[1.01]'
                : 'border-border hover:border-primary/40 hover:bg-muted/30'
            )}
          >
            <input {...getInputProps()} />
            <div className={cn(
              'w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 transition-transform',
              isDragActive && 'scale-110 animate-pulse-glow'
            )}>
              <CloudUpload className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-1">
              {isDragActive ? 'Drop your document here' : 'Drag & drop your document'}
            </h3>
            <p className="text-sm text-muted-foreground mb-4">or click to browse files</p>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground px-3 py-1.5 rounded-full bg-muted/50">
                <FileText className="w-3.5 h-3.5" /> PDF
              </span>
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground px-3 py-1.5 rounded-full bg-muted/50">
                <File className="w-3.5 h-3.5" /> DOCX
              </span>
            </div>
            <p className="text-[10px] text-muted-foreground/60 mt-3">Maximum file size: 50 MB</p>
          </div>
        )}

        {uploadState === 'uploading' && (
          <div className="p-12 flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <Loader2 className="w-7 h-7 text-primary animate-spin" />
            </div>
            <h3 className="text-lg font-semibold mb-1">Uploading Document</h3>
            <p className="text-sm text-muted-foreground mb-4">{fileName}</p>
            <div className="w-full max-w-md">
              <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
                <span>Progress</span>
                <span>{Math.min(Math.round(uploadProgress), 100)}%</span>
              </div>
              <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-blue-400 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(uploadProgress, 100)}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {uploadState === 'processing' && (
          <div className="p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary animate-pulse" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">AI Processing Engine</h3>
                <p className="text-xs text-muted-foreground">{fileName}</p>
              </div>
            </div>
            <div className="space-y-2 max-w-xl mx-auto">
              {processingSteps.map((step, i) => {
                const isCompleted = step.status === 'completed'
                const isCurrent = step.status === 'in_progress'
                const isPending = step.status === 'pending'
                const isFailed = step.status === 'failed'
                return (
                  <div
                    key={step.id}
                    className={cn(
                      'flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-500',
                      isCompleted && 'bg-emerald-500/5',
                      isCurrent && 'bg-primary/5',
                      isFailed && 'bg-red-500/5',
                      isPending && 'opacity-40'
                    )}
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    ) : isFailed ? (
                      <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                    ) : isCurrent ? (
                      <Loader2 className="w-5 h-5 text-primary animate-spin flex-shrink-0" />
                    ) : (
                      <div className="w-5 h-5 rounded-full border-2 border-border flex-shrink-0" />
                    )}
                    <span className={cn(
                      'text-sm',
                      isCompleted && 'text-emerald-600 font-medium',
                      isCurrent && 'text-primary font-medium',
                      isFailed && 'text-red-600 font-medium',
                      isPending && 'text-muted-foreground'
                    )}>
                      {step.label}
                    </span>
                    {isCurrent && (
                      <div className="ml-auto flex gap-0.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
            <div className="mt-4">
              <div className="h-1.5 bg-muted rounded-full overflow-hidden max-w-xl mx-auto">
                <div
                  className="h-full bg-gradient-to-r from-primary to-emerald-400 rounded-full transition-all duration-500"
                  style={{ width: `${((processingSteps.filter(s => s.status === 'completed').length + 0.5) / processingSteps.length) * 100}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {uploadState === 'complete' && (
          <div className="p-12 flex flex-col items-center animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-10 h-10 text-emerald-500" />
            </div>
            <h3 className="text-xl font-bold mb-1">Analysis Complete!</h3>
            <p className="text-sm text-muted-foreground mb-6">{fileName} processed and requirements extracted successfully</p>
            <div className="flex gap-3">
              <button
                onClick={() => navigate('/requirements')}
                className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
              >
                View Requirements <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={reset}
                className="flex items-center gap-2 px-5 py-2.5 border border-border rounded-lg text-sm font-medium hover:bg-muted transition-colors"
              >
                Upload Another
              </button>
            </div>
          </div>
        )}

        {uploadState === 'error' && (
          <div className="p-12 flex flex-col items-center animate-scale-in">
            <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mb-4">
              <AlertCircle className="w-10 h-10 text-red-500" />
            </div>
            <h3 className="text-xl font-bold mb-1 text-red-600">Processing Failed</h3>
            <p className="text-xs text-muted-foreground max-w-md text-center mb-6 bg-red-500/10 text-red-700 p-3 rounded-lg border border-red-500/20 font-mono">
              {errorMessage}
            </p>
            <div className="flex gap-3">
              <button
                onClick={reset}
                className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
              >
                <RefreshCw className="w-4 h-4" /> Try Again
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Uploaded Documents */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold mb-3">Uploaded Documents</h3>
        {availableDocuments.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-6 text-center">
            <p className="text-sm font-medium">No documents uploaded yet</p>
            <p className="text-xs text-muted-foreground mt-1">Upload a BRD, HLRD, FRD, RFP, or SRS file to start backend analysis.</p>
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {availableDocuments.map((doc) => (
              <button
                key={doc.id}
                onClick={() => loadDocument(doc.id)}
                className={cn(
                  'px-4 py-3 rounded-lg text-xs font-medium border transition-all text-left',
                  activeDocId === doc.id
                    ? 'border-primary bg-primary/5 text-primary'
                    : 'border-border hover:bg-muted/50'
                )}
              >
                <div className="font-semibold truncate">{doc.name}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{doc.type}</div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
