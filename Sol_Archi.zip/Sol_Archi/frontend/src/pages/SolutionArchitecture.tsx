import { useState, useCallback, useEffect, useMemo } from 'react'
import { cn, getPriorityColor, getConfidenceBg } from '@/lib/utils'
import { useDocuments } from '@/context/DocumentContext'
import { useAuth } from '@/context/AuthContext'
import {
  ReactFlow, MiniMap, Controls, Background, useNodesState, useEdgesState,
  type Node, type Edge, Panel, BackgroundVariant, addEdge, Handle, Position,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { toast } from 'sonner'
import {
  CheckCircle2, X, Sparkles, Shield, Zap, AlertTriangle,
  Clock, Copy, Trash2, RotateCcw, GitCompare, BarChart3,
  ChevronRight, Server, Globe, Key, User, Target, Calendar,
  Bell, Database, HardDrive, Search, ArrowLeftRight, Activity,
  FileText, Brain, Layers, Cloud, Plus, Save, Undo2, Redo2, Cpu, Code,
  History, Download, ChevronDown, RefreshCw, Check, UserCog, Crown
} from 'lucide-react'
import type { ArchNode, ArchEdge, ExecutiveArchitectureData, ExecutiveTemplateId, ExecutiveThemeId } from '@/data/types'
import { exportDesignArtifactAPI } from '@/services/api'
import type { ExportFormat } from '@/services/exportService'
import { submitGovernanceReview } from '@/services/collaborationService'
import { RegenerationProgressModal } from '@/components/RegenerationProgressModal'
import { ExecutiveArchitectureCanvas, normalizeExecutiveArchitecture } from '@/components/ExecutiveArchitectureCanvas'

const layerColors: Record<string, string> = {
  Presentation: '#3B82F6',
  Middleware: '#8B5CF6',
  Backend: '#10B981',
  Data: '#F59E0B',
  Infrastructure: '#6B7280',
}

const iconMap: Record<string, React.ElementType> = {
  Users: User, Globe, Shield, Key, User, Target, Calendar, Bell,
  Database, Zap, HardDrive, Search, ArrowLeftRight, Activity, FileText, Brain, Cloud, Server,
  UserCog: User, Crown: User, Settings: Layers, DollarSign: Zap, BarChart3,
}

const tabs = ['Architecture Canvas', 'AI Recommendations', 'Technology Stack', 'Validation', 'Health Score', 'Version History']

// Custom Node Component with explicitly rendered connection handles
function CustomArchitectureNode({ data, selected }: any) {
  const layer = data.layer || 'Backend'
  const color = layerColors[layer] || '#6B7280'
  const Icon = iconMap[data.icon] || Server

  return (
    <div
      className={cn(
        'px-4 py-3 rounded-xl shadow-sm border-2 transition-all min-w-[160px] relative bg-card text-card-foreground',
        selected ? 'border-primary shadow-md ring-2 ring-primary/20 scale-[1.02]' : 'hover:border-primary/40'
      )}
      style={{ borderColor: selected ? undefined : color }}
    >
      <Handle
        type="target"
        position={Position.Top}
        className="!w-2 !h-2 !bg-muted-foreground !border-background"
        style={{ top: -5 }}
      />
      <div className="flex items-center gap-2.5">
        <div className="p-1.5 rounded-lg bg-muted flex items-center justify-center" style={{ color }}>
          <Icon className="w-4 h-4" />
        </div>
        <div className="text-left min-w-0">
          <p className="text-xs font-bold truncate">{data.label}</p>
          <p className="text-[9px] text-muted-foreground truncate">{data.technology || data.componentType}</p>
        </div>
      </div>
      <Handle
        type="source"
        position={Position.Bottom}
        className="!w-2 !h-2 !bg-muted-foreground !border-background"
        style={{ bottom: -5 }}
      />
    </div>
  )
}

export default function SolutionArchitecture() {
  const {
    documentData,
    updateArchitecture,
    activeProject,
    activeProjectId,
    activeDocId,
    updateProjectTechStackDetails,
    dbArchitecture,
    architectureVersions,
    triggerGenerateArchitecture,
    restoreArchitectureVersion,
  } = useDocuments()

  const { currentUser } = useAuth()

  const [activeTab, setActiveTab] = useState('Architecture Canvas')
  const [architectureView, setArchitectureView] = useState<'Executive' | 'Technical'>('Executive')
  const [currentTemplate, setCurrentTemplate] = useState<ExecutiveTemplateId>('enterpriseConsulting')
  const [currentTheme, setCurrentTheme] = useState<ExecutiveThemeId>('corporateBlue')
  const [expandedCapability, setExpandedCapability] = useState<string | null>(null)
  const [nodes, setNodes, onNodesChange] = useNodesState<Node>([])
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([])
  const [selectedNode, setSelectedNode] = useState<ArchNode | null>(null)
  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null)

  // Modals & Export state
  const [showVersionModal, setShowVersionModal] = useState(false)
  const [exportMenuOpen, setExportMenuOpen] = useState(false)
  const [isRegenerating, setIsRegenerating] = useState(false)
  const [showProgressModal, setShowProgressModal] = useState(false)
  const [progressStep, setProgressStep] = useState('Preparing project...')
  const [regenerationError, setRegenerationError] = useState<string | null>(null)

  const [frontend, setFrontend] = useState(activeProject.techStackDetails?.frontend || 'React 18 + TypeScript')
  const [backend, setBackend] = useState(activeProject.techStackDetails?.backend || '.NET 8 / C#')
  const [database, setDatabase] = useState(activeProject.techStackDetails?.database || 'SQL Server')
  const [authentication, setAuthentication] = useState(activeProject.techStackDetails?.authentication || 'Azure AD B2C')
  const [cloudPlatform, setCloudPlatform] = useState(activeProject.techStackDetails?.cloudPlatform || 'Azure')
  const [storage, setStorage] = useState(activeProject.techStackDetails?.storage || 'Azure Blob Storage')
  const [messaging, setMessaging] = useState(activeProject.techStackDetails?.messaging || 'Azure Service Bus')
  const [aiServices, setAiServices] = useState(activeProject.techStackDetails?.aiServices || 'Azure OpenAI')
  const [monitoring, setMonitoring] = useState(activeProject.techStackDetails?.monitoring || 'Azure Monitor')

  const canEdit = currentUser?.role === 'Solution Architect' ||
                  currentUser?.role === 'Enterprise Architect' ||
                  currentUser?.role === 'Admin'

  const filteredTabs = useMemo(() => {
    if (!currentUser) return []
    const role = currentUser.role
    if (role === 'Admin' || role === 'Enterprise Architect') {
      return tabs
    }
    if (role === 'Solution Architect') {
      return ['Architecture Canvas', 'Technology Stack', 'Health Score', 'Version History']
    }
    if (role === 'Delivery Manager') {
      return ['Architecture Canvas', 'Health Score', 'Version History']
    }
    return ['Architecture Canvas']
  }, [currentUser])

  const executiveArchitecture = useMemo<ExecutiveArchitectureData | null>(() => {
    return documentData.architecture.executive || dbArchitecture?.executive || null
  }, [documentData.architecture.executive, dbArchitecture])

  const executiveDataToUse = useMemo<ExecutiveArchitectureData>(() => {
    return normalizeExecutiveArchitecture(
      executiveArchitecture,
      currentTemplate,
      currentTheme,
      activeProject.name
    )
  }, [executiveArchitecture, currentTemplate, currentTheme, activeProject.name])

  useEffect(() => {
    if (filteredTabs.length > 0 && !filteredTabs.includes(activeTab)) {
      setActiveTab(filteredTabs[0])
    }
  }, [filteredTabs, activeTab])

  useEffect(() => {
    setFrontend(activeProject.techStackDetails?.frontend || 'React 18 + TypeScript')
    setBackend(activeProject.techStackDetails?.backend || '.NET 8 / C#')
    setDatabase(activeProject.techStackDetails?.database || 'SQL Server')
    setAuthentication(activeProject.techStackDetails?.authentication || 'Azure AD B2C')
    setCloudPlatform(activeProject.techStackDetails?.cloudPlatform || 'Azure')
    setStorage(activeProject.techStackDetails?.storage || 'Azure Blob Storage')
    setMessaging(activeProject.techStackDetails?.messaging || 'Azure Service Bus')
    setAiServices(activeProject.techStackDetails?.aiServices || 'Azure OpenAI')
    setMonitoring(activeProject.techStackDetails?.monitoring || 'Azure Monitor')
  }, [activeProject])

  useEffect(() => {
    if (executiveArchitecture?.templateId) {
      setCurrentTemplate(executiveArchitecture.templateId)
    }
    if (executiveArchitecture?.themeId) {
      setCurrentTheme(executiveArchitecture.themeId)
    }
  }, [executiveArchitecture])

  // Dialog / Creation state
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [newCompName, setNewCompName] = useState('')
  const [newCompTech, setNewCompTech] = useState('')
  const [newCompDesc, setNewCompDesc] = useState('')
  const [newCompLayer, setNewCompLayer] = useState('Backend')

  const [connectTargetId, setConnectTargetId] = useState('')
  const [connectLabel, setConnectLabel] = useState('')

  const nodeTypes = useMemo(() => ({
    archNode: CustomArchitectureNode,
  }), [])

  useEffect(() => {
    const mappedNodes = documentData.architecture.nodes.map(n => ({
      ...n,
      type: 'archNode',
      style: undefined,
    }))
    setNodes(mappedNodes as Node[])
    setEdges(documentData.architecture.edges as Edge[])
    setSelectedNode(null)
    setSelectedEdge(null)
    setConnectTargetId('')
    setConnectLabel('')
  }, [documentData, setNodes, setEdges])

  const onNodeClick = useCallback((_: any, node: Node) => {
    const comp = documentData.architecture.nodes.find(c => c.id === node.id)
    if (comp) {
      setSelectedNode(comp)
      setSelectedEdge(null)
      setConnectTargetId('')
      setConnectLabel('')
    }
  }, [documentData])

  const onEdgeClick = useCallback((_: any, edge: Edge) => {
    setSelectedEdge(edge)
    setSelectedNode(null)
  }, [])

  const onConnect = useCallback((params: any) => {
    setEdges((eds) => addEdge({ ...params, animated: true, style: { stroke: '#94A3B8', strokeWidth: 1.5 } }, eds))
    toast.success('Connection created')
  }, [setEdges])

  const deleteSelected = useCallback(() => {
    if (!selectedNode) return
    setNodes(nds => nds.filter(n => n.id !== selectedNode.id))
    setEdges(eds => eds.filter(e => e.source !== selectedNode.id && e.target !== selectedNode.id))
    setSelectedNode(null)
    toast.success('Component deleted')
  }, [selectedNode, setNodes, setEdges])

  const deleteSelectedEdge = useCallback(() => {
    if (!selectedEdge) return
    setEdges(eds => eds.filter(e => e.id !== selectedEdge.id))
    setSelectedEdge(null)
    toast.success('Connection deleted')
  }, [selectedEdge, setEdges])

  const handleConnectButton = () => {
    if (!selectedNode || !connectTargetId) return
    const newEdge: Edge = {
      id: `manual-arch-edge-${Date.now()}`,
      source: selectedNode.id,
      target: connectTargetId,
      label: connectLabel || undefined,
      animated: true,
      style: { stroke: '#94A3B8', strokeWidth: 1.5 },
    }
    setEdges(eds => addEdge(newEdge, eds))
    setConnectTargetId('')
    setConnectLabel('')
    toast.success('Connection line added')
  }

  const addNewComponent = () => {
    if (!newCompName.trim()) return
    const id = `ac-new-${Date.now()}`
    const newNode: Node = {
      id,
      type: 'archNode',
      position: { x: 400, y: 250 },
      data: {
        label: newCompName,
        componentType: 'Microservice',
        technology: newCompTech || 'Microservice',
        cloudService: 'Microservice',
        layer: newCompLayer as any,
        description: newCompDesc || `${newCompName} operating at ${newCompLayer} layer.`,
        icon: 'Server',
      },
    }
    setNodes(nds => [...nds, newNode])
    setShowAddDialog(false)
    setNewCompName('')
    setNewCompDesc('')
    toast.success('Component added')
  }

  const saveArchitecture = () => {
    const serializedNodes: ArchNode[] = nodes.map(n => ({
      id: n.id,
      type: n.type || 'archNode',
      position: n.position,
      data: n.data as ArchNode['data'],
    }))

    const executiveToSave = executiveArchitecture
      ? { ...executiveArchitecture, templateId: currentTemplate, themeId: currentTheme }
      : undefined

    updateArchitecture(serializedNodes, edges as ArchEdge[], executiveToSave)
    toast.success('Solution architecture updated and version snapshot created!')
  }

  const handleRegenerateArchitecture = async () => {
    if (isRegenerating) return
    setIsRegenerating(true)
    setShowProgressModal(true)
    setRegenerationError(null)
    setProgressStep('Preparing project...')

    try {
      await triggerGenerateArchitecture((step: string) => {
        setProgressStep(step)
      })
      toast.success('Solution Architecture regenerated with a fresh enterprise variant.')
    } catch (e: any) {
      console.error('AI Architecture Generation Error:', e)
      const msg = e?.message || 'AI Architecture generation failed. Please check AI settings.'
      setRegenerationError(msg)
      toast.error(msg)
    } finally {
      setIsRegenerating(false)
    }
  }

  const confirmTechStackSelection = async () => {
    if (isRegenerating) return
    updateProjectTechStackDetails(activeProject.id, {
      frontend, backend, database, authentication, cloudPlatform, storage, messaging, aiServices, monitoring
    })
    setIsRegenerating(true)
    setShowProgressModal(true)
    setRegenerationError(null)
    setProgressStep('Preparing project...')

    try {
      await triggerGenerateArchitecture((step: string) => {
        setProgressStep(step)
      })
      toast.success(`Technology stack saved & solution architecture regenerated!`)
    } catch (e: any) {
      console.error('AI Architecture Generation Error:', e)
      const msg = e?.message || 'Failed to regenerate architecture for new stack.'
      setRegenerationError(msg)
      toast.error(msg)
    } finally {
      setIsRegenerating(false)
    }
  }

  const handleExport = async (format: ExportFormat) => {
    setExportMenuOpen(false)
    try {
      const filename = `Solution_Architecture_${activeDocId || 'v1'}`
      await exportDesignArtifactAPI('Solution Architecture', format, 'architecture-canvas', filename, {
        nodes,
        edges,
        projectId: activeProjectId,
        docId: activeDocId,
      })
      toast.success(`Solution Architecture exported as ${format}!`)
    } catch (e) {
      toast.error(`Export to ${format} failed.`)
    }
  }

  return (
    <div className="space-y-4 animate-fade-in text-foreground">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Solution Architecture Engine</h1>
          <p className="text-sm text-muted-foreground mt-1">AI-driven multi-layered architecture diagram automatically mapped to technology stack</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Version History Button */}
          <button
            onClick={() => setShowVersionModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-muted transition-colors bg-card shadow-sm"
          >
            <History className="w-3.5 h-3.5 text-primary" />
            <span>Version: <strong className="text-primary">v{dbArchitecture ? dbArchitecture.version : 1}</strong></span>
          </button>

          {/* AI Regenerate Button */}
          <button
            onClick={handleRegenerateArchitecture}
            disabled={isRegenerating}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-primary/10 border border-primary/20 hover:border-primary/50 text-primary rounded-lg text-xs font-semibold transition-colors"
          >
            {isRegenerating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {isRegenerating ? 'Generating...' : 'Regenerate Architecture'}
          </button>

          {/* Export Dropdown */}
          <div className="relative">
            <button
              onClick={() => setExportMenuOpen(!exportMenuOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-border bg-card hover:bg-muted rounded-lg text-xs font-semibold transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> Export <ChevronDown className="w-3 h-3 ml-0.5" />
            </button>
            {exportMenuOpen && (
              <div className="absolute right-0 mt-1 w-40 bg-card border border-border rounded-xl shadow-xl z-50 py-1 text-xs">
                {(['PNG', 'SVG', 'PDF', 'Draw.io', 'PlantUML', 'JSON'] as ExportFormat[]).map(fmt => (
                  <button
                    key={fmt}
                    onClick={() => handleExport(fmt)}
                    className="w-full text-left px-3 py-1.5 hover:bg-primary/10 hover:text-primary transition-colors flex items-center justify-between"
                  >
                    <span>{fmt} Format</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Governance Controls */}
          <div className="flex items-center gap-1 bg-muted/40 p-1 rounded-lg border border-border">
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'arch', 'Solution Architecture', 'Approved', 'Architect')
                toast.success('Solution Architecture marked as Approved!')
              }}
              className="px-2 py-1 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <Check className="w-3 h-3" /> Approve
            </button>
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'arch', 'Solution Architecture', 'Rejected', 'Architect')
                toast.warning('Solution Architecture marked as Rejected.')
              }}
              className="px-2 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <X className="w-3 h-3" /> Reject
            </button>
          </div>

          {canEdit && (
            <button
              onClick={saveArchitecture}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-semibold hover:bg-emerald-700 transition-colors shadow"
            >
              <Save className="w-3.5 h-3.5" /> Save Architecture
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border pb-px overflow-x-auto">
        {filteredTabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              'px-4 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors',
              activeTab === tab
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* CANVAS TAB */}
      {activeTab === 'Architecture Canvas' && (
        <div className="space-y-4">
          {/* Executive vs Technical View Switcher Header */}
          <div className="flex items-center justify-between bg-card rounded-xl border border-border p-2.5 shadow-sm flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-muted-foreground mr-1">Architecture View:</span>
              <button
                onClick={() => setArchitectureView('Executive')}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all',
                  architectureView === 'Executive'
                    ? 'bg-primary text-primary-foreground shadow'
                    : 'bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground'
                )}
              >
                <Brain className="w-3.5 h-3.5" /> Executive Architecture
              </button>
              <button
                onClick={() => setArchitectureView('Technical')}
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all',
                  architectureView === 'Technical'
                    ? 'bg-primary text-primary-foreground shadow'
                    : 'bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground'
                )}
              >
                <Cpu className="w-3.5 h-3.5" /> Technical Topology
              </button>
            </div>

            <div className="flex items-center gap-3 text-xs">
              <span className="text-muted-foreground">Active Stack: <strong className="text-foreground font-mono">{activeProject.selectedTechStack}</strong></span>
              <button
                onClick={() => setActiveTab('Technology Stack')}
                className="text-xs text-primary font-semibold hover:underline"
              >
                Configure Stack
              </button>
            </div>
          </div>

          {/* 1. EXECUTIVE SOLUTION ARCHITECTURE VIEW */}
          {architectureView === 'Executive' && (
            <div id="architecture-canvas" className="w-full space-y-3">
              <ExecutiveArchitectureCanvas
                executive={executiveDataToUse}
                projectName={activeProject.name}
                techStackDetails={activeProject.techStackDetails}
              />
            </div>
          )}

          {/* 2. TECHNICAL TOPOLOGY VIEW */}
          {architectureView === 'Technical' && (
            <div className="space-y-3">
              {/* Action Bar */}
              <div className="flex items-center justify-between bg-card rounded-xl border border-border p-2 flex-wrap gap-2">
                <div className="flex items-center gap-1">
                  {canEdit && (
                    <button
                      onClick={() => setShowAddDialog(true)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-primary hover:bg-primary/10 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Component
                    </button>
                  )}
                  {selectedNode && canEdit && (
                    <button
                      onClick={deleteSelected}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-500 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete Component
                    </button>
                  )}
                  {selectedEdge && canEdit && (
                    <button
                      onClick={deleteSelectedEdge}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-500 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete Connection
                    </button>
                  )}
                </div>
              </div>

              {/* Connection Builder Toolbar */}
              {selectedNode && canEdit && (
                <div className="bg-card rounded-xl border border-border p-3 flex items-center justify-between gap-3 text-xs shadow-sm">
                  <div className="flex items-center gap-2 flex-1">
                    <span className="font-semibold text-muted-foreground">Selected Component:</span>
                    <span className="font-bold text-primary">{selectedNode.data.label}</span>
                    <span className="bg-muted px-2 py-0.5 rounded text-[10px]">{selectedNode.data.layer}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-muted-foreground">Connect To:</span>
                    <select
                      value={connectTargetId}
                      onChange={e => setConnectTargetId(e.target.value)}
                      className="px-2 py-1 rounded border border-border bg-background text-xs outline-none"
                    >
                      <option value="">Select component target...</option>
                      {nodes.filter(n => n.id !== selectedNode.id).map(n => (
                        <option key={n.id} value={n.id}>{(n.data as any)?.label}</option>
                      ))}
                    </select>
                    <input
                      type="text"
                      placeholder="Connection label (e.g., gRPC / HTTPS)"
                      value={connectLabel}
                      onChange={e => setConnectLabel(e.target.value)}
                      className="px-2 py-1 rounded border border-border bg-background text-xs outline-none w-44"
                    />
                    <button
                      onClick={handleConnectButton}
                      disabled={!connectTargetId}
                      className="px-3 py-1 rounded bg-primary text-primary-foreground font-semibold disabled:opacity-50 text-xs"
                    >
                      Link
                    </button>
                  </div>
                </div>
              )}

              {/* Main React Flow Canvas */}
              <div id="architecture-canvas" className="h-[550px] bg-card rounded-xl border border-border overflow-hidden relative shadow-inner">
                {nodes.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center p-6 text-center space-y-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <Cpu className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold">No Solution Architecture Generated Yet</h3>
                      <p className="text-xs text-muted-foreground mt-1 max-w-md">
                        Generate an interactive multi-tier solution architecture diagram matching your tech stack using AI.
                      </p>
                    </div>
                    <button
                      onClick={handleRegenerateArchitecture}
                      disabled={isRegenerating}
                      className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity shadow cursor-pointer"
                    >
                      {isRegenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                      Generate Architecture
                    </button>
                  </div>
                ) : (
                  <ReactFlow
                    nodes={nodes}
                    edges={edges}
                    onNodesChange={canEdit ? onNodesChange : undefined}
                    onEdgesChange={canEdit ? onEdgesChange : undefined}
                    onConnect={canEdit ? onConnect : undefined}
                    onNodeClick={onNodeClick}
                    onEdgeClick={onEdgeClick}
                    nodeTypes={nodeTypes}
                    fitView
                  >
                    <Background variant={BackgroundVariant.Dots} gap={16} size={1} />
                    <Controls />
                    <MiniMap nodeStrokeWidth={3} zoomable pannable className="!bg-card !border-border" />
                    <Panel position="top-right" className="bg-card/90 backdrop-blur border border-border px-3 py-1.5 rounded-lg text-[10px] text-muted-foreground shadow-sm">
                      Interactive Solution Architecture Canvas
                    </Panel>
                  </ReactFlow>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TECH STACK SELECTION TAB */}
      {activeTab === 'Technology Stack' && (
        <div className="space-y-4 bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div>
              <h3 className="text-sm font-bold text-foreground">Technology Stack Configuration</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Configure platform frameworks, databases, messaging, and cloud providers to automatically regenerate your solution architecture</p>
            </div>
            <button
              onClick={confirmTechStackSelection}
              disabled={isRegenerating}
              className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-xs font-semibold hover:opacity-90 transition-opacity shadow"
            >
              {isRegenerating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              Save & Regenerate Architecture
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Frontend Framework</label>
              <input
                type="text"
                value={frontend}
                onChange={e => setFrontend(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Backend Framework / Language</label>
              <input
                type="text"
                value={backend}
                onChange={e => setBackend(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Database Engine</label>
              <input
                type="text"
                value={database}
                onChange={e => setDatabase(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Authentication Provider</label>
              <input
                type="text"
                value={authentication}
                onChange={e => setAuthentication(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Cloud Platform</label>
              <input
                type="text"
                value={cloudPlatform}
                onChange={e => setCloudPlatform(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Object Storage</label>
              <input
                type="text"
                value={storage}
                onChange={e => setStorage(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Messaging Queue</label>
              <input
                type="text"
                value={messaging}
                onChange={e => setMessaging(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">AI Services</label>
              <input
                type="text"
                value={aiServices}
                onChange={e => setAiServices(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="font-semibold text-muted-foreground uppercase text-[10px]">Monitoring & Observability</label>
              <input
                type="text"
                value={monitoring}
                onChange={e => setMonitoring(e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background font-medium outline-none focus:border-primary"
              />
            </div>
          </div>
        </div>
      )}

      {/* AI RECOMMENDATIONS TAB */}
      {activeTab === 'AI Recommendations' && (
        <div className="space-y-4 bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="border-b border-border pb-3">
            <h3 className="text-sm font-bold text-foreground">AI Architecture Recommendations</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Automated design pattern suggestions, performance enhancements, and security improvements</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-4 rounded-xl border border-border bg-muted/20 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-primary">Distributed Caching Layer</span>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded font-medium">Recommended</span>
              </div>
              <p className="text-xs text-muted-foreground">Add Redis / Memcached in front of relational database queries to reduce p95 latency under 100ms.</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-muted/20 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-primary">Async Event Queue Engine</span>
                <span className="text-[10px] bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded font-medium">High Priority</span>
              </div>
              <p className="text-xs text-muted-foreground">Implement RabbitMQ / Azure Service Bus for background job processing and non-blocking API webhooks.</p>
            </div>
          </div>
        </div>
      )}

      {/* VALIDATION TAB */}
      {activeTab === 'Validation' && (
        <div className="space-y-4 bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="border-b border-border pb-3">
            <h3 className="text-sm font-bold text-foreground">Architecture Validation & Compliance</h3>
            <p className="text-xs text-muted-foreground mt-0.5">Automated validation checks against enterprise security, reliability, and cloud standards</p>
          </div>
          <div className="space-y-2">
            <div className="p-3 rounded-lg border border-emerald-500/20 bg-emerald-500/5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span className="font-semibold">Multi-Tier Layer Isolation</span>
              </div>
              <span className="text-emerald-600 font-mono text-[10px]">Passed</span>
            </div>
            <div className="p-3 rounded-lg border border-emerald-500/20 bg-emerald-500/5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span className="font-semibold">OAuth2 / Azure AD Authentication</span>
              </div>
              <span className="text-emerald-600 font-mono text-[10px]">Passed</span>
            </div>
            <div className="p-3 rounded-lg border border-amber-500/20 bg-amber-500/5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <span className="font-semibold">Cross-Region Redundancy</span>
              </div>
              <span className="text-amber-600 font-mono text-[10px]">Warning (Single-Region active)</span>
            </div>
          </div>
        </div>
      )}

      {/* HEALTH SCORE TAB */}
      {activeTab === 'Health Score' && (
        <div className="space-y-5 bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div>
              <h3 className="text-sm font-bold text-foreground">Architecture Health Score & Audit</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Calculated from topology complexity, security coverage, resiliency, and maintainability</p>
            </div>
            <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-600 px-3 py-1.5 rounded-xl border border-emerald-500/20">
              <Activity className="w-4 h-4" />
              <span className="text-sm font-bold">Overall Health: 91 / 100</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl border border-border bg-muted/20 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span>Security & Identity</span>
                <span className="text-blue-500">92%</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: '92%' }} />
              </div>
              <p className="text-[10px] text-muted-foreground">Auth provider, RBAC, HTTPS TLS 1.3</p>
            </div>

            <div className="p-4 rounded-xl border border-border bg-muted/20 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span>Scalability & Performance</span>
                <span className="text-purple-500">88%</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full" style={{ width: '88%' }} />
              </div>
              <p className="text-[10px] text-muted-foreground">API Gateway, Caching, Edge CDN</p>
            </div>

            <div className="p-4 rounded-xl border border-border bg-muted/20 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span>Resilience & Redundancy</span>
                <span className="text-emerald-500">95%</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '95%' }} />
              </div>
              <p className="text-[10px] text-muted-foreground">Async Messaging, Failover, Backups</p>
            </div>

            <div className="p-4 rounded-xl border border-border bg-muted/20 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span>Maintainability</span>
                <span className="text-orange-500">90%</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-orange-500 rounded-full" style={{ width: '90%' }} />
              </div>
              <p className="text-[10px] text-muted-foreground">Clean Layer Separation, Microservices</p>
            </div>
          </div>
        </div>
      )}

      {/* VERSION HISTORY TAB */}
      {activeTab === 'Version History' && (
        <div className="space-y-4 bg-card rounded-xl border border-border p-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <div>
              <h3 className="text-sm font-bold text-foreground">Architecture Version Snapshots</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Historical solution architecture versions and change log records</p>
            </div>
            <span className="text-xs font-mono font-bold bg-primary/10 text-primary px-2.5 py-1 rounded-lg">
              Total Versions: {architectureVersions.length}
            </span>
          </div>

          <div className="space-y-3">
            {architectureVersions.length === 0 ? (
              <div className="text-center py-10 text-sm text-muted-foreground bg-muted/20 rounded-xl border border-border">
                No versions available yet. Generated versions will automatically record snapshots here.
              </div>
            ) : (
              architectureVersions.map(v => (
                <div key={v.id} className="p-4 rounded-xl border border-border bg-muted/20 flex items-center justify-between hover:border-primary/30 transition-colors">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-primary bg-primary/10 px-2 py-0.5 rounded">v{v.version}</span>
                      <span className="text-xs font-medium text-foreground">{v.changeSummary}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      Author: <strong className="text-foreground">{v.author}</strong> | Timestamp: {new Date(v.timestamp).toLocaleString()}
                    </p>
                  </div>

                  <button
                    onClick={async () => {
                      await restoreArchitectureVersion(v)
                      toast.success(`Restored Solution Architecture Version v${v.version}!`)
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-border bg-card text-xs font-semibold text-primary hover:bg-primary/10 transition-colors shadow-sm"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Restore Version
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Add Component Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-sm w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-sm font-bold">Add Architecture Component</h3>
              <button onClick={() => setShowAddDialog(false)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Component Name</label>
                <input
                  type="text"
                  value={newCompName}
                  onChange={e => setNewCompName(e.target.value)}
                  placeholder="E.g., Payment Gateway Service"
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Technology / Framework</label>
                <input
                  type="text"
                  value={newCompTech}
                  onChange={e => setNewCompTech(e.target.value)}
                  placeholder="E.g., Node.js / Express"
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Architecture Layer</label>
                <select
                  value={newCompLayer}
                  onChange={e => setNewCompLayer(e.target.value)}
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
                >
                  <option value="Presentation">Presentation (UI/CDN)</option>
                  <option value="Middleware">Middleware (API Gateway)</option>
                  <option value="Backend">Backend (App / Microservice)</option>
                  <option value="Data">Data (DB / Storage)</option>
                  <option value="Infrastructure">Infrastructure (Messaging / APM)</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-2 border-t border-border pt-3">
              <button onClick={() => setShowAddDialog(false)} className="px-3 py-1.5 rounded-lg border border-border text-xs font-medium">Cancel</button>
              <button onClick={addNewComponent} className="px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold">Add Component</button>
            </div>
          </div>
        </div>
      )}

      {/* Version History Modal */}
      {showVersionModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-lg w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <History className="w-4 h-4 text-primary" /> Architecture Version History
              </h3>
              <button onClick={() => setShowVersionModal(false)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
              {architectureVersions.length === 0 ? (
                <div className="text-center py-6 text-xs text-muted-foreground">
                  No previous architecture version snapshots found.
                </div>
              ) : (
                architectureVersions.map(v => (
                  <div key={v.id} className="p-3 rounded-lg border border-border bg-muted/20 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-primary">Version v{v.version}</span>
                      <span className="text-[10px] text-muted-foreground">{new Date(v.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-xs font-medium text-foreground">{v.changeSummary}</p>
                    <div className="flex justify-between items-center text-[10px] text-muted-foreground pt-1 border-t border-border/40">
                      <span>Author: <strong className="text-foreground">{v.author}</strong></span>
                      <button
                        onClick={async () => {
                          await restoreArchitectureVersion(v)
                          setShowVersionModal(false)
                          toast.success(`Restored Architecture Version v${v.version}!`)
                        }}
                        className="text-xs text-primary font-semibold hover:underline"
                      >
                        Restore Snapshot
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end border-t border-border pt-3">
              <button onClick={() => setShowVersionModal(false)} className="px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Regeneration Progress Modal */}
      <RegenerationProgressModal
        isOpen={showProgressModal}
        title="Regenerating Solution Architecture"
        currentStep={progressStep}
        error={regenerationError}
        onClose={() => setShowProgressModal(false)}
        onRetry={handleRegenerateArchitecture}
      />
    </div>
  )
}
