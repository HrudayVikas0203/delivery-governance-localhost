import { useState, useMemo } from 'react'
import { cn, getPriorityColor } from '@/lib/utils'
import { useDocuments } from '@/context/DocumentContext'
import type { Requirement } from '@/data/types'
import {
  User, UserCog, Shield, Crown, Settings, DollarSign, Key, Bell,
  BarChart3, Users, Search, Filter, CheckCircle2, Clock, ChevronDown, ChevronUp,
  AlertTriangle, ListChecks, FileText, Boxes, ArrowLeftRight, Mail, Smartphone,
  Edit3, History, Sparkles, Save, X, RefreshCw, Layers
} from 'lucide-react'
import { toast } from 'sonner'
import { submitGovernanceReview } from '@/services/collaborationService'

const iconMap: Record<string, React.ElementType> = {
  User, UserCog, Shield, Crown, Settings, DollarSign, Key, Bell, BarChart3, Users, Mail, Smartphone,
}

const tabs = [
  'All', 'Actors', 'Business Modules', 'Functional', 'Non-Functional',
  'Business Rules', 'Assumptions', 'Constraints', 'External Systems', 'Risks',
]

export default function Requirements() {
  const {
    documentData,
    dbRequirements,
    requirementVersions,
    updateRequirementItem,
    regenerateActiveRequirements,
    activeDocId,
  } = useDocuments()

  const [activeTab, setActiveTab] = useState('All')
  const [searchQuery, setSearchQuery] = useState('')
  const [expandedReqs, setExpandedReqs] = useState<Set<string>>(new Set())

  // Edit Modal state
  const [editingReq, setEditingReq] = useState<Requirement | null>(null)
  const [editForm, setEditForm] = useState<Partial<Requirement>>({})

  // Version History Modal state
  const [showVersions, setShowVersions] = useState(false)

  // Regeneration Modal state
  const [showRegenerate, setShowRegenerate] = useState(false)
  const [customPrompt, setCustomPrompt] = useState('')
  const [isRegenerating, setIsRegenerating] = useState(false)

  const { actors, modules, functional, nonFunctional, businessRules, assumptions, constraints, externalSystems, risks } = documentData.requirements

  const safeFunctional = functional ?? []
  const safeNonFunctional = nonFunctional ?? []
  const safeActors = actors ?? []
  const safeModules = modules ?? []
  const safeBusinessRules = businessRules ?? []
  const safeAssumptions = assumptions ?? []
  const safeConstraints = constraints ?? []
  const safeExternalSystems = externalSystems ?? []
  const safeRisks = risks ?? []

  const validatedCount = useMemo(() => {
    return safeFunctional.filter(r => r?.status === 'Validated').length + safeNonFunctional.filter(r => r?.status === 'Validated').length
  }, [safeFunctional, safeNonFunctional])

  const pendingCount = useMemo(() => {
    return safeFunctional.filter(r => r?.status !== 'Validated').length + safeNonFunctional.filter(r => r?.status !== 'Validated').length
  }, [safeFunctional, safeNonFunctional])

  const filteredReqs = useMemo(() => {
    let reqs = activeTab === 'Functional' ? safeFunctional
      : activeTab === 'Non-Functional' ? safeNonFunctional
      : [...safeFunctional, ...safeNonFunctional]
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      reqs = reqs.filter(r =>
        (r?.title ?? '').toLowerCase().includes(query) ||
        (r?.code ?? '').toLowerCase().includes(query) ||
        (r?.description ?? '').toLowerCase().includes(query)
      )
    }
    return reqs
  }, [activeTab, searchQuery, safeFunctional, safeNonFunctional])

  const toggleReq = (id: string) => {
    setExpandedReqs(prev => {
      const next = new Set(prev)
      if (next.has(id)) {
        next.delete(id)
      } else {
        next.add(id)
      }
      return next
    })
  }

  const openEditModal = (req: Requirement, e: React.MouseEvent) => {
    e.stopPropagation()
    setEditingReq(req)
    setEditForm({ ...req })
  }

  const handleSaveEdit = async () => {
    if (!editingReq || !editForm.title) return
    try {
      await updateRequirementItem(editForm as Requirement)
      toast.success(`Requirement ${editingReq.code} updated & version saved.`)
      setEditingReq(null)
    } catch (err) {
      toast.error('Failed to update requirement.')
    }
  }

  const handleRegenerateSubmit = async () => {
    if (isRegenerating) return
    setIsRegenerating(true)
    try {
      await regenerateActiveRequirements(customPrompt)
      toast.success('Requirements regenerated successfully!')
      setShowRegenerate(false)
      setCustomPrompt('')
    } catch (err: any) {
      toast.error(err?.message || 'Regeneration failed.')
    } finally {
      setIsRegenerating(false)
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header with Version Badge and Regeneration */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Requirements Management</h1>
          <p className="text-sm text-muted-foreground mt-1">Structured extraction from uploaded documents with full editability and version history</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Version History Button */}
          <button
            onClick={() => setShowVersions(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-muted transition-colors bg-card shadow-sm"
          >
            <History className="w-3.5 h-3.5 text-primary" />
            <span>Version: <strong className="text-primary">v{dbRequirements ? dbRequirements.version : 1}</strong></span>
            {requirementVersions.length > 0 && (
              <span className="bg-primary/10 text-primary text-[10px] px-1.5 py-0.5 rounded-full ml-1 font-mono">
                {requirementVersions.length} snapshots
              </span>
            )}
          </button>

          {/* AI Governance Controls */}
          <div className="flex items-center gap-1 bg-muted/40 p-1 rounded-lg border border-border">
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'req', 'Requirements', 'Approved', 'Architect')
                toast.success('Requirements marked as Approved!')
              }}
              className="px-2.5 py-1 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> Approve
            </button>
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'req', 'Requirements', 'Rejected', 'Architect')
                toast.warning('Requirements marked as Rejected.')
              }}
              className="px-2.5 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <AlertTriangle className="w-3.5 h-3.5" /> Reject
            </button>
            <button
              onClick={() => {
                submitGovernanceReview(activeDocId || 'req', 'Requirements', 'Marked as Reviewed', 'Architect')
                toast.info('Requirements marked as Reviewed.')
              }}
              className="px-2.5 py-1 rounded bg-blue-500/15 hover:bg-blue-500/25 text-blue-600 text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <Shield className="w-3.5 h-3.5" /> Reviewed
            </button>
          </div>

          {/* Regenerate AI Requirements Button */}
          <button
            onClick={() => setShowRegenerate(true)}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity shadow"
          >
            <Sparkles className="w-3.5 h-3.5" /> Regenerate AI
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { label: 'Total', value: safeFunctional.length + safeNonFunctional.length, icon: ListChecks, color: 'text-blue-500 bg-blue-500/10' },
          { label: 'Functional', value: safeFunctional.length, icon: FileText, color: 'text-emerald-500 bg-emerald-500/10' },
          { label: 'Non-Functional', value: safeNonFunctional.length, icon: Boxes, color: 'text-purple-500 bg-purple-500/10' },
          { label: 'Validated', value: validatedCount, icon: CheckCircle2, color: 'text-green-500 bg-green-500/10' },
          { label: 'Pending', value: pendingCount, icon: Clock, color: 'text-orange-500 bg-orange-500/10' },
        ].map((stat, i) => {
          const Icon = stat.icon
          return (
            <div key={i} className="bg-card rounded-xl border border-border px-4 py-3 flex items-center gap-3">
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center', stat.color)}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xl font-bold">{stat.value}</p>
                <p className="text-[10px] text-muted-foreground">{stat.label}</p>
              </div>
            </div>
          )
        })}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              'px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors',
              activeTab === tab
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Content */}
      {(activeTab === 'All' || activeTab === 'Functional' || activeTab === 'Non-Functional') && (
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search requirements..."
                className="w-full pl-9 pr-4 py-2 rounded-lg border border-border bg-background text-sm outline-none focus:border-primary transition-colors"
              />
            </div>
            <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border text-xs text-muted-foreground hover:bg-muted transition-colors">
              <Filter className="w-3.5 h-3.5" /> Filter
            </button>
          </div>
          <div className="space-y-2">
            {filteredReqs.length === 0 ? (
              <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
                {searchQuery.trim() ? 'No requirements match your search.' : 'No requirements generated yet. Upload a document and run AI extraction.'}
              </div>
            ) : filteredReqs.map((req, idx) => {
              const r = req as any
              const reqId = r.id || `req-item-${r.code || idx}`
              const title = r.title || r.name || r.requirementName || r.label || r.summary || `Requirement ${idx + 1}`
              const code = r.code || r.reqCode || r.identifier || `REQ-${idx + 1}`
              const description = r.description || r.details || r.desc || r.summary || r.text || title
              const priority = r.priority || r.importance || r.severity || 'Medium'
              const status = r.status || r.state || 'Extracted'
              const type = r.type || 'Functional'
              const rawModule = r.module ?? r.businessModule ?? r.moduleName ?? r.moduleId ?? r.component ?? r.feature
              const moduleName = typeof rawModule === 'object'
                ? (rawModule?.name || rawModule?.title || rawModule?.label || rawModule?.id || '')
                : (rawModule || '')
              const category = r.category || r.domain || 'General'

              return (
                <div key={reqId} className="bg-card rounded-xl border border-border overflow-hidden hover:border-primary/20 transition-colors">
                  <button onClick={() => toggleReq(reqId)} className="w-full flex items-center gap-3 px-4 py-3 text-left">
                    <span className="text-[10px] font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">{code}</span>
                    <span className="text-sm font-medium flex-1">{title}</span>
                    <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-medium', getPriorityColor(priority))}>{priority}</span>
                    <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-medium',
                      status === 'Validated' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-yellow-500/10 text-yellow-600'
                    )}>{status}</span>
                    <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded">{type}</span>
                    
                    {/* Edit Action Button */}
                    <span
                      onClick={(e) => openEditModal(req, e)}
                      className="p-1 hover:bg-primary/10 rounded text-muted-foreground hover:text-primary transition-colors"
                      title="Edit Requirement"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </span>

                    {expandedReqs.has(reqId) ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                  </button>
                  {expandedReqs.has(reqId) && (
                    <div className="px-4 pb-3 pt-0 border-t border-border mt-0">
                      <p className="text-sm text-muted-foreground py-3">{description}</p>
                      <div className="flex items-center justify-between text-[10px]">
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">Module:</span>
                          <span className="bg-muted px-2 py-0.5 rounded">{moduleName}</span>
                          <span className="text-muted-foreground ml-2">Category:</span>
                          <span className="bg-muted px-2 py-0.5 rounded">{category}</span>
                        </div>
                        <button
                          onClick={(e) => openEditModal(req, e)}
                          className="text-xs text-primary font-medium hover:underline flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" /> Edit Fields
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {activeTab === 'Actors' && (
        safeActors.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No actors extracted yet.
          </div>
        ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 stagger-children">
          {safeActors.map((actor, i) => {
            const Icon = (actor?.icon && iconMap[actor.icon]) || User
            return (
              <div key={actor?.id || `actor-${i}`} className="bg-card rounded-xl border border-border p-4 hover:border-primary/20 hover:shadow-md transition-all">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{actor?.name || 'Unnamed Actor'}</p>
                    <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-medium',
                      actor?.type === 'Primary' ? 'bg-blue-500/10 text-blue-600' :
                      actor?.type === 'Secondary' ? 'bg-purple-500/10 text-purple-600' :
                      'bg-orange-500/10 text-orange-600'
                    )}>{actor?.type || 'User'}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{actor?.description || ''}</p>
              </div>
            )
          })}
        </div>
        )
      )}

      {activeTab === 'Business Modules' && (
        safeModules.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No business modules extracted yet.
          </div>
        ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 stagger-children">
          {safeModules.map((mod, i) => (
            <div key={mod?.id || `mod-${i}`} className="bg-card rounded-xl border border-border p-4 hover:border-primary/20 hover:shadow-md transition-all">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-semibold">{mod?.name || 'Module'}</h4>
                <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-medium', getPriorityColor(mod?.priority))}>{mod?.priority || 'Medium'}</span>
              </div>
              <p className="text-xs text-muted-foreground mb-3 leading-relaxed">{mod?.description || ''}</p>
              <span className="inline-block text-[10px] px-2 py-0.5 rounded-full font-medium bg-emerald-500/10 text-emerald-600">{mod?.status || 'Active'}</span>
            </div>
          ))}
        </div>
        )
      )}

      {activeTab === 'Business Rules' && (
        safeBusinessRules.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No business rules extracted yet.
          </div>
        ) : (
        <div className="bg-card rounded-xl border border-border divide-y divide-border">
          {safeBusinessRules.map((rule, i) => (
            <div key={rule?.id || `rule-${i}`} className="px-5 py-3.5 flex items-start gap-3 hover:bg-muted/20 transition-colors">
              <span className="text-xs font-bold text-primary mt-0.5">{i + 1}</span>
              <div className="flex-1">
                <p className="text-sm">{rule?.rule || ''}</p>
                <span className="text-[10px] text-muted-foreground mt-1 bg-muted px-2 py-0.5 rounded inline-block">{rule?.module || 'General'}</span>
              </div>
            </div>
          ))}
        </div>
        )
      )}

      {activeTab === 'Assumptions' && (
        safeAssumptions.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No assumptions extracted yet.
          </div>
        ) : (
        <div className="bg-card rounded-xl border border-border divide-y divide-border">
          {safeAssumptions.map((a, i) => (
            <div key={a?.id || `assump-${i}`} className="px-5 py-3.5 flex items-start gap-3 hover:bg-muted/20 transition-colors">
              <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm">{a?.assumption || ''}</p>
                <span className="text-[10px] bg-blue-500/10 text-blue-600 px-2 py-0.5 rounded-full mt-1 inline-block">{a?.category || 'General'}</span>
              </div>
            </div>
          ))}
        </div>
        )
      )}

      {activeTab === 'Constraints' && (
        safeConstraints.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No constraints extracted yet.
          </div>
        ) : (
        <div className="bg-card rounded-xl border border-border divide-y divide-border">
          {safeConstraints.map((c, i) => (
            <div key={c?.id || `const-${i}`} className="px-5 py-3.5 flex items-start gap-3 hover:bg-muted/20 transition-colors">
              <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm">{c?.constraint || ''}</p>
                <span className="text-[10px] bg-orange-500/10 text-orange-600 px-2 py-0.5 rounded-full mt-1 inline-block">{c?.category || 'General'}</span>
              </div>
            </div>
          ))}
        </div>
        )
      )}

      {activeTab === 'External Systems' && (
        safeExternalSystems.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No external systems extracted yet.
          </div>
        ) : (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-5 py-2.5 text-xs font-medium text-muted-foreground">System</th>
                <th className="text-left px-5 py-2.5 text-xs font-medium text-muted-foreground">Type</th>
                <th className="text-left px-5 py-2.5 text-xs font-medium text-muted-foreground">Integration</th>
                <th className="text-left px-5 py-2.5 text-xs font-medium text-muted-foreground">Direction</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {safeExternalSystems.map((sys, i) => (
                <tr key={sys?.id || `ext-${i}`} className="hover:bg-muted/20 transition-colors">
                  <td className="px-5 py-3 font-medium text-xs">{sys?.name || 'System'}</td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{sys?.type || 'API'}</td>
                  <td className="px-5 py-3"><span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded font-mono">{sys?.integration || 'REST'}</span></td>
                  <td className="px-5 py-3 flex items-center gap-1 text-xs text-muted-foreground"><ArrowLeftRight className="w-3 h-3" />{sys?.direction || 'Bi-directional'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        )
      )}

      {activeTab === 'Risks' && (
        safeRisks.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground bg-card rounded-xl border border-border">
            No risks extracted yet.
          </div>
        ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 stagger-children">
          {safeRisks.map((risk, i) => (
            <div key={risk?.id || `risk-${i}`} className="bg-card rounded-xl border border-border p-4">
              <div className="flex items-start gap-3 mb-2">
                <AlertTriangle className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm font-medium">{risk?.risk || 'Risk'}</p>
              </div>
              <div className="flex gap-2 mb-3 ml-8">
                <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-medium',
                  risk?.probability === 'High' ? 'bg-red-500/10 text-red-600' : 'bg-yellow-500/10 text-yellow-600'
                )}>Probability: {risk?.probability || 'Medium'}</span>
                <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-medium',
                  risk?.impact === 'Critical' ? 'bg-red-500/10 text-red-600' : risk?.impact === 'High' ? 'bg-orange-500/10 text-orange-600' : 'bg-yellow-500/10 text-yellow-600'
                )}>Impact: {risk?.impact || 'Medium'}</span>
              </div>
              <div className="ml-8 bg-emerald-500/5 rounded-lg px-3 py-2">
                <p className="text-[10px] font-medium text-emerald-600 mb-0.5">Mitigation</p>
                <p className="text-xs text-muted-foreground">{risk?.mitigation || 'No mitigation specified.'}</p>
              </div>
            </div>
          ))}
        </div>
        )
      )}

      {/* Requirement Edit Modal */}
      {editingReq && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-lg w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-primary" /> Edit Requirement ({editingReq.code})
              </h3>
              <button onClick={() => setEditingReq(null)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Title</label>
                <input
                  type="text"
                  value={editForm.title || ''}
                  onChange={e => setEditForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary font-medium"
                />
              </div>

              <div>
                <label className="font-semibold text-muted-foreground uppercase text-[10px]">Description</label>
                <textarea
                  rows={4}
                  value={editForm.description || ''}
                  onChange={e => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-muted-foreground uppercase text-[10px]">Priority</label>
                  <select
                    value={editForm.priority || 'Medium'}
                    onChange={e => setEditForm(prev => ({ ...prev, priority: e.target.value as any }))}
                    className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary font-medium"
                  >
                    <option value="Critical">Critical</option>
                    <option value="High">High</option>
                    <option value="Medium">Medium</option>
                    <option value="Low">Low</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-muted-foreground uppercase text-[10px]">Status</label>
                  <select
                    value={editForm.status || 'Pending'}
                    onChange={e => setEditForm(prev => ({ ...prev, status: e.target.value as any }))}
                    className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary font-medium"
                  >
                    <option value="Extracted">Extracted</option>
                    <option value="Validated">Validated</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-muted-foreground uppercase text-[10px]">Module</label>
                  <input
                    type="text"
                    value={editForm.module || ''}
                    onChange={e => setEditForm(prev => ({ ...prev, module: e.target.value }))}
                    className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary font-medium"
                  />
                </div>

                <div>
                  <label className="font-semibold text-muted-foreground uppercase text-[10px]">Category</label>
                  <input
                    type="text"
                    value={editForm.category || ''}
                    onChange={e => setEditForm(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary font-medium"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 border-t border-border pt-3">
              <button
                onClick={() => setEditingReq(null)}
                className="px-4 py-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-muted"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90"
              >
                <Save className="w-3.5 h-3.5" /> Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Version History Modal */}
      {showVersions && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-xl w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <History className="w-4 h-4 text-primary" /> Requirement Version History
              </h3>
              <button onClick={() => setShowVersions(false)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
              {requirementVersions.length === 0 ? (
                <div className="text-center py-6 text-xs text-muted-foreground">
                  No version history records found for this document.
                </div>
              ) : (
                requirementVersions.map((v) => (
                  <div key={v.id} className="p-3 rounded-lg border border-border bg-muted/20 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-primary">Version v{v.version}</span>
                      <span className="text-[10px] text-muted-foreground">{new Date(v.timestamp).toLocaleString()}</span>
                    </div>
                    <p className="text-xs font-medium text-foreground">{v.changeSummary}</p>
                    <div className="flex justify-between items-center text-[10px] text-muted-foreground pt-1 border-t border-border/40">
                      <span>Author: <strong className="text-foreground">{v.author}</strong></span>
                      <span className="bg-primary/10 text-primary px-2 py-0.5 rounded font-mono">{v.changeType}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end border-t border-border pt-3">
              <button
                onClick={() => setShowVersions(false)}
                className="px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90"
              >
                Close History
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI Regeneration Modal */}
      {showRegenerate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-card rounded-xl border border-border p-6 max-w-md w-full space-y-4 shadow-xl animate-scale-in">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary animate-pulse" /> Regenerate AI Requirements
              </h3>
              <button onClick={() => setShowRegenerate(false)} className="p-1 hover:bg-muted rounded text-muted-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-muted-foreground">
              Re-run the AI extraction engine on the document. Optionally provide custom extraction instructions below.
            </p>

            <div>
              <label className="text-[10px] font-semibold text-muted-foreground uppercase">Custom Extraction Guidance (Optional)</label>
              <textarea
                rows={3}
                value={customPrompt}
                onChange={e => setCustomPrompt(e.target.value)}
                placeholder="E.g., Focus heavily on security compliance and mobile app workflows..."
                className="w-full mt-1 px-3 py-2 rounded-lg border border-border bg-background text-xs outline-none focus:border-primary"
              />
            </div>

            <div className="flex justify-end gap-2 border-t border-border pt-3">
              <button
                onClick={() => setShowRegenerate(false)}
                className="px-4 py-1.5 rounded-lg border border-border text-xs font-semibold hover:bg-muted"
                disabled={isRegenerating}
              >
                Cancel
              </button>
              <button
                onClick={handleRegenerateSubmit}
                disabled={isRegenerating}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90"
              >
                {isRegenerating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                {isRegenerating ? 'Regenerating...' : 'Start AI Extraction'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
