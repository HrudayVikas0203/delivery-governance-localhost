import { useState, useMemo } from 'react'
import { cn } from '@/lib/utils'
import { useDocuments } from '@/context/DocumentContext'
import { toast } from 'sonner'
import {
  Download, Package, GitBranch, Cpu, Code,
  FileText, BookOpen, Clock, CheckCircle2, Loader2, Files
} from 'lucide-react'
import { exportDesignArtifactAPI } from '@/services/api'
import { convertDBToSQL, convertToMermaid, convertToDrawIO, convertToPlantUML, downloadTextFile, type ExportFormat } from '@/services/exportService'

const iconMap: Record<string, React.ElementType> = {
  GitBranch, Cpu, Code, FileText, BookOpen,
}

export default function ExportCenter() {
  const { activeProject, availableDocuments, documentData, activeDocId } = useDocuments()

  const [downloading, setDownloading] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [selectedFormats, setSelectedFormats] = useState<Record<string, string>>({})

  const exportItems = useMemo(() => {
    return [
      {
        id: 'EX1',
        name: 'Business Flow Diagram',
        icon: 'GitBranch',
        formats: ['PNG', 'SVG', 'PDF', 'Mermaid', 'Draw.io', 'PlantUML'],
        lastExported: new Date()
      },
      {
        id: 'EX2',
        name: 'Solution Architecture',
        icon: 'Cpu',
        formats: ['PNG', 'SVG', 'PDF', 'Draw.io', 'PlantUML', 'JSON'],
        lastExported: new Date()
      },
      {
        id: 'EX3',
        name: 'Requirements Document',
        icon: 'FileText',
        formats: ['JSON', 'Markdown'],
        lastExported: new Date(Date.now() - 86400000)
      },
      {
        id: 'EX4',
        name: 'Complete Executive Report',
        icon: 'BookOpen',
        formats: ['Markdown', 'JSON'],
        lastExported: new Date()
      },
    ]
  }, [])

  const downloadHistory = useMemo(() => {
    const safeProjectName = activeProject.name.replace(/[^a-zA-Z0-9]/g, '_')
    return [
      { id: 'DH1', name: `${safeProjectName}_Full_Package.zip`, format: 'ZIP', size: '12.4 MB', date: new Date(), status: 'completed' },
      { id: 'DH2', name: `${safeProjectName}_Executive_Report.pdf`, format: 'PDF', size: '2.8 MB', date: new Date(), status: 'completed' },
      { id: 'DH3', name: 'Business_Flow_v3.0.vsdx', format: 'Visio', size: '4.1 MB', date: new Date(Date.now() - 3600000), status: 'completed' },
    ]
  }, [activeProject])

  const downloadAll = () => {
    setDownloading(true)
    setDownloadProgress(0)
    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          setDownloading(false)

          // Trigger real download of master project JSON package
          const fullPkg = {
            project: activeProject,
            documents: availableDocuments,
            requirements: documentData.requirements,
            businessFlow: documentData.businessFlow,
            architecture: documentData.architecture,
            reports: documentData.reports,
          }
          const safeName = activeProject.name.replace(/[^a-zA-Z0-9]/g, '_')
          downloadTextFile(JSON.stringify(fullPkg, null, 2), `${safeName}_Full_Project_Package.json`, 'application/json')
          toast.success(`Complete project package for "${activeProject.name}" exported!`)
          return 100
        }
        return prev + 20
      })
    }, 120)
  }

  const downloadItem = async (itemName: string, format: string) => {
    toast.info(`Preparing ${itemName} export in ${format} format...`)
    try {
      const filename = `${itemName.replace(/\s+/g, '_')}_${activeDocId || 'v1'}`

      if (itemName === 'Business Flow Diagram') {
        await exportDesignArtifactAPI('Business Flow', format as ExportFormat, 'business-flow-canvas', filename, {
          nodes: documentData.businessFlow.nodes,
          edges: documentData.businessFlow.edges,
          title: itemName,
        })
      } else if (itemName === 'Solution Architecture') {
        await exportDesignArtifactAPI('Solution Architecture', format as ExportFormat, 'architecture-canvas', filename, {
          nodes: documentData.architecture.nodes,
          edges: documentData.architecture.edges,
          title: itemName,
        })
      } else if (itemName === 'Requirements Document') {
        downloadTextFile(JSON.stringify(documentData.requirements, null, 2), `${filename}.json`, 'application/json')
      } else if (itemName === 'Complete Executive Report') {
        const markdownReport = documentData.reports.sections.map(s => `## ${s.title}\n\n${s.content}`).join('\n\n')
        downloadTextFile(markdownReport, `${filename}.md`, 'text/markdown')
      }
      toast.success(`${itemName} successfully exported as ${format}!`)
    } catch (e) {
      toast.error(`Export failed: ${e instanceof Error ? e.message : 'Export error'}`)
    }
  }

  return (
    <div className="space-y-6 animate-fade-in text-foreground">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Export Center</h1>
        <p className="text-sm text-muted-foreground mt-1">Download generated design artifacts and comprehensive solution packages</p>
      </div>

      {/* Hero Download: Scoped to the complete project package */}
      <div className="bg-gradient-to-r from-primary via-indigo-600 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0 text-white">
              <Package className="w-7 h-7" />
            </div>
            <div className="min-w-0">
              <h2 className="text-lg font-bold truncate">Complete Project Package</h2>
              <p className="text-sm text-white/80 mt-0.5 truncate">
                Export all configurations for: <span className="font-semibold text-white">{activeProject.name}</span>
              </p>
              <p className="text-xs text-white/60 mt-1">
                Includes {availableDocuments.length} documents, business flows, tech stack diagrams, DB models, and executive report.
              </p>
            </div>
          </div>
          <button
            onClick={downloadAll}
            disabled={downloading}
            className="flex items-center gap-2 px-6 py-3 bg-white text-primary rounded-xl font-bold text-xs md:text-sm hover:bg-white/95 transition-all shadow-md disabled:opacity-70 flex-shrink-0 w-full md:w-auto justify-center cursor-pointer"
          >
            {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {downloading ? `Compiling: ${Math.min(Math.round(downloadProgress), 100)}%` : 'Download Project Package'}
          </button>
        </div>
        {downloading && (
          <div className="mt-4">
            <div className="h-2 bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-white rounded-full transition-all duration-300" style={{ width: `${Math.min(downloadProgress, 100)}%` }} />
            </div>
          </div>
        )}
      </div>

      {/* Export Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {exportItems.map(item => {
          const Icon = iconMap[item.icon] || FileText
          const currentFormat = selectedFormats[item.id] || item.formats[0]
          return (
            <div key={item.id} className="bg-card rounded-2xl border border-border p-4 hover:border-primary/20 hover:shadow-md transition-all flex flex-col justify-between h-56">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold truncate text-foreground">{item.name}</h4>
                    <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3 text-muted-foreground/60" />
                      {item.lastExported ? `Exported ${item.lastExported.toLocaleTimeString()}` : 'Not exported yet'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-border/50">
                <div className="space-y-1">
                  <label className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">Select Export Format</label>
                  <div className="flex gap-1.5 flex-wrap">
                    {item.formats.map(fmt => (
                      <button
                        key={fmt}
                        onClick={() => setSelectedFormats(prev => ({ ...prev, [item.id]: fmt }))}
                        className={cn(
                          'px-2.5 py-1 rounded-md text-[10px] font-mono transition-all border cursor-pointer',
                          currentFormat === fmt
                            ? 'bg-primary text-primary-foreground border-primary font-bold shadow-sm'
                            : 'bg-muted/40 text-muted-foreground border-border hover:bg-muted hover:text-foreground'
                        )}
                      >
                        {fmt}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => downloadItem(item.name, currentFormat)}
                  className="w-full py-2 bg-muted hover:bg-primary hover:text-primary-foreground text-foreground border border-border rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" /> Download {currentFormat}
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
