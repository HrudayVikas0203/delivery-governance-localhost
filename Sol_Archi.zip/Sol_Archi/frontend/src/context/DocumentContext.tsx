import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react'
import type { DocumentData, FlowNode, FlowEdge, ArchNode, ArchEdge, Project, Requirement, ExecutiveArchitectureData } from '../data/types'
import { generateArchitectureForStack } from '../lib/architectureGenerator'
import {
  saveBusinessFlowRecord,
  saveArchitectureRecord,
  type StoredDocument,
  type ExtractedRequirementsRecord,
  type RequirementVersionRecord,
  type StoredBusinessFlow,
  type BusinessFlowVersionRecord,
  type StoredArchitecture,
  type ArchitectureVersionRecord,
} from '../services/db'
import {
  uploadDocument,
  processDocument,
  regenerateRequirements,
  updateRequirements,
  generateBusinessFlowAPI,
  saveBusinessFlowAPI,
  generateSolutionArchitectureAPI,
  saveSolutionArchitectureAPI,
  type DesignProgressCallback,
} from '../services/api'
import { useApp } from './AppContext'
import type { ProgressCallback, ProgressStep } from '../services/documentProcessor'
import { browserStorage, STORAGE_KEYS } from '@/services/storage'
import { backendApi, type BackendProject } from '@/services/backendApi'
import { monitoring } from '@/services/monitoringService'

interface HistoryState {
  businessFlow: { nodes: FlowNode[]; edges: FlowEdge[] }
  architecture: { nodes: ArchNode[]; edges: ArchEdge[] }
}

interface DocumentContextType {
  // Projects state
  projects: Project[]
  activeProjectId: string
  activeProject: Project
  createProject: (name: string, description: string, documentIds: string[]) => void
  resetContext: () => void
  selectProject: (projectId: string) => void
  updateProjectTechStack: (projectId: string, stack: string) => void
  updateProjectTechStackDetails: (projectId: string, details: Project['techStackDetails']) => void
  updateProjectDatabase: (projectId: string, db: string) => void
  addDocumentToProject: (projectId: string, docId: string) => void

  // Active document in project
  activeDocId: string
  loadDocument: (docId: string) => void
  availableDocuments: { id: string; name: string; type: string }[]
  allDocuments: { id: string; name: string; type: string }[]

  // Aggregated data for active project
  documentData: DocumentData
  isLoaded: boolean

  // Phase 2 & Phase 3 DB & AI Integration state
  dbDocuments: StoredDocument[]
  dbRequirements: ExtractedRequirementsRecord | null
  requirementVersions: RequirementVersionRecord[]
  dbFlow: StoredBusinessFlow | null
  flowVersions: BusinessFlowVersionRecord[]
  dbArchitecture: StoredArchitecture | null
  architectureVersions: ArchitectureVersionRecord[]

  processUploadedFile: (file: File, onProgress?: ProgressCallback) => Promise<string>
  updateRequirementItem: (updatedReq: Requirement) => Promise<void>
  regenerateActiveRequirements: (customPrompt?: string) => Promise<void>

  // Phase 3 Triggers & Restoration
  triggerGenerateBusinessFlow: (onProgress?: DesignProgressCallback) => Promise<void>
  triggerGenerateArchitecture: (onProgress?: DesignProgressCallback) => Promise<void>
  restoreFlowVersion: (version: BusinessFlowVersionRecord) => Promise<void>
  restoreArchitectureVersion: (version: ArchitectureVersionRecord) => Promise<void>

  // State modification (saves to active project)
  updateBusinessFlow: (nodes: FlowNode[], edges: FlowEdge[]) => void
  updateArchitecture: (nodes: ArchNode[], edges: ArchEdge[], executive?: ExecutiveArchitectureData) => void

  // History controls
  undo: () => void
  redo: () => void
  canUndo: boolean
  canRedo: boolean
}

const DocumentContext = createContext<DocumentContextType | undefined>(undefined)

const PROJECTS_STORAGE_KEY = 'copilot_projects'
const PROCESSING_PIPELINE_STEPS: ProgressStep[] = [
  { id: '1', label: 'Uploading document to backend', status: 'pending' },
  { id: '2', label: 'Parsing document on backend', status: 'pending' },
  { id: '3', label: 'Generating requirements with configured AI provider', status: 'pending' },
  { id: '4', label: 'Saving extracted requirements', status: 'pending' },
  { id: '5', label: 'Generating business flow', status: 'pending' },
  { id: '6', label: 'Generating solution architecture', status: 'pending' },
]

function mapBackendProjectToLocal(project: BackendProject, existing?: Project): Project {
  const normalizedDocuments = Array.isArray(existing?.documents) ? existing.documents : []
  return {
    id: project.id || existing?.id || `project-${Date.now()}`,
    name: project.name || existing?.name || 'Current Project',
    description: project.description || existing?.description || 'Project workspace for uploaded solution documents',
    createdAt: project.createdAt || existing?.createdAt || new Date().toISOString(),
    documents: normalizedDocuments,
    selectedTechStack: project.selectedTechStack || existing?.selectedTechStack || '',
    selectedDatabase: project.selectedDatabase || existing?.selectedDatabase || '',
    isStackConfirmed: project.isStackConfirmed ?? existing?.isStackConfirmed ?? false,
    techStackDetails: existing?.techStackDetails,
    customBusinessFlow: existing?.customBusinessFlow,
    customArchitecture: existing?.customArchitecture,
  }
}

const createLocalFallbackProject = (): Project => ({
  id: `project-${Date.now()}`,
  name: 'Current Project',
  description: 'Project workspace for uploaded solution documents',
  createdAt: new Date().toISOString(),
  documents: [],
  selectedTechStack: '',
  selectedDatabase: '',
  isStackConfirmed: false,
})

export const DocumentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { state: appState } = useApp()
  const [projects, setProjects] = useState<Project[]>(() => browserStorage.getLocal<Project[]>(PROJECTS_STORAGE_KEY) ?? [createLocalFallbackProject()])
  const [activeProjectId, setActiveProjectId] = useState<string>(() => browserStorage.getLocal<string>(STORAGE_KEYS.activeProjectId) ?? (browserStorage.getLocal<Project[]>(PROJECTS_STORAGE_KEY)?.[0]?.id || createLocalFallbackProject().id))
  const [isLoaded, setIsLoaded] = useState(true)

  // DB State
  const [dbDocuments, setDbDocuments] = useState<StoredDocument[]>([])
  const [dbRequirements, setDbRequirements] = useState<ExtractedRequirementsRecord | null>(null)
  const [requirementVersions, setRequirementVersions] = useState<RequirementVersionRecord[]>([])

  const [dbFlow, setDbFlow] = useState<StoredBusinessFlow | null>(null)
  const [flowVersions, setFlowVersions] = useState<BusinessFlowVersionRecord[]>([])

  const [dbArchitecture, setDbArchitecture] = useState<StoredArchitecture | null>(null)
  const [architectureVersions, setArchitectureVersions] = useState<ArchitectureVersionRecord[]>([])


  // Undo/Redo history tracking
  const [undoStack, setUndoStack] = useState<HistoryState[]>([])
  const [redoStack, setRedoStack] = useState<HistoryState[]>([])

  const activeProject = useMemo(() => {
    const candidate = projects.find(p => p.id === activeProjectId) || projects[0] || createLocalFallbackProject()
    return {
      ...candidate,
      documents: Array.isArray(candidate.documents) ? candidate.documents : [],
    }
  }, [projects, activeProjectId])

  const [activeDocId, setActiveDocId] = useState<string>('')

  useEffect(() => {
    let cancelled = false

    const syncProjectsFromBackend = async () => {
      try {
        const remoteProjects = await backendApi.listProjects()
        if (cancelled || remoteProjects.length === 0) {
          return
        }

        setProjects((previous) => {
          return remoteProjects.map((remote: BackendProject) => {
            const existing = previous.find((project) => project.id === remote.id)
            return mapBackendProjectToLocal(remote, existing)
          })
        })

        setActiveProjectId((previous) => {
          const storedId = browserStorage.getLocal<string>(STORAGE_KEYS.activeProjectId)
          if (storedId && remoteProjects.some((project) => project.id === storedId)) {
            return storedId
          }
          if (remoteProjects.some((project) => project.id === previous)) {
            return previous
          }
          return remoteProjects[0].id
        })
      } catch (error) {
        console.error('Failed to sync projects from backend', error)
      }
    }

    void syncProjectsFromBackend()
    return () => {
      cancelled = true
    }
  }, [])

  // Sync DB records on project or active document change
  const refreshDBData = useCallback(async () => {
    try {
      const docs = await backendApi.listProjectDocuments(activeProjectId)
      setDbDocuments(docs ?? [])

      if (docs && docs.length > 0) {
        const docIds = docs.map(d => d.id)
        setProjects(prev => prev.map(p => {
          if (p.id === activeProjectId) {
            const currentDocs = p.documents ?? []
            const newDocIds = docIds.filter(id => !currentDocs.includes(id))
            if (newDocIds.length > 0) {
              return { ...p, documents: [...currentDocs, ...newDocIds] }
            }
          }
          return p
        }))
      }
    } catch (e) {
      console.error('Failed to load project documents', e)
      setDbDocuments([])
    }

    if (!activeDocId) {
      setDbRequirements(null)
      setRequirementVersions([])
      setDbFlow(null)
      setFlowVersions([])
      setDbArchitecture(null)
      setArchitectureVersions([])
      return
    }

    const [req, reqVers, fl, flVers, arch, archVers] = await Promise.all([
      backendApi.getRequirements(activeDocId, activeProjectId).catch(() => null),
      backendApi.getRequirementVersions(activeDocId).catch(() => [] as RequirementVersionRecord[]),
      backendApi.getBusinessFlow(activeDocId, activeProjectId).catch(() => null),
      backendApi.getBusinessFlowVersions(activeDocId).catch(() => [] as BusinessFlowVersionRecord[]),
      backendApi.getArchitecture(activeDocId, activeProjectId).catch(() => null),
      backendApi.getArchitectureVersions(activeDocId).catch(() => [] as ArchitectureVersionRecord[]),
    ])

    void monitoring.sendTelemetry({
      location: 'DocumentContext.tsx:refreshDBData',
      message: 'DB data refreshed',
      data: {
        activeDocId,
        hasRequirements: !!req,
        hasBusinessFlow: !!fl,
        hasArchitecture: !!arch,
      },
      hypothesisId: 'B',
      runId: 'pre-fix',
    })

    setDbRequirements(req || null)
    setRequirementVersions(reqVers ?? [])
    setDbFlow(fl || null)
    setFlowVersions(flVers ?? [])
    setDbArchitecture(arch || null)
    setArchitectureVersions(archVers ?? [])
  }, [activeProjectId, activeDocId])

  useEffect(() => {
    browserStorage.setLocal(PROJECTS_STORAGE_KEY, projects)
  }, [projects])

  useEffect(() => {
    browserStorage.setLocal(STORAGE_KEYS.activeProjectId, activeProjectId)
  }, [activeProjectId])

  useEffect(() => {
    refreshDBData()
  }, [refreshDBData])

  useEffect(() => {
    if (activeProject.documents.length > 0) {
      setActiveDocId((current) => {
        if (current && activeProject.documents.includes(current)) {
          return current
        }
        return activeProject.documents[activeProject.documents.length - 1]
      })
    } else {
      setActiveDocId('')
    }
    setUndoStack([])
    setRedoStack([])
  }, [activeProjectId, activeProject.documents])

  const allDocuments = useMemo(() => {
    const projectDocs = dbDocuments.map(d => ({
      id: d.id,
      name: d.name,
      type: d.type,
    }))

    const seen = new Set<string>()
    return projectDocs.filter(d => {
      if (seen.has(d.id)) return false
      seen.add(d.id)
      return true
    })
  }, [dbDocuments])

  const availableDocuments = useMemo(() => {
    return activeProject.documents.map(id => {
      const dbDoc = dbDocuments.find(d => d.id === id)
      if (dbDoc) {
        return { id: dbDoc.id, name: dbDoc.name, type: dbDoc.type }
      }
      return null
    }).filter((doc): doc is { id: string; name: string; type: StoredDocument['type'] } => doc !== null)
  }, [activeProject, dbDocuments])

  const getSelectedTechStack = useCallback(() => {
    return activeProject.selectedTechStack || `${activeProject.techStackDetails?.frontend || 'React'} + ${activeProject.techStackDetails?.backend || '.NET'} + ${activeProject.techStackDetails?.database || 'SQL Server'}`
  }, [activeProject])

  const getSelectedDatabase = useCallback(() => {
    return activeProject.selectedDatabase || activeProject.techStackDetails?.database || 'SQL Server'
  }, [activeProject])

  // Process uploaded document file
  const processUploadedFile = async (file: File, onProgress?: ProgressCallback): Promise<string> => {
    const steps = PROCESSING_PIPELINE_STEPS.map((step) => ({ ...step }))
    const updatePipelineStep = (index: number, status: ProgressStep['status']) => {
      steps[index].status = status
      onProgress?.([...steps], index)
    }
    const syncRequirementProgress: ProgressCallback = (requirementSteps) => {
      const stepMapping = [
        { source: 1, target: 1 },
        { source: 2, target: 2 },
        { source: 3, target: 3 },
      ]

      stepMapping.forEach(({ source, target }) => {
        const nextStatus = requirementSteps[source]?.status
        if (nextStatus) {
          steps[target].status = nextStatus
        }
      })

      const currentIndex = stepMapping.find(({ source }) => requirementSteps[source]?.status === 'in_progress')?.target ?? 1
      onProgress?.([...steps], currentIndex)
    }

    try {
      updatePipelineStep(0, 'in_progress')
      const uploadRes = await uploadDocument(file, activeProjectId)
      updatePipelineStep(0, 'completed')

      addDocumentToProject(activeProjectId, uploadRes.documentId)
      const requirementsRecord = await processDocument(file, uploadRes.documentId, activeProjectId, appState.aiConfig, syncRequirementProgress)
      setDbRequirements(requirementsRecord)

      updatePipelineStep(4, 'in_progress')
      const newFlow = await generateBusinessFlowAPI(activeProjectId, uploadRes.documentId, appState.aiConfig)
      setDbFlow(newFlow)
      updatePipelineStep(4, 'completed')

      updatePipelineStep(5, 'in_progress')
      const newArch = await generateSolutionArchitectureAPI(
        activeProjectId,
        uploadRes.documentId,
        activeProject.techStackDetails,
        getSelectedTechStack(),
        appState.aiConfig
      )
      setDbArchitecture(newArch)
      updatePipelineStep(5, 'completed')

      setActiveDocId(uploadRes.documentId)
      await refreshDBData()
      return uploadRes.documentId
    } catch (error) {
      const activeIndex = steps.findIndex((step) => step.status === 'in_progress')
      if (activeIndex !== -1) {
        updatePipelineStep(activeIndex, 'failed')
      }
      throw error
    }
  }

  // Requirement Update & Regeneration
  const updateRequirementItem = async (updatedReq: Requirement) => {
    if (!activeDocId || !dbRequirements) return
    const isFunctional = updatedReq.type === 'Functional'
    const newFunctional = isFunctional
      ? dbRequirements.functional.map(r => (r.id === updatedReq.id ? updatedReq : r))
      : dbRequirements.functional

    const newNonFunctional = !isFunctional
      ? dbRequirements.nonFunctional.map(r => (r.id === updatedReq.id ? updatedReq : r))
      : dbRequirements.nonFunctional

    const updatedRecord = await updateRequirements(activeProjectId, activeDocId, {
      functional: newFunctional,
      nonFunctional: newNonFunctional,
    })
    setDbRequirements(updatedRecord)
    await refreshDBData()
  }

  const regenerateActiveRequirements = async (customPrompt?: string) => {
    if (!activeDocId) return
    const updatedRecord = await regenerateRequirements(activeProjectId, activeDocId, appState.aiConfig, customPrompt)
    setDbRequirements(updatedRecord)
    const newFlow = await generateBusinessFlowAPI(activeProjectId, activeDocId, appState.aiConfig)
    setDbFlow(newFlow)
    const newArch = await generateSolutionArchitectureAPI(
      activeProjectId,
      activeDocId,
      activeProject.techStackDetails,
      getSelectedTechStack(),
      appState.aiConfig
    )
    setDbArchitecture(newArch)
    await refreshDBData()
  }

  // Phase 3 Design Triggers & Restores
  const triggerGenerateBusinessFlow = async (onProgress?: DesignProgressCallback) => {
    const docIdToUse = activeDocId || activeProject.documents[activeProject.documents.length - 1] || ''
    if (!docIdToUse) {
      throw new Error('No document available to generate Business Flow. Please upload a document first.')
    }
    const newFlow = await generateBusinessFlowAPI(activeProjectId, docIdToUse, appState.aiConfig, onProgress)
    setDbFlow(newFlow)
    await refreshDBData()
  }

  const triggerGenerateArchitecture = async (onProgress?: DesignProgressCallback) => {
    const docIdToUse = activeDocId || activeProject.documents[activeProject.documents.length - 1] || ''
    if (!docIdToUse) {
      throw new Error('No document available to generate Solution Architecture. Please upload a document first.')
    }
    const newArch = await generateSolutionArchitectureAPI(
      activeProjectId,
      docIdToUse,
      activeProject.techStackDetails,
      getSelectedTechStack(),
      appState.aiConfig,
      onProgress
    )
    setDbArchitecture(newArch)
    await refreshDBData()
  }

  const restoreFlowVersion = async (versionRecord: BusinessFlowVersionRecord) => {
    await saveBusinessFlowRecord(versionRecord.flowSnapshot)
    setDbFlow(versionRecord.flowSnapshot)
    await refreshDBData()
  }

  const restoreArchitectureVersion = async (versionRecord: ArchitectureVersionRecord) => {
    await saveArchitectureRecord(versionRecord.architectureSnapshot)
    setDbArchitecture(versionRecord.architectureSnapshot)
    await refreshDBData()
  }

  // Aggregate project data across its documents
  const documentData = useMemo<DocumentData>(() => {
    const activeStoredDoc = activeDocId ? dbDocuments.find((doc) => doc.id === activeDocId) : undefined
    const requirementsSource = dbRequirements ?? {
      actors: [],
      modules: [],
      functional: [],
      nonFunctional: [],
      businessRules: [],
      assumptions: [],
      constraints: [],
      externalSystems: [],
      risks: [],
    } as Pick<ExtractedRequirementsRecord, 'actors' | 'modules' | 'functional' | 'nonFunctional' | 'businessRules' | 'assumptions' | 'constraints' | 'externalSystems' | 'risks'>

    if (!activeStoredDoc && !dbRequirements && availableDocuments.length === 0) {
      return {
        documentInfo: { id: activeProject.id, name: activeProject.name, type: 'BRD', pages: 0, confidence: 0, size: '0 MB', uploadedAt: activeProject.createdAt },
        requirements: { actors: [], modules: [], functional: [], nonFunctional: [], businessRules: [], assumptions: [], constraints: [], externalSystems: [], risks: [] },
        businessFlow: { nodes: [], edges: [] },
        architecture: { nodes: [], edges: [], recommendations: [], techStack: [], validations: [], healthMetrics: [], versions: [] },
        reports: { sections: [] }
      }
    }

    const totalPages = (dbDocuments ?? []).reduce((sum, d) => sum + (d?.pages ?? 0), 0)
    const avgConfidence = activeStoredDoc?.confidence ?? (dbRequirements ? 95 : 0)
    const totalSize = (dbDocuments ?? []).reduce((sum, d) => sum + (parseFloat(d?.size ?? '0') || 0), 0).toFixed(1)

    const docInfo = {
      id: activeStoredDoc?.id || activeProject.id,
      name: activeStoredDoc?.name || activeProject.name,
      type: (activeStoredDoc?.type || 'BRD') as DocumentData['documentInfo']['type'],
      pages: totalPages,
      confidence: avgConfidence,
      size: `${totalSize} MB`,
      uploadedAt: activeProject.createdAt
    }

    const uniqueById = <T extends { id?: string }>(arr?: T[] | null): T[] => {
      if (!arr || !Array.isArray(arr)) return []
      const seen = new Set<string>()
      return arr.filter(item => {
        if (!item || !item.id) return true
        if (seen.has(item.id)) return false
        seen.add(item.id)
        return true
      })
    }

    const uniqueByName = <T extends { name?: string; title?: string; filename?: string }>(arr?: T[] | null): T[] => {
      if (!arr || !Array.isArray(arr)) return []
      const seen = new Set<string>()
      return arr.filter(item => {
        if (!item) return false
        const rawName = item.name ?? item.title ?? item.filename ?? ''
        if (typeof rawName !== 'string' || !rawName.trim()) return true
        const lower = rawName.trim().toLowerCase()
        if (seen.has(lower)) return false
        seen.add(lower)
        return true
      })
    }

    const actors = uniqueById(requirementsSource.actors)
    const modules = uniqueByName(requirementsSource.modules)
    const functional = requirementsSource.functional ?? []
    const nonFunctional = requirementsSource.nonFunctional ?? []
    const businessRules = requirementsSource.businessRules ?? []
    const assumptions = requirementsSource.assumptions ?? []
    const constraints = requirementsSource.constraints ?? []
    const externalSystems = uniqueByName(requirementsSource.externalSystems)
    const risks = requirementsSource.risks ?? []

    // Business Flow: Prefer dbFlow if present
    let businessFlow = activeProject.customBusinessFlow
    if (dbFlow) {
      businessFlow = { nodes: dbFlow.nodes ?? [], edges: dbFlow.edges ?? [] }
    } else if (!businessFlow) {
      businessFlow = { nodes: [], edges: [] }
    } else {
      businessFlow = { nodes: businessFlow.nodes ?? [], edges: businessFlow.edges ?? [] }
    }

    // Architecture: Prefer dbArchitecture if present
    let architecture = activeProject.customArchitecture
    if (dbArchitecture) {
      const baseArch = generateArchitectureForStack(activeProject.selectedTechStack, dbArchitecture.techStackDetails || activeProject.techStackDetails)
      architecture = {
        ...baseArch,
        nodes: dbArchitecture.nodes ?? [],
        edges: dbArchitecture.edges ?? [],
        executive: dbArchitecture.executive ?? (baseArch as any)?.executive,
      }
    } else if (!architecture) {
      architecture = {
        ...generateArchitectureForStack(activeProject.selectedTechStack || 'Custom Stack', activeProject.techStackDetails),
        nodes: [],
        edges: [],
      }
    } else {
      architecture = {
        ...architecture,
        nodes: architecture.nodes ?? [],
        edges: architecture.edges ?? [],
      }
    }

    return {
      documentInfo: docInfo,
      requirements: { actors, modules, functional, nonFunctional, businessRules, assumptions, constraints, externalSystems, risks },
      businessFlow,
      architecture,
      reports: { sections: [] }
    }
  }, [activeProject, activeDocId, availableDocuments.length, dbRequirements, dbFlow, dbArchitecture, dbDocuments])

  const selectProject = (projectId: string) => {
    setIsLoaded(false)
    setTimeout(() => {
      setActiveProjectId(projectId)
      setIsLoaded(true)
    }, 200)
  }

  const createProject = (name: string, description: string, documentIds: string[]) => {
    void (async () => {
      try {
        const created = await backendApi.createProject({ name, description })
        const newProj: Project = {
          ...mapBackendProjectToLocal(created),
          documents: documentIds,
          selectedTechStack: 'React + .NET + Azure SQL',
          selectedDatabase: 'SQL Server',
          isStackConfirmed: false,
        }
        setProjects((prev) => [...prev, newProj])
        setActiveProjectId(newProj.id)
      } catch (error) {
        console.error('Failed to create project on backend; using local project id', error)
        const newProj: Project = {
          id: `project-${Date.now()}`,
          name,
          description,
          createdAt: new Date().toISOString(),
          documents: documentIds,
          selectedTechStack: 'React + .NET + Azure SQL',
          selectedDatabase: 'SQL Server',
          isStackConfirmed: false,
        }
        setProjects((prev) => [...prev, newProj])
        setActiveProjectId(newProj.id)
      }
    })()
  }

  const resetContext = () => {
    const fallbackProject = projects[0] || createLocalFallbackProject()
    setActiveProjectId(fallbackProject.id)
    browserStorage.removeLocal(STORAGE_KEYS.activeProjectId)
  }

  const updateProjectTechStack = (projectId: string, stack: string) => {
    let db = 'SQL Server'
    if (stack.includes('FastAPI')) db = 'PostgreSQL'
    if (stack.includes('Spring Boot')) db = 'MongoDB'

    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        return {
          ...p,
          selectedTechStack: stack,
          selectedDatabase: db,
          isStackConfirmed: true,
          customArchitecture: undefined
        }
      }
      return p
    }))
  }

  const updateProjectTechStackDetails = (projectId: string, details: Project['techStackDetails']) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        const stackSummary = `${details?.frontend || 'React'} + ${details?.backend || '.NET'} + ${details?.database || 'SQL Server'}`
        return {
          ...p,
          techStackDetails: details,
          selectedTechStack: stackSummary,
          selectedDatabase: details?.database || p.selectedDatabase,
          isStackConfirmed: true,
          customArchitecture: undefined
        }
      }
      return p
    }))
  }

  const updateProjectDatabase = (projectId: string, db: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        return {
          ...p,
          selectedDatabase: db
        }
      }
      return p
    }))
  }

  const addDocumentToProject = (projectId: string, docId: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        if (p.documents.includes(docId)) return p
        return {
          ...p,
          documents: [...p.documents, docId]
        }
      }
      return p
    }))
  }

  const loadDocument = (docId: string) => {
    setIsLoaded(false)
    setTimeout(() => {
      setActiveDocId(docId)
      setIsLoaded(true)
    }, 200)
  }

  const pushStateToHistory = (currentNodes: FlowNode[] | ArchNode[], currentEdges: FlowEdge[] | ArchEdge[], type: 'businessFlow' | 'architecture') => {
    const currentState: HistoryState = {
      businessFlow: {
        nodes: type === 'businessFlow' ? (currentNodes as FlowNode[]) : documentData.businessFlow.nodes,
        edges: type === 'businessFlow' ? (currentEdges as FlowEdge[]) : documentData.businessFlow.edges,
      },
      architecture: {
        nodes: type === 'architecture' ? (currentNodes as ArchNode[]) : documentData.architecture.nodes,
        edges: type === 'architecture' ? (currentEdges as ArchEdge[]) : documentData.architecture.edges,
      },
    }

    setUndoStack(prev => [...prev, JSON.parse(JSON.stringify(currentState))])
    setRedoStack([])
  }

  const updateBusinessFlow = (nodes: FlowNode[], edges: FlowEdge[]) => {
    pushStateToHistory(documentData.businessFlow.nodes, documentData.businessFlow.edges, 'businessFlow')
    if (activeDocId) {
      saveBusinessFlowAPI(activeProjectId, activeDocId, nodes, edges)
    }
  }

  const updateArchitecture = (nodes: ArchNode[], edges: ArchEdge[], executive?: ExecutiveArchitectureData) => {
    pushStateToHistory(documentData.architecture.nodes, documentData.architecture.edges, 'architecture')
    if (activeDocId) {
      saveSolutionArchitectureAPI(activeProjectId, activeDocId, nodes, edges, activeProject.techStackDetails, executive ?? dbArchitecture?.executive)
    }
  }

  const undo = () => {
    if (undoStack.length === 0) return
    const previous = undoStack[undoStack.length - 1]
    const nextUndoStack = undoStack.slice(0, -1)

    const current: HistoryState = {
      businessFlow: { nodes: documentData.businessFlow.nodes, edges: documentData.businessFlow.edges },
      architecture: { nodes: documentData.architecture.nodes, edges: documentData.architecture.edges },
    }

    setRedoStack(prev => [current, ...prev])
    setUndoStack(nextUndoStack)

    setProjects(prev => prev.map(p => {
      if (p.id === activeProjectId) {
        const arch = p.customArchitecture || generateArchitectureForStack(p.selectedTechStack)
        return {
          ...p,
          customBusinessFlow: previous.businessFlow,
          customArchitecture: {
            ...arch,
            nodes: previous.architecture.nodes,
            edges: previous.architecture.edges
          }
        }
      }
      return p
    }))
  }

  const redo = () => {
    if (redoStack.length === 0) return
    const next = redoStack[0]
    const nextRedoStack = redoStack.slice(1)

    const current: HistoryState = {
      businessFlow: { nodes: documentData.businessFlow.nodes, edges: documentData.businessFlow.edges },
      architecture: { nodes: documentData.architecture.nodes, edges: documentData.architecture.edges },
    }

    setUndoStack(prev => [...prev, current])
    setRedoStack(nextRedoStack)

    setProjects(prev => prev.map(p => {
      if (p.id === activeProjectId) {
        const arch = p.customArchitecture || generateArchitectureForStack(p.selectedTechStack)
        return {
          ...p,
          customBusinessFlow: next.businessFlow,
          customArchitecture: {
            ...arch,
            nodes: next.architecture.nodes,
            edges: next.architecture.edges
          }
        }
      }
      return p
    }))
  }

  return (
    <DocumentContext.Provider
      value={{
        projects,
        activeProjectId,
        activeProject,
        createProject,
        resetContext,
        selectProject,
        updateProjectTechStack,
        updateProjectTechStackDetails,
        updateProjectDatabase,
        addDocumentToProject,
        activeDocId,
        loadDocument,
        availableDocuments,
        allDocuments,
        documentData,
        isLoaded,
        dbDocuments,
        dbRequirements,
        requirementVersions,
        dbFlow,
        flowVersions,
        dbArchitecture,
        architectureVersions,
        processUploadedFile,
        updateRequirementItem,
        regenerateActiveRequirements,
        triggerGenerateBusinessFlow,
        triggerGenerateArchitecture,
        restoreFlowVersion,
        restoreArchitectureVersion,
        updateBusinessFlow,
        updateArchitecture,
        undo,
        redo,
        canUndo: undoStack.length > 0,
        canRedo: redoStack.length > 0,
      }}
    >
      {children}
    </DocumentContext.Provider>
  )
}

export const useDocuments = () => {
  const context = useContext(DocumentContext)
  if (!context) {
    throw new Error('useDocuments must be used within a DocumentProvider')
  }
  return context
}
