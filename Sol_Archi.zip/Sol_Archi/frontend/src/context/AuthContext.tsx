import { createContext, useContext, useState, useEffect } from 'react'
import type { ReactNode } from 'react'
import { addAuditLog } from '../services/db'
import { APP_ROUTES } from '@/config/routes'
import {
  browserStorage,
  clearAuthSession,
  persistAuthUser,
  readPersistedAuthUser,
  STORAGE_KEYS,
} from '@/services/storage'

export type UserRole = 'Business Analyst' | 'Solution Architect' | 'Enterprise Architect' | 'Delivery Manager' | 'Admin'

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  mfaEnabled?: boolean
  lastLoginAt?: string
}

interface AuthContextType {
  currentUser: User | null
  isAuthenticated: boolean
  mfaRequired: boolean
  login: (email: string, password: string, rememberUser?: boolean) => Promise<boolean>
  loginSSO: (role: UserRole, rememberUser?: boolean) => Promise<boolean>
  verifyMFA: (code: string) => Promise<boolean>
  toggleMFA: (enabled: boolean) => void
  logout: () => void
  users: User[]
  updateUserRole: (userId: string, role: UserRole) => void
  createUser: (name: string, email: string, role: UserRole) => void
  hasPermission: (path: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const defaultUsers: User[] = [
  { id: 'u1', name: 'Priya Raman', email: 'priya.raman@company.com', role: 'Business Analyst', mfaEnabled: false },
  { id: 'u2', name: 'Michael Torres', email: 'michael.torres@company.com', role: 'Solution Architect', mfaEnabled: false },
  { id: 'u3', name: 'Sara Nguyen', email: 'sara.nguyen@company.com', role: 'Enterprise Architect', mfaEnabled: true },
  { id: 'u4', name: 'Daniel Reed', email: 'daniel.reed@company.com', role: 'Delivery Manager', mfaEnabled: false },
  { id: 'u5', name: 'Admin User', email: 'admin@company.com', role: 'Admin', mfaEnabled: true },
]

export const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  'Business Analyst': [APP_ROUTES.dashboard, APP_ROUTES.upload, APP_ROUTES.requirements, APP_ROUTES.businessFlow, APP_ROUTES.export, APP_ROUTES.aiChat],
  'Solution Architect': [APP_ROUTES.dashboard, APP_ROUTES.upload, APP_ROUTES.requirements, APP_ROUTES.businessFlow, APP_ROUTES.architecture, APP_ROUTES.export, APP_ROUTES.aiChat],
  'Enterprise Architect': [APP_ROUTES.dashboard, APP_ROUTES.upload, APP_ROUTES.requirements, APP_ROUTES.businessFlow, APP_ROUTES.architecture, APP_ROUTES.export, APP_ROUTES.aiChat],
  'Delivery Manager': [APP_ROUTES.dashboard, APP_ROUTES.architecture, APP_ROUTES.export],
  'Admin': [APP_ROUTES.dashboard, APP_ROUTES.upload, APP_ROUTES.requirements, APP_ROUTES.businessFlow, APP_ROUTES.architecture, APP_ROUTES.aiChat, APP_ROUTES.export, APP_ROUTES.settings, APP_ROUTES.userManagement],
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    return readPersistedAuthUser<User>()
  })

  const [mfaRequired, setMfaRequired] = useState(false)
  const [pendingUser, setPendingUser] = useState<User | null>(() => browserStorage.getSession<User>(STORAGE_KEYS.mfaPendingUser))

  const [users, setUsers] = useState<User[]>(() => {
    return browserStorage.getLocal<User[]>(STORAGE_KEYS.allUsers) ?? defaultUsers
  })

  useEffect(() => {
    browserStorage.setLocal(STORAGE_KEYS.allUsers, users)
  }, [users])

  useEffect(() => {
    if (currentUser) {
      persistAuthUser(currentUser, !!browserStorage.getLocal(STORAGE_KEYS.currentUser))
    } else {
      clearAuthSession()
    }
  }, [currentUser])

  useEffect(() => {
    if (pendingUser) {
      browserStorage.setSession(STORAGE_KEYS.mfaPendingUser, pendingUser)
    } else {
      browserStorage.removeSession(STORAGE_KEYS.mfaPendingUser)
    }
  }, [pendingUser])

  const login = async (email: string, password: string, rememberUser = false): Promise<boolean> => {
    const matchedUser = users.find(u => u.email.toLowerCase() === email.toLowerCase())
    if (matchedUser && (password === 'password123' || password.length >= 6)) {
      if (matchedUser.mfaEnabled) {
        setPendingUser(matchedUser)
        setMfaRequired(true)
        return false
      }
      const updatedUser = { ...matchedUser, lastLoginAt: new Date().toISOString() }
      persistAuthUser(updatedUser, rememberUser)
      setCurrentUser(updatedUser)
      await addAuditLog({ projectId: 'system', action: 'User Login', detail: `User ${matchedUser.email} logged in successfully`, user: matchedUser.name, status: 'Success' })
      return true
    }
    return false
  }

  const verifyMFA = async (code: string): Promise<boolean> => {
    if (pendingUser && (code === '123456' || code.length === 6)) {
      const updatedUser = { ...pendingUser, lastLoginAt: new Date().toISOString() }
      setCurrentUser(updatedUser)
      setPendingUser(null)
      setMfaRequired(false)
      await addAuditLog({ projectId: 'system', action: 'MFA Verified', detail: `User ${pendingUser.email} verified MFA challenge`, user: pendingUser.name, status: 'Success' })
      return true
    }
    return false
  }

  const toggleMFA = (enabled: boolean) => {
    if (!currentUser) return
    const updated = { ...currentUser, mfaEnabled: enabled }
    setCurrentUser(updated)
    setUsers(prev => prev.map(u => u.id === currentUser.id ? updated : u))
  }

  const loginSSO = async (role: UserRole, rememberUser = true): Promise<boolean> => {
    const matchedUser = users.find(u => u.role === role) || users[0]
    const updatedUser = { ...matchedUser, lastLoginAt: new Date().toISOString() }
    persistAuthUser(updatedUser, rememberUser)
    setCurrentUser(updatedUser)
    await addAuditLog({ projectId: 'system', action: 'SSO Login', detail: `SSO login as ${role}`, user: matchedUser.name, status: 'Success' })
    return true
  }

  const logout = () => {
    clearAuthSession()
    setCurrentUser(null)
    setMfaRequired(false)
    setPendingUser(null)
  }

  const updateUserRole = (userId: string, role: UserRole) => {
    setUsers(prev => prev.map(u => {
      if (u.id === userId) {
        const updated = { ...u, role }
        if (currentUser && currentUser.id === userId) {
          setCurrentUser(updated)
        }
        return updated
      }
      return u
    }))
  }

  const createUser = (name: string, email: string, role: UserRole) => {
    const newUser: User = {
      id: `u-${Date.now()}`,
      name,
      email,
      role,
      mfaEnabled: false,
    }
    setUsers(prev => [...prev, newUser])
  }

  const hasPermission = (path: string): boolean => {
    if (!currentUser) return false
    const allowed = ROLE_PERMISSIONS[currentUser.role] || []
    if (allowed.includes(path)) return true
    if (path.startsWith('/')) {
      const basePath = '/' + path.split('/')[1]
      return allowed.includes(basePath)
    }
    return false
  }

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        mfaRequired,
        login,
        loginSSO,
        verifyMFA,
        toggleMFA,
        logout,
        users,
        updateUserRole,
        createUser,
        hasPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
