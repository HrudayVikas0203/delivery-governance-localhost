import { createContext, useContext, useReducer, useCallback, type ReactNode } from 'react'
import { DEFAULT_AI_CONFIG, type AiConfig } from '@/data/aiConfig'
import { browserStorage, STORAGE_KEYS } from '@/services/storage'

const getSavedAiConfig = (): AiConfig => {
  return browserStorage.getLocal<AiConfig>(STORAGE_KEYS.aiConfig) ?? DEFAULT_AI_CONFIG
}

interface AppState {
  theme: 'light' | 'dark' | 'system'
  sidebarCollapsed: boolean
  activeDocument: string | null
  searchOpen: boolean
  notifications: { id: string; title: string; message: string; read: boolean; time: Date }[]
  aiConfig: AiConfig
}

type AppAction =
  | { type: 'SET_THEME'; payload: 'light' | 'dark' | 'system' }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'SET_SIDEBAR'; payload: boolean }
  | { type: 'SET_ACTIVE_DOCUMENT'; payload: string | null }
  | { type: 'TOGGLE_SEARCH' }
  | { type: 'MARK_NOTIFICATION_READ'; payload: string }
  | { type: 'SET_AI_CONFIG'; payload: AiConfig }

const initialState: AppState = {
  theme: 'light',
  sidebarCollapsed: false,
  activeDocument: 'EPWMS_Business_Requirements_v2.1.pdf',
  searchOpen: false,
  notifications: [
    { id: '1', title: 'Architecture Generated', message: 'Solution architecture v3.0 has been generated with 18 components', read: false, time: new Date(Date.now() - 300000) },
    { id: '2', title: 'Validation Complete', message: '7 warnings found — 2 critical issues require attention', read: false, time: new Date(Date.now() - 1200000) },
    { id: '3', title: 'Export Ready', message: 'Complete solution package is ready for download', read: true, time: new Date(Date.now() - 3600000) },
    { id: '4', title: 'New Recommendations', message: '3 new AI recommendations for architecture improvement', read: true, time: new Date(Date.now() - 7200000) },
  ],
  aiConfig: getSavedAiConfig(),
}

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_THEME':
      return { ...state, theme: action.payload }
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarCollapsed: !state.sidebarCollapsed }
    case 'SET_SIDEBAR':
      return { ...state, sidebarCollapsed: action.payload }
    case 'SET_ACTIVE_DOCUMENT':
      return { ...state, activeDocument: action.payload }
    case 'TOGGLE_SEARCH':
      return { ...state, searchOpen: !state.searchOpen }
    case 'MARK_NOTIFICATION_READ':
      return {
        ...state,
        notifications: state.notifications.map(n =>
          n.id === action.payload ? { ...n, read: true } : n
        ),
      }
    case 'SET_AI_CONFIG':
      browserStorage.setLocal(STORAGE_KEYS.aiConfig, action.payload)
      return { ...state, aiConfig: action.payload }
    default:
      return state
  }
}

interface AppContextType {
  state: AppState
  dispatch: React.Dispatch<AppAction>
  setTheme: (theme: 'light' | 'dark' | 'system') => void
  toggleSidebar: () => void
  toggleSearch: () => void
  updateAiConfig: (config: AiConfig) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState)

  const setTheme = useCallback((theme: 'light' | 'dark' | 'system') => {
    dispatch({ type: 'SET_THEME', payload: theme })
    const root = document.documentElement
    if (theme === 'dark') {
      root.classList.add('dark')
    } else if (theme === 'light') {
      root.classList.remove('dark')
    } else {
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        root.classList.add('dark')
      } else {
        root.classList.remove('dark')
      }
    }
  }, [])

  const toggleSidebar = useCallback(() => dispatch({ type: 'TOGGLE_SIDEBAR' }), [])
  const toggleSearch = useCallback(() => dispatch({ type: 'TOGGLE_SEARCH' }), [])
  const updateAiConfig = useCallback((config: AiConfig) => {
    dispatch({ type: 'SET_AI_CONFIG', payload: config })
  }, [])

  return (
    <AppContext.Provider value={{ state, dispatch, setTheme, toggleSidebar, toggleSearch, updateAiConfig }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) throw new Error('useApp must be used within AppProvider')
  return context
}
