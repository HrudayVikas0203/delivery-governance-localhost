import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import {
  getAllNotifications,
  addNotification as addDBNotification,
  markNotificationAsRead as markDBRead,
  type AppNotificationRecord,
} from '../services/db'

interface NotificationContextType {
  notifications: AppNotificationRecord[]
  unreadCount: number
  sendNotification: (title: string, message: string, type?: AppNotificationRecord['type'], link?: string) => Promise<void>
  markAsRead: (id: string) => Promise<void>
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<AppNotificationRecord[]>([])

  const refreshNotifications = useCallback(async () => {
    try {
      const list = await getAllNotifications()
      setNotifications(list)
    } catch (e) {
      console.error('Failed to load notifications:', e)
    }
  }, [])

  useEffect(() => {
    refreshNotifications()
  }, [refreshNotifications])

  const sendNotification = async (
    title: string,
    message: string,
    type: AppNotificationRecord['type'] = 'info',
    link?: string
  ) => {
    const record = await addDBNotification({ title, message, type, link })
    setNotifications(prev => [record, ...prev])
  }

  const markAsRead = async (id: string) => {
    await markDBRead(id)
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n))
  }

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        sendNotification,
        markAsRead,
      }}
    >
      {children}
    </NotificationContext.Provider>
  )
}

export const useNotifications = () => {
  const context = useContext(NotificationContext)
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider')
  }
  return context
}
