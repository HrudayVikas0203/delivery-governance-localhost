export interface ModuleModelMapping {
  requirementExtraction: string
  businessFlow: string
  architecture: string
  reports: string
  aiChat: string
  database?: string
}

export interface AiConfig {
  provider: string
  defaultModel: string
  moduleModels: ModuleModelMapping
  temperature: number
  maxTokens: number
  responseFormat: 'JSON Object' | 'Markdown' | 'Structured Text' | 'Raw Text'
  apiKey?: string
  endpointUrl?: string
  timeout?: number
  retryCount?: number
}

export interface ProviderDefinition {
  id: string
  name: string
  description: string
  models: string[]
  requiresEndpoint?: boolean
}

export const AI_PROVIDERS: ProviderDefinition[] = [
  {
    id: 'groq',
    name: 'Groq',
    description: 'Low-latency hosted inference compatible with the backend default provider',
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'],
  },
  {
    id: 'openai',
    name: 'OpenAI',
    description: 'Official OpenAI cloud services platform API',
    models: ['gpt-4o', 'gpt-4o-mini', 'o1-preview', 'o3-mini', 'gpt-4-turbo'],
  },
  {
    id: 'anthropic-claude',
    name: 'Anthropic Claude',
    description: 'Anthropic flagship reasoning & solution architecture models',
    models: ['claude-3-5-sonnet-20241022', 'claude-3-5-haiku', 'claude-3-opus'],
  },
  {
    id: 'google-gemini',
    name: 'Google Gemini',
    description: 'Google Multimodal High-Performance AI Platform',
    models: ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-2.0-flash'],
  },
  {
    id: 'xai-grok',
    name: 'xAI Grok',
    description: 'xAI Frontier reasoning and complex architectural model engine',
    models: ['grok-2-latest', 'grok-2-vision-latest', 'grok-beta'],
  },
  {
    id: 'ollama',
    name: 'Ollama',
    description: 'Self-hosted local open-weight LLMs runner',
    models: ['llama3.2', 'mistral', 'deepseek-r1:14b', 'codellama'],
    requiresEndpoint: true,
  },
  {
    id: 'custom-endpoint',
    name: 'Custom Endpoint',
    description: 'Private or proprietary API gateway (vLLM, OpenRouter, TGI)',
    models: ['custom-llm-v1', 'llama-3-70b-custom', 'vllm-model'],
    requiresEndpoint: true,
  },
  {
    id: 'azure-openai',
    name: 'Azure OpenAI',
    description: 'Managed OpenAI models deployed on Microsoft Azure',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-35-turbo'],
    requiresEndpoint: true,
  },
]

export const DEFAULT_AI_CONFIG: AiConfig = {
  provider: 'Groq',
  defaultModel: 'llama-3.3-70b-versatile',
  moduleModels: {
    requirementExtraction: 'llama-3.3-70b-versatile',
    businessFlow: 'llama-3.3-70b-versatile',
    architecture: 'llama-3.3-70b-versatile',
    reports: 'llama-3.3-70b-versatile',
    aiChat: 'llama-3.3-70b-versatile',
  },
  temperature: 0.2,
  maxTokens: 1200,
  responseFormat: 'Raw Text',
  endpointUrl: '',
  apiKey: '',
  timeout: 30,
  retryCount: 3,
}

export const MODULE_LABEL_MAP: Record<keyof ModuleModelMapping, string> = {
  requirementExtraction: 'Requirement Extraction',
  businessFlow: 'Business Flow Generation',
  architecture: 'Solution Architecture Generation',
  reports: 'Report Generation',
  aiChat: 'AI Chat',
  database: 'Database Design',
}
