import type { DocumentData } from '../types'

const layerColors: Record<string, string> = {
  Presentation: '#3B82F6', Middleware: '#8B5CF6', Backend: '#10B981', Data: '#F59E0B', Infrastructure: '#6B7280',
}
function nodeStyle(layer: string) {
  const color = layerColors[layer] || '#6B7280'
  return { background: `${color}15`, border: `2px solid ${color}`, borderRadius: '12px', padding: '12px 16px', fontSize: '12px', fontWeight: 600, color, minWidth: '120px', textAlign: 'center' as const }
}
const flowNodeStyle = (color: string) => ({ background: color, borderRadius: '10px', padding: '10px 16px', fontSize: '12px', fontWeight: 600, color: '#fff', minWidth: '100px', textAlign: 'center' as const, border: 'none' })

const data: DocumentData = {
  documentInfo: {
    id: 'ecommerce-srs',
    name: 'E-Commerce_Global_Storefront_SRS_v4.2.docx',
    type: 'SRS',
    pages: 112,
    confidence: 96,
    size: '5.8 MB',
    uploadedAt: new Date().toISOString(),
  },
  requirements: {
    actors: [
      { id: 'A1', name: 'Shopper', description: 'Anonymous or registered user browsing products, adding to cart, and checking out', type: 'Primary', icon: 'User' },
      { id: 'A2', name: 'Customer Support Representative', description: 'Assists shoppers with orders, refunds, and account issues', type: 'Primary', icon: 'UserCog' },
      { id: 'A3', name: 'Store Administrator', description: 'Manages catalog, inventory, pricing, campaigns, and user accounts', type: 'Primary', icon: 'Shield' },
      { id: 'A4', name: 'Warehouse Staff', description: 'Handles order fulfillment, packing, and dispatch operations', type: 'Primary', icon: 'Users' },
      { id: 'A5', name: 'Stripe Gateway', description: 'Processes credit cards, digital wallets, and local payments', type: 'External', icon: 'DollarSign' },
      { id: 'A6', name: 'TaxJar API', description: 'Calculates sales tax in real-time based on destination address', type: 'External', icon: 'Settings' },
      { id: 'A7', name: 'FedEx/DHL API', description: 'Retrieves live shipping rates and generates tracking labels', type: 'External', icon: 'Bell' },
    ],
    modules: [
      { id: 'M1', name: 'Product Catalog', description: 'Manage products, categories, search, recommendations, and reviews', priority: 'Critical', requirements: 28, status: 'Analyzed' },
      { id: 'M2', name: 'Shopping Cart & Checkout', description: 'Cart management, promo codes, tax/shipping calculation, checkout flow', priority: 'Critical', requirements: 32, status: 'Analyzed' },
      { id: 'M3', name: 'Order Fulfillment', description: 'Order status flow, warehouse notifications, labeling, tracking updates', priority: 'High', requirements: 20, status: 'Analyzed' },
      { id: 'M4', name: 'Inventory Control', description: 'Real-time stock tracking, low stock alerts, supplier management', priority: 'High', requirements: 14, status: 'Analyzed' },
      { id: 'M5', name: 'Customer Accounts', description: 'Authentication, order history, profile, address book, wishlist', priority: 'Medium', requirements: 18, status: 'Analyzed' },
    ],
    functional: [
      { id: 'R1', code: 'FR-001', title: 'Product Search and Filter', description: 'Shoppers must be able to search for products by keywords, filter by category, price, brand, rating, and sort the results.', priority: 'Critical', category: 'Catalog', module: 'Product Catalog', status: 'Validated', type: 'Functional' },
      { id: 'R2', code: 'FR-002', title: 'Cart Management', description: 'Shoppers must be able to add, update quantity, remove, and persist items in a shopping cart across sessions.', priority: 'Critical', category: 'Checkout', module: 'Shopping Cart & Checkout', status: 'Validated', type: 'Functional' },
      { id: 'R3', code: 'FR-003', title: 'Real-Time Tax and Shipping Calculation', description: 'The checkout flow must call external tax and shipping APIs to calculate final amounts based on shipping addresses.', priority: 'Critical', category: 'Checkout', module: 'Shopping Cart & Checkout', status: 'Validated', type: 'Functional' },
      { id: 'R4', code: 'FR-004', title: 'One-Click Checkout', description: 'Registered shoppers with saved addresses and cards must be able to complete purchase in a single click.', priority: 'High', category: 'Checkout', module: 'Shopping Cart & Checkout', status: 'Validated', type: 'Functional' },
      { id: 'R5', code: 'FR-005', title: 'Order Placement Workflow', description: 'Upon checkout completion, the system must process payment, send confirmation email, and route order to the warehouse.', priority: 'Critical', category: 'Fulfillment', module: 'Order Fulfillment', status: 'Validated', type: 'Functional' },
      { id: 'R6', code: 'FR-006', title: 'Inventory Reservation', description: 'When an item is added to checkout, block stock for 15 minutes to prevent overselling.', priority: 'High', category: 'Inventory', module: 'Inventory Control', status: 'Validated', type: 'Functional' },
      { id: 'R7', code: 'FR-007', title: 'Wishlist & Save for Later', description: 'Shoppers can save products to wishlists and share them with other users.', priority: 'Medium', category: 'Accounts', module: 'Customer Accounts', status: 'Extracted', type: 'Functional' },
    ],
    nonFunctional: [
      { id: 'NF1', code: 'NFR-001', title: 'Peak Transactions per Second', description: 'System must handle 1,500 checkouts per minute during Black Friday peak sales.', priority: 'Critical', category: 'Performance', module: 'System-Wide', status: 'Validated', type: 'Non-Functional' },
      { id: 'NF2', code: 'NFR-002', title: 'PCI-DSS Compliance', description: 'No raw cardholder data must be stored. Stripe Hosted Fields/Elements must be used.', priority: 'Critical', category: 'Security', module: 'System-Wide', status: 'Validated', type: 'Non-Functional' },
      { id: 'NF3', code: 'NFR-003', title: 'Global CDN Caching', description: 'Product catalog images and static pages must have a cache hit ratio of >90% globally.', priority: 'High', category: 'Performance', module: 'System-Wide', status: 'Validated', type: 'Non-Functional' },
      { id: 'NF4', code: 'NFR-004', title: 'SLA for External API Failures', description: 'System must fallback to flat shipping/tax estimates if TaxJar or FedEx APIs do not respond in 2 seconds.', priority: 'High', category: 'Reliability', module: 'System-Wide', status: 'Validated', type: 'Non-Functional' },
    ],
    businessRules: [
      { id: 'BR1', rule: 'Promo codes cannot be stacked unless explicitly marked as stackable', module: 'Shopping Cart & Checkout' },
      { id: 'BR2', rule: 'Free shipping applies to orders over $75 within the continental US', module: 'Shopping Cart & Checkout' },
      { id: 'BR3', rule: 'Items in cart do not guarantee stock reservation until checkout process begins', module: 'Shopping Cart & Checkout' },
      { id: 'BR4', rule: 'Returns allowed within 30 days of purchase for unused items', module: 'Customer Accounts' },
    ],
    assumptions: [
      { id: 'AS1', assumption: 'Third-party payment gateway (Stripe) is active and integrated', category: 'Integrations' },
      { id: 'AS2', assumption: 'Catalog assets (images/videos) will be uploaded in optimized web formats', category: 'Assets' },
    ],
    constraints: [
      { id: 'CN1', constraint: 'Platform must pass quarterly PCI compliance scans', category: 'Compliance' },
      { id: 'CN2', constraint: 'Core database migrations must be zero-downtime', category: 'Database' },
      { id: 'CN3', constraint: 'Page size for critical path pages must be <1.5MB total payload', category: 'Performance' },
    ],
    externalSystems: [
      { id: 'ES1', name: 'Stripe Gateway', type: 'Payment Processing', integration: 'Stripe Elements + Webhooks', direction: 'Bidirectional' },
      { id: 'ES2', name: 'TaxJar', type: 'Sales Tax Compliance', integration: 'REST API', direction: 'Outbound' },
      { id: 'ES3', name: 'FedEx API', type: 'Fulfillment & Shipping', integration: 'REST API', direction: 'Bidirectional' },
      { id: 'ES4', name: 'Klaviyo', type: 'Marketing Automation', integration: 'REST API + Events', direction: 'Outbound' },
    ],
    risks: [
      { id: 'RK1', risk: 'Inventory discrepancies during high-concurrency peak sales', probability: 'Medium', impact: 'High', mitigation: 'Implement Redis locks for stock verification and auto-expire reservations after 15 mins' },
      { id: 'RK2', risk: 'Checkout failures due to Tax/Shipping API latency or outage', probability: 'Low', impact: 'Critical', mitigation: 'Cached fallback table containing regional averages and trigger flat calculations' },
    ],
  },
  businessFlow: {
    nodes: [
      { id: 'bf1', type: 'default', position: { x: 350, y: 0 }, data: { label: 'Browse Products', description: 'Catalog/Search' }, style: flowNodeStyle('#3B82F6') },
      { id: 'bf2', type: 'default', position: { x: 350, y: 100 }, data: { label: 'Add to Cart', description: 'Verify inventory' }, style: flowNodeStyle('#8B5CF6') },
      { id: 'bf3', type: 'default', position: { x: 350, y: 200 }, data: { label: 'Initiate Checkout', description: 'Lock stock for 15m' }, style: flowNodeStyle('#EF4444') },
      { id: 'bf4', type: 'default', position: { x: 150, y: 310 }, data: { label: 'Enter Shipping Info', description: 'Address verification' }, style: flowNodeStyle('#F59E0B') },
      { id: 'bf5', type: 'default', position: { x: 550, y: 310 }, data: { label: 'Apply Coupons/Promos', description: 'Recalculate order' }, style: flowNodeStyle('#10B981') },
      { id: 'bf6', type: 'default', position: { x: 350, y: 420 }, data: { label: 'Payment Method', description: 'Stripe Hosted Flow' }, style: flowNodeStyle('#3B82F6') },
      { id: 'bf7', type: 'default', position: { x: 350, y: 530 }, data: { label: 'Fulfillment', description: 'Warehouse notification' }, style: flowNodeStyle('#10B981') },
      { id: 'bf8', type: 'default', position: { x: 350, y: 640 }, data: { label: 'Dispatch Order', description: 'Tracking generated' }, style: flowNodeStyle('#64748B') },
    ],
    edges: [
      { id: 'e1', source: 'bf1', target: 'bf2', animated: true },
      { id: 'e2', source: 'bf2', target: 'bf3' },
      { id: 'e3', source: 'bf3', target: 'bf4' },
      { id: 'e4', source: 'bf3', target: 'bf5' },
      { id: 'e5', source: 'bf4', target: 'bf6' },
      { id: 'e6', source: 'bf5', target: 'bf6' },
      { id: 'e7', source: 'bf6', target: 'bf7', label: 'Authorized' },
      { id: 'e8', source: 'bf7', target: 'bf8' },
    ],
  },
  architecture: {
    nodes: [
      { id: 'ac1', type: 'default', position: { x: 350, y: 0 }, data: { label: 'Shopify Storefront', componentType: 'Frontend', technology: 'React + Remix', description: 'Global customer storefront', cloudService: 'Cloudflare Pages', layer: 'Presentation', icon: 'Globe' }, style: nodeStyle('Presentation') },
      { id: 'ac2', type: 'default', position: { x: 600, y: 0 }, data: { label: 'Admin Portal', componentType: 'Frontend', technology: 'React', description: 'Internal store console', cloudService: 'Cloudflare Pages', layer: 'Presentation', icon: 'Shield' }, style: nodeStyle('Presentation') },
      { id: 'ac3', type: 'default', position: { x: 470, y: 120 }, data: { label: 'API Gateway', componentType: 'Gateway', technology: 'Fastly Custom Edge', description: 'Reverse proxy, routing, caching', cloudService: 'Fastly WAF', layer: 'Middleware', icon: 'Shield' }, style: nodeStyle('Middleware') },
      { id: 'ac4', type: 'default', position: { x: 100, y: 260 }, data: { label: 'Catalog Service', componentType: 'Microservice', technology: 'Go + GraphQL', description: 'Product search, catalogs', cloudService: 'AWS Fargate', layer: 'Backend', icon: 'Target' }, style: nodeStyle('Backend') },
      { id: 'ac5', type: 'default', position: { x: 300, y: 260 }, data: { label: 'Cart & Order Service', componentType: 'Microservice', technology: 'Go', description: 'Transactions, promotions', cloudService: 'AWS Fargate', layer: 'Backend', icon: 'DollarSign' }, style: nodeStyle('Backend') },
      { id: 'ac6', type: 'default', position: { x: 500, y: 260 }, data: { label: 'Inventory Service', componentType: 'Microservice', technology: 'Node.js', description: 'Real-time stocks', cloudService: 'AWS Fargate', layer: 'Backend', icon: 'Database' }, style: nodeStyle('Backend') },
      { id: 'ac7', type: 'default', position: { x: 700, y: 260 }, data: { label: 'Customer Service', componentType: 'Microservice', technology: 'Node.js', description: 'Accounts, profiles, wallets', cloudService: 'AWS Fargate', layer: 'Backend', icon: 'User' }, style: nodeStyle('Backend') },
      { id: 'ac8', type: 'default', position: { x: 200, y: 400 }, data: { label: 'CockroachDB', componentType: 'Database', technology: 'CockroachDB Serverless', description: 'Global relational transactional DB', cloudService: 'CockroachDB Cloud', layer: 'Data', icon: 'Database' }, style: nodeStyle('Data') },
      { id: 'ac9', type: 'default', position: { x: 400, y: 400 }, data: { label: 'Redis Stock Cache', componentType: 'Cache', technology: 'Redis Cluster', description: 'Stock reservation caching', cloudService: 'Redis Enterprise', layer: 'Data', icon: 'Zap' }, style: nodeStyle('Data') },
      { id: 'ac10', type: 'default', position: { x: 600, y: 400 }, data: { label: 'Algolia Search', componentType: 'Search', technology: 'Algolia', description: 'Instant product search engine', cloudService: 'Algolia Cloud', layer: 'Data', icon: 'Search' }, style: nodeStyle('Data') },
      { id: 'ac11', type: 'default', position: { x: 450, y: 520 }, data: { label: 'Apache Kafka', componentType: 'Messaging', technology: 'Kafka + Confluent', description: 'Event pipeline (Orders, inventory)', cloudService: 'Confluent Cloud', layer: 'Infrastructure', icon: 'ArrowLeftRight' }, style: nodeStyle('Infrastructure') },
      { id: 'ac12', type: 'default', position: { x: 650, y: 520 }, data: { label: 'Datadog APM', componentType: 'Monitoring', technology: 'Datadog', description: 'Global performance APM', cloudService: 'Datadog Cloud', layer: 'Infrastructure', icon: 'Activity' }, style: nodeStyle('Infrastructure') },
    ],
    edges: [
      { id: 'ae1', source: 'ac1', target: 'ac3', animated: true }, { id: 'ae2', source: 'ac2', target: 'ac3' },
      { id: 'ae3', source: 'ac3', target: 'ac4' }, { id: 'ae4', source: 'ac3', target: 'ac5', animated: true },
      { id: 'ae5', source: 'ac3', target: 'ac6' }, { id: 'ae6', source: 'ac3', target: 'ac7' },
      { id: 'ae7', source: 'ac4', target: 'ac8' }, { id: 'ae8', source: 'ac5', target: 'ac8' },
      { id: 'ae9', source: 'ac6', target: 'ac9' }, { id: 'ae10', source: 'ac4', target: 'ac10' },
      { id: 'ae11', source: 'ac5', target: 'ac11' }, { id: 'ae12', source: 'ac6', target: 'ac11' },
      { id: 'ae13', source: 'ac11', target: 'ac12' },
    ],
    recommendations: [
      { id: 'REC1', title: 'Implement Image Optimization CDN', reason: 'High static payload on catalog. Reduce banner sizes.', impact: 'High', priority: 1, category: 'Performance', applied: false },
      { id: 'REC2', title: 'Multi-Region DB Replication', reason: 'Avoid single points of latency for EU/Asia customers on CockroachDB.', impact: 'Critical', priority: 2, category: 'Reliability', applied: false },
      { id: 'REC3', title: 'Webhooks Re-try with Backoff', reason: 'Stripe webhook failures can lead to order dropouts if not retried properly.', impact: 'High', priority: 3, category: 'Reliability', applied: false },
    ],
    techStack: [
      { category: 'Frontend', technology: 'Remix + React', confidence: 95, reason: 'Edge rendering capability, built-in forms, optimized resource loading', alternatives: ['Next.js', 'Astro'] },
      { category: 'Database', technology: 'CockroachDB', confidence: 93, reason: 'Distributed SQL supporting ACID transactions globally', alternatives: ['Spanner', 'Aurora PostgreSQL'] },
      { category: 'Search Engine', technology: 'Algolia', confidence: 96, reason: 'Out-of-the-box global latency <50ms for instant search', alternatives: ['Elasticsearch', 'Typesense'] },
      { category: 'Cloud Infrastructure', technology: 'AWS Fargate', confidence: 91, reason: 'Serverless container execution, autoscales easily', alternatives: ['Kubernetes', 'Cloud Run'] },
    ],
    validations: [
      { id: 'VW1', title: 'Flat Calculation Fallback Missing', priority: 'High', description: 'Checkout blocks if TaxJar is completely down.', recommendedFix: 'Implement regional standard averages fallback calculations', category: 'Reliability', resolved: false },
      { id: 'VW2', title: 'Cart Storage Security', priority: 'Medium', description: 'Cart items saved in local storage without integrity check.', recommendedFix: 'Verify cart content checksum on checkout start', category: 'Security', resolved: false },
    ],
    healthMetrics: [
      { name: 'Completeness', score: 86, maxScore: 100, recommendations: ['Setup SLA fallbacks'] },
      { name: 'Security', score: 92, maxScore: 100, recommendations: ['Audit third-party scripts'] },
      { name: 'Performance', score: 89, maxScore: 100, recommendations: ['Image optimizations'] },
      { name: 'Scalability', score: 94, maxScore: 100, recommendations: [] },
      { name: 'Reliability', score: 79, maxScore: 100, recommendations: ['Configure webhook retries'] },
    ],
    versions: [
      { id: 'v2', version: 'v4.2', name: 'Global Scale Store', date: new Date().toISOString(), changes: 'Added Confluent Kafka and Algolia search integrations', components: 12, connections: 13, author: 'AI Copilot' },
      { id: 'v1', version: 'v1.0', name: 'Monolith Prototype', date: new Date(Date.now() - 172800000).toISOString(), changes: 'Single deploy prototype', components: 6, connections: 5, author: 'AI Copilot' },
    ],
  },
  database: {
    entities: [
      { id: 'E1', name: 'Product', description: 'Items sold in the global catalog', fields: [
        { name: 'sku', type: 'VARCHAR(50)', pk: true, description: 'Stock Keeping Unit (Unique)' },
        { name: 'name', type: 'VARCHAR(255)', description: 'Product name' },
        { name: 'description', type: 'TEXT', description: 'Full description' },
        { name: 'price', type: 'NUMERIC(10,2)', description: 'Unit price' },
        { name: 'stock_quantity', type: 'INT', description: 'Available warehouse inventory' },
        { name: 'category_id', type: 'UUID', fk: 'Category.category_id', description: 'Parent category' },
      ]},
      { id: 'E2', name: 'Category', description: 'Product organization categories', fields: [
        { name: 'category_id', type: 'UUID', pk: true, description: 'Unique identifier' },
        { name: 'name', type: 'VARCHAR(150)', description: 'Category label' },
        { name: 'slug', type: 'VARCHAR(150)', description: 'SEO url path' },
      ]},
      { id: 'E3', name: 'Order', description: 'Customer transaction records', fields: [
        { name: 'order_id', type: 'UUID', pk: true, description: 'Unique identifier' },
        { name: 'customer_id', type: 'UUID', fk: 'Customer.customer_id', description: 'Associated customer' },
        { name: 'tax_amount', type: 'NUMERIC(10,2)', description: 'Calculated sales tax' },
        { name: 'shipping_amount', type: 'NUMERIC(10,2)', description: 'Calculated shipping rate' },
        { name: 'total_amount', type: 'NUMERIC(10,2)', description: 'Final order total charged' },
        { name: 'status', type: 'VARCHAR(50)', description: 'paid, processing, shipped, complete' },
        { name: 'shipping_address', type: 'TEXT', description: 'Delivery destination' },
      ]},
      { id: 'E4', name: 'OrderItem', description: 'Line items within orders', fields: [
        { name: 'order_item_id', type: 'UUID', pk: true, description: 'Line item unique identifier' },
        { name: 'order_id', type: 'UUID', fk: 'Order.order_id', description: 'Associated order parent' },
        { name: 'sku', type: 'VARCHAR(50)', fk: 'Product.sku', description: 'SKU purchased' },
        { name: 'quantity', type: 'INT', description: 'Quantity ordered' },
        { name: 'unit_price', type: 'NUMERIC(10,2)', description: 'Price at order date' },
      ]},
    ],
  },
  reports: {
    sections: [
      { title: 'Executive Summary', content: 'The E-Commerce Global Storefront is a global high-performance scale commerce solution. Built to handle Black Friday level peak transaction rates of up to 1,500 checkouts per minute.\n\nKey Metrics: 96% AI confidence, 7 functional requirements, 4 non-functional requirements, 5 business modules, and overall health score of 86/100.' },
      { title: 'Business Summary', content: '5 core modules: Product Catalog (28 requirements), Shopping Cart & Checkout (32 requirements), Order Fulfillment (20 requirements), Inventory Control (14 requirements), and Customer Accounts (18 requirements). Integrations with external Stripe payment gateways, TaxJar calculations, and FedEx APIs are essential.' },
      { title: 'Technical Summary', content: 'Edge presentation deployment via Cloudflare Pages and Fastly edge configurations. Backend Go/GraphQL containers deployed to AWS Fargate. Database layers: CockroachDB distributed database + global Redis clusters + Algolia search pipelines. Operations run fully async utilizing Confluent Kafka messages.' },
    ],
  },
}

export default data
