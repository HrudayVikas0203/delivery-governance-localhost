// Shared types for document-generated data
// These types define the schema that all mock JSON files follow
// and that the DocumentContext exposes to all pages.

export interface DocumentInfo {
  id: string
  name: string
  type: 'BRD' | 'HLRD' | 'FRD' | 'RFP' | 'SRS'
  pages: number
  confidence: number
  size: string
  uploadedAt: string
}

export interface Actor {
  id: string
  name: string
  description: string
  type: 'Primary' | 'Secondary' | 'External'
  icon: string
}

export interface BusinessModule {
  id: string
  name: string
  description: string
  priority: 'Critical' | 'High' | 'Medium' | 'Low'
  requirements: number
  status: string
}

export interface Requirement {
  id: string
  code: string
  title: string
  description: string
  priority: 'Critical' | 'High' | 'Medium' | 'Low'
  category: string
  module: string
  status: 'Extracted' | 'Validated' | 'Pending'
  type: 'Functional' | 'Non-Functional'
}

export interface BusinessRule {
  id: string
  rule: string
  module: string
}

export interface Assumption {
  id: string
  assumption: string
  category: string
}

export interface Constraint {
  id: string
  constraint: string
  category: string
}

export interface ExternalSystem {
  id: string
  name: string
  type: string
  integration: string
  direction: string
}

export interface Risk {
  id: string
  risk: string
  probability: string
  impact: string
  mitigation: string
}

export interface FlowNode {
  id: string
  type: string
  position: { x: number; y: number }
  data: { label: string; description?: string }
  style?: Record<string, unknown>
}

export interface FlowEdge {
  id: string
  source: string
  target: string
  label?: string
  animated?: boolean
  style?: Record<string, unknown>
}

export interface ArchNode {
  id: string
  type: string
  position: { x: number; y: number }
  data: {
    label: string
    componentType: string
    technology: string
    description: string
    cloudService: string
    layer: string
    icon: string
  }
  style?: Record<string, unknown>
}

export interface ArchEdge {
  id: string
  source: string
  target: string
  label?: string
  animated?: boolean
  style?: Record<string, unknown>
}

export interface DBField {
  name: string
  type: string
  pk?: boolean
  fk?: boolean | string
  nullable?: boolean
  description?: string
}

export interface DBEntity {
  id: string
  name: string
  description?: string
  fields: DBField[]
  relationships?: { target: string; type: string }[]
}

export interface Recommendation {
  id: string
  title: string
  reason: string
  impact: 'Critical' | 'High' | 'Medium' | 'Low'
  priority: number
  category: string
  applied: boolean
}

export interface TechRecommendation {
  category: string
  technology: string
  confidence: number
  reason: string
  alternatives: string[]
}

export interface ValidationWarning {
  id: string
  title: string
  priority: 'Critical' | 'High' | 'Medium' | 'Low'
  description: string
  recommendedFix: string
  category: string
  resolved: boolean
}

export interface HealthMetric {
  name: string
  score: number
  maxScore: number
  recommendations: string[]
}

export interface VersionHistoryItem {
  id: string
  version: string
  name: string
  date: string
  changes: string
  components: number
  connections: number
  author: string
}

export interface ReportSection {
  title: string
  content: string
}

export interface ExecutiveLayerItem {
  id: string
  name: string
  description?: string
  businessPurpose?: string
  technicalDetails?: string
  technicalResponsibility?: string | string[]
  supportingTechnology?: string
  icon?: string
  type?: string
  badge?: string
  emphasis?: 'primary' | 'secondary' | 'tertiary'
}

export interface ExecutiveLayer {
  id: string
  name: string
  category?: 'Users' | 'Capabilities' | 'AI Platform' | 'Integrations' | 'Enterprise Systems' | 'Data Sources' | 'Security & Governance' | 'Infrastructure & DevOps' | string
  items: ExecutiveLayerItem[]
  summary?: string
}

export interface ArchitecturalDecision {
  id: string
  decision: string
  whyChosen: string
  category?: string
}

export interface BusinessValueItem {
  id: string
  title: string
  description: string
  metric?: string
}

export interface ExecutiveInsightItem {
  id: string
  title: string
  description: string
  badge?: string
}

export interface TechnologyHighlightItem {
  id: string
  title: string
  summary: string
  category?: string
  badge?: string
}

export interface SecurityControlItem {
  id: string
  title: string
  description: string
  category?: string
  badge?: string
}

export interface ScalabilityStrategyItem {
  id: string
  title: string
  description: string
  category?: string
  badge?: string
}

export interface DeploymentModelItem {
  id: string
  title: string
  description: string
  category?: string
  badge?: string
}

export type ExecutiveTemplateId =
  | 'enterpriseConsulting'
  | 'executiveBlueprint'
  | 'capabilityMap'
  | 'cloudNativePlatform'
  | 'aiPlatformArchitecture'
  | 'digitalTransformation'
  | 'technologyCapabilityMatrix'
  | 'enterpriseOperatingModel'
  | 'referenceArchitecture'
  | 'solutionDeliveryFramework'
  | 'modernEnterprisePlatform'
  | 'executiveStrategyView'
  | 'technologyReferenceArchitecture'
  | 'applicationModernization'
  | 'platformArchitecture'
  | 'dataGovernanceArchitecture'
  | 'integrationArchitecture'
  | 'businessTransformationRoadmap'
  | 'microservicesArchitecture'
  | 'eventDrivenArchitecture'
  | 'hybridCloudArchitecture'
  | 'enterpriseAiEcosystem'
  | 'businessCapabilityModel'
  | 'operatingArchitecture'
  | 'targetStateArchitecture'

export type ExecutiveThemeId =
  | 'corporateBlue'
  | 'executiveNavy'
  | 'azure'
  | 'emerald'
  | 'purple'
  | 'slateGray'
  | 'ibmStyle'
  | 'awsStyle'
  | 'sapStyle'
  | 'oracleStyle'
  | 'darkExecutive'
  | 'monochrome'

export interface ExecutiveArchitectureData {
  templateId?: ExecutiveTemplateId
  themeId?: ExecutiveThemeId
  title?: string
  subtitle?: string
  layoutNarrative?: string
  generatedVariantId?: string
  layers: ExecutiveLayer[]
  architecturalDecisions: ArchitecturalDecision[]
  businessValue: BusinessValueItem[]
  technologyHighlights?: TechnologyHighlightItem[]
  executiveInsights?: ExecutiveInsightItem[]
  securityControls?: SecurityControlItem[]
  scalabilityStrategy?: ScalabilityStrategyItem[]
  deploymentModel?: DeploymentModelItem[]
}

export interface DocumentData {
  documentInfo: DocumentInfo
  requirements: {
    actors: Actor[]
    modules: BusinessModule[]
    functional: Requirement[]
    nonFunctional: Requirement[]
    businessRules: BusinessRule[]
    assumptions: Assumption[]
    constraints: Constraint[]
    externalSystems: ExternalSystem[]
    risks: Risk[]
  }
  businessFlow: {
    nodes: FlowNode[]
    edges: FlowEdge[]
  }
  architecture: {
    nodes: ArchNode[]
    edges: ArchEdge[]
    executive?: ExecutiveArchitectureData
    recommendations: Recommendation[]
    techStack: TechRecommendation[]
    validations: ValidationWarning[]
    healthMetrics: HealthMetric[]
    versions: VersionHistoryItem[]
  }
  reports: {
    sections: ReportSection[]
  }
  database?: any
}

export interface Project {
  id: string
  name: string
  description: string
  createdAt: string
  documents: string[]
  selectedTechStack: string
  selectedDatabase: string
  isStackConfirmed?: boolean
  customBusinessFlow?: {
    nodes: FlowNode[]
    edges: FlowEdge[]
  }
  customArchitecture?: {
    nodes: ArchNode[]
    edges: ArchEdge[]
    executive?: ExecutiveArchitectureData
    recommendations: Recommendation[]
    techStack: TechRecommendation[]
    validations: ValidationWarning[]
    healthMetrics: HealthMetric[]
    versions: VersionHistoryItem[]
  }
  techStackDetails?: {
    frontend?: string
    backend?: string
    database?: string
    authentication?: string
    cloudPlatform?: string
    storage?: string
    messaging?: string
    aiServices?: string
    monitoring?: string
  }
}
